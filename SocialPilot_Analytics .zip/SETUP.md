# SocialPilot AI — Phase 9: Usage Analytics & Owner Dashboard

## What you get

| Piece | Where |
|---|---|
| SQL migrations (tables, indexes, RLS, ingestion + admin query functions) | `supabase/migrations/*.sql` (run in order) |
| Grant the first owner | `supabase/seed/grant_owner.sql` |
| Secure analytics API (`/api/admin/analytics/*`) | `server/src/app.js` |
| Admin dashboard (`/admin/analytics`) | `server/public/admin/analytics/` |
| Web tracker | `client/web/analytics.js` |
| Android tracker (Kotlin) | `client/android/SocialPilotAnalytics.kt` |
| Privacy policy text | `docs/privacy-policy-analytics-section.md` |
| Tests | `tests/`, run all with `scripts/test-all.sh` |

Stack assumption: Supabase (Postgres + Auth). No earlier-phase code was present in this workspace,
so this is a self-contained module. If your auth/database differs, the SQL logic ports directly; the
`auth.users` / `auth.uid()` references are the only Supabase-specific parts.

## 1. Database

1. Supabase dashboard → SQL editor → run the five files in `supabase/migrations/` in order.
   They are idempotent (safe to re-run).
2. Sign in once with the owner account so it exists in `auth.users`.
3. Edit the email in `supabase/seed/grant_owner.sql` and run it in the SQL editor.
   Roles can ONLY be granted this way: no API, app or logged-in user can write `admin_roles`
   (no grants, no write policies, plus a trigger that blocks any change when a JWT user is present).

## 2. Run the dashboard + API

```bash
cd server
SUPABASE_URL=https://YOUR-REF.supabase.co SUPABASE_ANON_KEY=YOUR_PUBLIC_ANON_KEY node src/index.js
# open http://127.0.0.1:8787/admin/analytics and sign in as the owner
```

Needs Node 20+, zero npm dependencies. Put it behind HTTPS (reverse proxy) in production. The
**service-role key is never used**: every query runs with the signed-in user's own token, so
Postgres itself decides who is an admin. To embed in an existing app instead, call
`createApp({supabase}).handle({method,url,headers})` from any framework route.

Production notes: enable MFA on the owner account in Supabase Auth; the API rate limit is
in-memory per process (use a shared store if you run several instances).

## 3. Add tracking

**Web**: copy `client/web/analytics.js`; see the header comment. Call `start()` after sign-in and
`stop()` on logout (before clearing the session).
**Android**: copy `SocialPilotAnalytics.kt`, add the three Gradle dependencies listed in its header,
call `init(...)` in `Application.onCreate`, `track(...)` for events, `logout()` on sign-out.
Set `requireConsent = true` where opt-in is legally required (EU/UK) and wire `setEnabled()` /
`setConsent()` to a privacy toggle.

> The Kotlin file could not be compiled in the authoring environment. Build it in Android Studio and do
> the manual check below. The web tracker, API and SQL are tested automatically.

Events: `app_open, login, logout, post_created, draft_saved, post_scheduled, post_published,
ai_generation, account_connected`. Only these metadata keys are stored (enforced in the database,
not just the clients): `provider, post_type, feature, method, success, error_code, count`.
Post text and AI prompts cannot be stored.

### Android apps that are a WebView (EarnKori)

If the Android app only opens your website in a WebView (login happens on the web page), do NOT use
`SocialPilotAnalytics.kt`. Use `client/web/analytics.js` on the website pages instead:

* The app adds a token to its User-Agent, e.g. ` EarnKoriApp/1.2 (Android 14; Pixel 8)` (already done in
  the updated `EarnKori_App_GitHub.zip`, see `appUserAgentToken()` in `MainActivity.kt`).
* The web tracker detects that token, so sessions and events from inside the app are stored as platform
  `android` with app version, Android version and device model; a normal browser is stored as `web`.
* Sent only: app version, Android version, device model. Nothing else is read from the phone.

### Building the APK on GitHub (same way as EarnKori / TechPremPro)

`.github/workflows/build-socialpilot-apk.yml` unzips your Android project ZIP from the repo root and
builds it with Gradle 8.9 / JDK 17. Before it can work:

1. Put your app ZIP in the repo root and set `APP_ZIP` at the top of the workflow to its file name.
2. Add repo secrets `SUPABASE_URL` and `SUPABASE_ANON_KEY` (public values). Release builds also need
   `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`.
3. Inside the app project: copy `SocialPilotAnalytics.kt`, add its three Gradle dependencies, and expose
   `SUPABASE_URL` / `SUPABASE_ANON_KEY` as `BuildConfig` fields (read from the environment variables
   above) so the tracker can call `init(...)`.
4. Push, or run the workflow manually from the Actions tab (choose debug or release).

> Not run yet: this workspace has no Android project, so this workflow is untested. The first Actions
> run may need small fixes (ZIP name, Gradle config).

## 4. Privacy

Paste `docs/privacy-policy-analytics-section.md` into your policy, fill the bracketed items and
get it reviewed for your jurisdictions. Decide retention (suggested: delete events older than 13
months). Example scheduled job:
`delete from public.analytics_events where created_at < now() - interval '13 months';`
Account deletion removes a user's analytics rows automatically (`on delete cascade`).

## 5. Testing

```bash
# any disposable Postgres 15+ server (never a real Supabase project)
PGHOST=localhost PGUSER=postgres ./scripts/test-all.sh          # SQL + unit + API end-to-end
BROWSER=1 SHOTS=/tmp ./scripts/test-all.sh                       # plus headless-browser dashboard checks
```

What is verified: every overview number against a fixed dataset with exact expected values;
zero-filled daily series; timezone boundaries; weekly/monthly growth; Android vs Web; user list
search/filter/sort/pagination (including LIKE-wildcard and SQL-injection input); privacy (no
password hash, no prompt text); ingestion hardening (bad events, foreign session ids, rate limit,
stale sessions); and access control: a regular user gets 403 from every admin route, the database
itself refuses them even if the API were bypassed, cannot read others' rows, cannot write
analytics tables directly, cannot create or edit their own admin role; anonymous callers get 401.

Manual Android check: sign in on a device/emulator, open the dashboard, confirm the user shows
Platform "Android", the app version, Android version and model under Devices, and that
"Online now (estimate)" counts them within ~2.5 minutes.

## Definitions (also shown in the dashboard)

* Registered users: non-deleted accounts. Repeat app opens never create users (one device row per user+platform).
* Active user: distinct user with at least one qualifying activity (any event except `logout`, or a session start). Heartbeats alone do not count.
* Online now: distinct users with an open session and a heartbeat under 150 seconds old. Labelled an estimate.
* Windows are calendar days in the admin's timezone including today. Session duration is capped at 4 hours.
* Post counts come from tracked events, so posts made before tracking was enabled are not counted.

## Limitations

* Android and web totals overlap for people who use both.
* Counts rely on clients reporting; blocked or opted-out users (consent, Do Not Track/GPC) are not counted.
* Admin login in the dashboard uses email + password via Supabase Auth; add MFA/SSO in Supabase for stronger protection.
