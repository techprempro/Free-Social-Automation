// SocialPilot AI — web analytics tracker (privacy-first, dependency-free ES module).
//
//   import { createAnalytics } from './analytics.js';
//   const analytics = createAnalytics({
//     supabaseUrl: 'https://xxx.supabase.co',
//     anonKey: '<public anon key>',
//     getAccessToken: async () => (await supabase.auth.getSession()).data.session?.access_token ?? null,
//     appVersion: '1.0.0',
//     requireConsent: false,          // set true where opt-in consent is required (e.g. EU/UK)
//   });
//   await analytics.start();                       // after sign-in / on app load
//   analytics.track('post_created', { post_type: 'image' });
//   await analytics.stop();                        // on logout (sends 'logout' + ends session)
//
// What it sends: event name, platform ('web'), app version, a session id and
// whitelisted non-sensitive metadata. It NEVER sends post content, AI prompts,
// emails, names, contacts, messages or location. Requests use the signed-in
// user's own token; the database derives the user id from that token.

export const ALLOWED_EVENTS = Object.freeze([
  'app_open', 'login', 'logout', 'post_created', 'draft_saved',
  'post_scheduled', 'post_published', 'ai_generation', 'account_connected',
]);
// Must match public.analytics_clean_metadata() in the database.
export const ALLOWED_METADATA_KEYS = Object.freeze(['provider', 'post_type', 'feature', 'method', 'success', 'error_code', 'count']);

const CONSENT_KEY = 'sp_analytics_consent';
const HEARTBEAT_MS = 30_000;
const MAX_QUEUE = 50;

// The Android app is a WebView that adds a token to its User-Agent, e.g.
//   " EarnKoriApp/1.0 (Android 14; Pixel 8)"
// Pages running inside it report platform 'android' (plus app/OS/model); a normal browser reports 'web'.
const APP_UA = /\b(?:EarnKoriApp|SocialPilotApp)\/([\w.-]{1,16})(?: \(Android ([\w.-]{1,16}); ([\w .+-]{0,40})\))?/;

export function detectPlatform(userAgent) {
  const m = typeof userAgent === 'string' ? APP_UA.exec(userAgent) : null;
  if (!m) return { platform: 'web', appVersion: null, osVersion: null, deviceModel: null };
  return { platform: 'android', appVersion: m[1], osVersion: m[2] ?? null, deviceModel: m[3]?.trim() || null };
}

export function sanitizeMetadata(meta) {
  const out = {};
  if (!meta || typeof meta !== 'object' || Array.isArray(meta)) return out;
  for (const key of ALLOWED_METADATA_KEYS) {
    const v = meta[key];
    if (typeof v === 'string' && v.length <= 64) out[key] = v;
    else if (typeof v === 'number' && Number.isFinite(v)) out[key] = v;
    else if (typeof v === 'boolean') out[key] = v;
  }
  return out;
}

export function createAnalytics(options, env = {}) {
  const {
    supabaseUrl, anonKey, getAccessToken, appVersion: webVersion = null,
    requireConsent = false, heartbeatMs = HEARTBEAT_MS,
  } = options;
  const doFetch = env.fetch ?? globalThis.fetch?.bind(globalThis);
  const storage = env.storage ?? safeStorage();
  const doc = env.document ?? globalThis.document;
  const win = env.window ?? globalThis.window;
  const nav = env.navigator ?? globalThis.navigator;
  const base = String(supabaseUrl).replace(/\/+$/, '');
  const detected = detectPlatform(nav?.userAgent);
  const platform = detected.platform;                       // 'android' inside the app, else 'web'
  const appVersion = detected.appVersion ?? webVersion;

  let sessionId = null;
  let timer = null;
  let started = false;
  const queue = [];
  let flushing = false;

  function browserOptOut() {
    // Honour Do Not Track and Global Privacy Control.
    return nav?.doNotTrack === '1' || nav?.globalPrivacyControl === true;
  }

  function enabled() {
    if (browserOptOut()) return false;
    const c = storage.getItem(CONSENT_KEY);
    if (c === 'denied') return false;
    if (requireConsent && c !== 'granted') return false;
    return true;
  }

  async function rpc(fn, args, { keepalive = false } = {}) {
    const token = await getAccessToken();
    if (!token) return { ok: false, status: 401, data: null };
    const res = await doFetch(`${base}/rest/v1/rpc/${fn}`, {
      method: 'POST',
      headers: { apikey: anonKey, Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(args),
      keepalive,
    });
    let data = null;
    try { data = await res.json(); } catch { /* empty */ }
    return { ok: res.ok, status: res.status, data };
  }

  async function beginSession() {
    const r = await rpc('start_session', {
      p_platform: platform, p_app_version: appVersion,
      p_os_version: detected.osVersion, p_device_model: detected.deviceModel,
    });
    if (r.ok && typeof r.data === 'string') {
      sessionId = r.data;
      return true;
    }
    return false;
  }

  async function flush() {
    if (flushing || !sessionId) return;
    flushing = true;
    try {
      while (queue.length) {
        const item = queue[0];
        const r = await rpc('track_event', {
          p_event_name: item.name, p_platform: platform, p_app_version: appVersion,
          p_session_id: sessionId, p_metadata: item.metadata,
        });
        if (r.ok) { queue.shift(); continue; }
        // 4xx (except 429) will never succeed: drop. Network/5xx/429: keep and retry later.
        if (r.status >= 400 && r.status < 500 && r.status !== 429) { queue.shift(); continue; }
        break;
      }
    } catch { /* offline: retry on next track/heartbeat */ } finally { flushing = false; }
  }

  async function beat() {
    if (!started || !sessionId) return;
    if (doc && doc.visibilityState === 'hidden') return;
    try {
      const r = await rpc('session_heartbeat', { p_session_id: sessionId });
      if (r.ok && r.data === false) {       // session expired/ended: begin a new one
        if (await beginSession()) await flush();
      } else if (r.ok) {
        await flush();
      }
    } catch { /* ignore */ }
  }

  function onVisibility() {
    if (doc?.visibilityState === 'visible') beat();
  }
  function onPageHide() {
    if (sessionId) rpc('end_session', { p_session_id: sessionId }, { keepalive: true }).catch(() => {});
  }

  return {
    /** Starts (or resumes) a session and records one app_open per browser tab session. */
    async start() {
      if (started || !enabled()) return false;
      try {
        if (!(await beginSession())) return false;
      } catch { return false; }
      started = true;
      let opened = false;
      try { opened = storage.session?.getItem('sp_app_open') === sessionId; } catch { /* ignore */ }
      if (!opened) {
        this.track('app_open');
        try { storage.session?.setItem('sp_app_open', sessionId); } catch { /* ignore */ }
      }
      timer = (env.setInterval ?? setInterval)(beat, heartbeatMs);
      doc?.addEventListener?.('visibilitychange', onVisibility);
      win?.addEventListener?.('pagehide', onPageHide);
      await flush();
      return true;
    },

    /** Queues an event. Unknown event names are ignored; metadata is whitelisted. */
    track(name, metadata = {}) {
      if (!started && name !== 'app_open') return;
      if (!ALLOWED_EVENTS.includes(name) || !enabled()) return;
      if (queue.length >= MAX_QUEUE) queue.shift();
      queue.push({ name, metadata: sanitizeMetadata(metadata) });
      flush();
    },

    /** Call on logout, BEFORE clearing the auth session. */
    async stop() {
      if (!started) return;
      started = false;
      (env.clearInterval ?? clearInterval)(timer);
      doc?.removeEventListener?.('visibilitychange', onVisibility);
      win?.removeEventListener?.('pagehide', onPageHide);
      try {
        if (enabled()) {
          queue.push({ name: 'logout', metadata: {} });
          await flush();
        }
        if (sessionId) await rpc('end_session', { p_session_id: sessionId });
      } catch { /* ignore */ }
      queue.length = 0;
      sessionId = null;
    },

    /** Wire this to a privacy settings toggle. */
    setConsent(granted) {
      storage.setItem(CONSENT_KEY, granted ? 'granted' : 'denied');
      if (!granted) { queue.length = 0; }
    },
    getConsent: () => storage.getItem(CONSENT_KEY),
    isEnabled: enabled,
    _debug: { queue, get sessionId() { return sessionId; } },
  };
}

function safeStorage() {
  try {
    const ls = globalThis.localStorage;
    const ss = globalThis.sessionStorage;
    ls.getItem('x');
    return { getItem: (k) => ls.getItem(k), setItem: (k, v) => ls.setItem(k, v), session: ss };
  } catch {
    const mem = new Map();
    return { getItem: (k) => mem.get(k) ?? null, setItem: (k, v) => mem.set(k, v), session: null };
  }
}
