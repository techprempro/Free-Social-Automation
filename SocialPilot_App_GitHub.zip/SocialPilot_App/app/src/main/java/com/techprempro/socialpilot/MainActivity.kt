package com.techprempro.socialpilot

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import java.util.concurrent.Executors

/**
 * SocialPilot AI owner app: shows the owner panel (https://techprempro.com/socialpilot) and reports
 * "app opened" to /api/socialpilot/active-user, the same way the other TechPremPro apps do.
 */
class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val trackingExecutor = Executors.newSingleThreadExecutor()

    private companion object {
        const val HOST = "techprempro.com"
        const val PANEL_URL = "https://techprempro.com/socialpilot"
        const val TRACK_URL = "https://techprempro.com/api/socialpilot/active-user"
        const val APP_VERSION = "1.0"
    }

    /** Random id created once per install (not derived from ANDROID_ID). Uninstalling the app resets it. */
    private fun installationId(): String {
        val prefs = getSharedPreferences("app_tracking", MODE_PRIVATE)
        return prefs.getString("installation_id", null) ?: UUID.randomUUID().toString().also {
            prefs.edit().putString("installation_id", it).apply()
        }
    }

    private fun reportActiveDevice() {
        val id = installationId()
        val deviceName = "${Build.MANUFACTURER} ${Build.MODEL}".take(150)
        trackingExecutor.execute {
            var connection: HttpURLConnection? = null
            try {
                val payload = JSONObject().apply {
                    put("installation_id", id)
                    put("device_name", deviceName)
                    put("platform", "android")
                    put("app_version", APP_VERSION)
                }
                connection = (URL(TRACK_URL).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 15000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    setRequestProperty("Accept", "application/json")
                }
                connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val status = connection.responseCode
                if (status !in 200..299) Log.w("ActiveDeviceTracking", "Tracking API returned HTTP $status")
            } catch (e: Exception) {
                Log.w("ActiveDeviceTracking", "Could not report active device", e) // tracking is optional
            } finally {
                connection?.disconnect()
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        reportActiveDevice()
        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true      // the panel is a script-driven page
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.scheme == "https" && uri.host == HOST) return false // stay inside the app
                return try { // everything else opens in the browser; the owner token never leaves techprempro.com
                    if (uri.scheme == "https" || uri.scheme == "http") startActivity(Intent(Intent.ACTION_VIEW, uri))
                    true
                } catch (_: Exception) {
                    true
                }
            }
        }

        if (savedInstanceState != null) webView.restoreState(savedInstanceState) else webView.loadUrl(PANEL_URL)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (::webView.isInitialized) webView.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        trackingExecutor.shutdown()
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }
}
