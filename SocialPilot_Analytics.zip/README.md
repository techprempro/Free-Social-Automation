# SocialPilot AI — Usage Analytics (Phase 9)

Private owner/admin analytics for the Android app and web dashboard: Supabase SQL migrations
(tables, indexes, RLS, admin-only report functions), a protected analytics API, the
`/admin/analytics` dashboard, and web + Android event trackers.

Start with **[SETUP.md](SETUP.md)**. Privacy policy text: `docs/privacy-policy-analytics-section.md`.

Run all tests (needs a disposable Postgres 15+): `./scripts/test-all.sh`
