# Privacy Policy — "Usage analytics" section

> Paste into the SocialPilot AI privacy policy and have it reviewed by counsel for
> the jurisdictions you serve (GDPR/UK GDPR, CCPA/CPRA, etc.). This is a template,
> not legal advice. Bracketed items need your input.

## Usage analytics

We collect limited usage information from the SocialPilot AI Android app and web
dashboard so we can keep the service running, understand which features are used,
fix problems and plan improvements.

**What we collect**

- **Account and activity facts:** your user ID, the date you registered, when you were last active, and how many sessions you have had.
- **Session information:** when a session starts, when it was last active and when it ended, and whether it happened on Android or the web.
- **Feature events:** simple records that an action happened, such as opening the app, logging in or out, creating or saving a draft, scheduling or publishing a post, using an AI generation feature, or connecting a social account. For some events we record a non-sensitive label, for example the social network involved or the post type.
- **App and device basics (Android):** app version, Android version and device model.
- **App version (web):** the web app version.

**What we do not collect through analytics**

- The content of your posts, drafts, captions or images.
- The text of your AI prompts or the AI's responses.
- Your contacts, messages, location, advertising ID or other unrelated device data.
- Passwords or access tokens.

**Why we use it** — [legal basis, e.g. our legitimate interest in operating and improving the service / your consent where required].

**Who can see it** — Aggregated reports and per-account usage facts (such as registration date, last active time and session count) are visible only to authorized SocialPilot administrators through a protected dashboard. Other users can never see your analytics. We do not sell this data or use it for advertising.

**Your choices** — You can turn usage analytics off in [Settings → Privacy → Usage analytics] in the app and on the web. We also honor browser Do Not Track and Global Privacy Control signals on the web. Turning analytics off stops new events from being recorded. [Where consent is required, analytics stay off until you opt in.]

**Retention** — Event and session records are kept for [13 months] and then deleted or aggregated. When you delete your account, your analytics records are deleted with it.

**Your rights** — Depending on where you live you may have the right to access, correct, delete or export your data, to object to or restrict processing, and to withdraw consent. Contact us at [privacy contact email].
