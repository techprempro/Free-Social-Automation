// Dependency-free SVG charts (line + bar) with crosshair/tooltip, legend and a
// data-table fallback. All text is inserted with textContent (never innerHTML).

const NS = 'http://www.w3.org/2000/svg';
const nf = new Intl.NumberFormat('en-US');

function svgEl(name, attrs = {}, parent) {
  const e = document.createElementNS(NS, name);
  for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, String(v));
  if (parent) parent.appendChild(e);
  return e;
}

function h(tag, props = {}, children = []) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') e.className = v;
    else if (k === 'text') e.textContent = v;
    else e.setAttribute(k, v);
  }
  for (const c of children) e.appendChild(c);
  return e;
}

export function fmtDate(ymd) {
  const [y, m, d] = ymd.split('-').map(Number);
  return new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' })
    .format(new Date(Date.UTC(y, m - 1, d)));
}

function niceMax(v) {
  if (v <= 4) return 4;
  const pow = 10 ** Math.floor(Math.log10(v));
  for (const m of [1, 2, 2.5, 5, 10]) if (v <= m * pow) return m * pow;
  return 10 * pow;
}

/**
 * spec: { labels: string[], series: [{name, color, values: number[]}],
 *         kind: 'line'|'bar', xLabel?: (l)=>string, height?: number, title: string }
 */
export function renderChart(container, spec) {
  container.replaceChildren();
  const { labels, series, kind = 'line', height = 220 } = spec;
  const xLabel = spec.xLabel ?? ((l) => l);

  if (!labels.length) {
    container.appendChild(h('p', { class: 'empty', text: 'No data for this range.' }));
    return;
  }

  // legend: always for >= 2 series, none for a single series (card title names it)
  if (series.length >= 2) {
    const legend = h('div', { class: 'legend' });
    for (const s of series) {
      const sw = h('span', { class: 'swatch' });
      sw.style.background = s.color;
      legend.appendChild(h('span', { class: 'legend-item' }, [sw, h('span', { text: s.name })]));
    }
    container.appendChild(legend);
  }

  const wrap = h('div', { class: 'plot' });
  container.appendChild(wrap);
  const tip = h('div', { class: 'tooltip', role: 'status' });
  tip.hidden = true;
  wrap.appendChild(tip);

  const width = Math.max(wrap.clientWidth || container.clientWidth || 320, 240);
  const m = { l: 44, r: 12, t: 10, b: 26 };
  const iw = width - m.l - m.r;
  const ih = height - m.t - m.b;
  const max = niceMax(Math.max(0, ...series.flatMap((s) => s.values)));
  const n = labels.length;
  const x = kind === 'bar'
    ? (i) => m.l + (iw / n) * (i + 0.5)
    : (i) => m.l + (n === 1 ? iw / 2 : (iw * i) / (n - 1));
  const y = (v) => m.t + ih - (v / max) * ih;

  const svg = svgEl('svg', {
    viewBox: `0 0 ${width} ${height}`, width, height, role: 'img',
    'aria-label': spec.title,
  }, wrap);

  // grid + y axis labels
  for (let i = 0; i <= 4; i++) {
    const v = (max / 4) * i;
    svgEl('line', { x1: m.l, x2: width - m.r, y1: y(v), y2: y(v), class: i === 0 ? 'axis' : 'gridline' }, svg);
    const t = svgEl('text', { x: m.l - 8, y: y(v) + 4, class: 'tick', 'text-anchor': 'end' }, svg);
    t.textContent = nf.format(Math.round(v * 10) / 10);
  }
  // x axis labels (~6)
  const step = Math.max(1, Math.ceil(n / 6));
  for (let i = 0; i < n; i += step) {
    const t = svgEl('text', { x: x(i), y: height - 6, class: 'tick', 'text-anchor': 'middle' }, svg);
    t.textContent = xLabel(labels[i]);
  }

  if (kind === 'bar') {
    const s = series[0];
    const bw = Math.min(24, (iw / n) * 0.7);
    s.values.forEach((v, i) => {
      if (v <= 0) return;
      const top = y(v);
      const base = y(0);
      const r = Math.min(4, bw / 2, base - top);
      const x0 = x(i) - bw / 2;
      svgEl('path', {
        d: `M${x0},${base} V${top + r} Q${x0},${top} ${x0 + r},${top} H${x0 + bw - r} Q${x0 + bw},${top} ${x0 + bw},${top + r} V${base} Z`,
        fill: s.color,
      }, svg);
    });
  } else {
    series.forEach((s) => {
      if (n === 1) {
        svgEl('circle', { cx: x(0), cy: y(s.values[0]), r: 4, fill: s.color }, svg);
        return;
      }
      const d = s.values.map((v, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(' ');
      svgEl('path', { d, fill: 'none', stroke: s.color, 'stroke-width': 2, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }, svg);
    });
  }

  // hover layer: crosshair, markers, tooltip
  const cross = svgEl('line', { y1: m.t, y2: m.t + ih, class: 'crosshair', visibility: 'hidden' }, svg);
  const dots = series.map((s) => svgEl('circle', { r: 4.5, fill: s.color, class: 'dot', visibility: 'hidden' }, svg));
  const hit = svgEl('rect', { x: m.l, y: m.t, width: iw, height: ih, fill: 'transparent' }, svg);

  function show(i) {
    cross.setAttribute('x1', x(i)); cross.setAttribute('x2', x(i)); cross.setAttribute('visibility', 'visible');
    dots.forEach((d, k) => {
      d.setAttribute('cx', x(i)); d.setAttribute('cy', y(series[k].values[i]));
      d.setAttribute('visibility', kind === 'line' ? 'visible' : 'hidden');
    });
    tip.replaceChildren(h('div', { class: 'tip-title', text: xLabel(labels[i]) }));
    for (const s of series) {
      const sw = h('span', { class: 'swatch' });
      sw.style.background = s.color;
      tip.appendChild(h('div', { class: 'tip-row' }, [sw, h('span', { text: `${s.name}: ` }), h('strong', { text: nf.format(s.values[i]) })]));
    }
    tip.hidden = false;
    const px = x(i);
    tip.style.left = `${Math.min(Math.max(px + 12, 0), width - 170)}px`;
    tip.style.top = '8px';
  }
  function hide() {
    cross.setAttribute('visibility', 'hidden');
    dots.forEach((d) => d.setAttribute('visibility', 'hidden'));
    tip.hidden = true;
  }
  hit.addEventListener('pointermove', (ev) => {
    const box = svg.getBoundingClientRect();
    const px = ((ev.clientX - box.left) / box.width) * width;
    let i = kind === 'bar' ? Math.floor(((px - m.l) / iw) * n) : Math.round(((px - m.l) / iw) * (n - 1));
    i = Math.min(Math.max(i, 0), n - 1);
    show(i);
  });
  hit.addEventListener('pointerleave', hide);

  // table view (accessibility + relief for low-contrast hues)
  const table = h('table', { class: 'data' });
  const head = h('tr', {}, [h('th', { text: 'Date' }), ...series.map((s) => h('th', { text: s.name }))]);
  table.appendChild(h('thead', {}, [head]));
  const body = h('tbody');
  labels.forEach((l, i) => body.appendChild(h('tr', {}, [h('td', { text: xLabel(l) }), ...series.map((s) => h('td', { text: nf.format(s.values[i]) }))])));
  table.appendChild(body);
  container.appendChild(h('details', { class: 'table-view' }, [h('summary', { text: 'View as table' }), h('div', { class: 'table-scroll' }, [table])]));
}
