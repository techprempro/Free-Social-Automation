// Owner/Admin analytics dashboard. Security notes:
//  * This script holds no secrets. The access token lives in sessionStorage
//    (cleared when the tab closes) and is sent only to this site's own API.
//  * Hiding the page is NOT the protection: every API call is verified
//    server-side (token -> admin check in Postgres). A non-admin who signs in
//    here only ever sees "not authorized".
//  * All user-controlled strings (names, emails) are rendered with textContent.

import { renderChart, fmtDate } from './charts.js';

const cfg = window.__CONFIG__;
const API = '/api/admin/analytics';
const TZ = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
const nf = new Intl.NumberFormat('en-US');
const $ = (id) => document.getElementById(id);
const css = (name) => getComputedStyle(document.documentElement).getPropertyValue(name).trim();

const state = { range: '30d', from: '', to: '', bucket: 'week', page: 1, pageSize: 25, lastData: null };

/* ------------------------------------------------------------------ auth */
const TOKEN_KEY = 'sp_admin_session';
function loadSession() {
  try { return JSON.parse(sessionStorage.getItem(TOKEN_KEY) || 'null'); } catch { return null; }
}
function saveSession(s) {
  try { sessionStorage.setItem(TOKEN_KEY, JSON.stringify(s)); } catch { /* private mode */ }
}
function clearSession() {
  try { sessionStorage.removeItem(TOKEN_KEY); } catch { /* ignore */ }
}

async function authRequest(path, body) {
  const res = await fetch(`${cfg.supabaseUrl}/auth/v1/${path}`, {
    method: 'POST',
    headers: { apikey: cfg.anonKey, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json.error_description || json.msg || 'Sign-in failed');
  return { access: json.access_token, refresh: json.refresh_token, email: json.user?.email ?? '' };
}

async function refreshSession() {
  const s = loadSession();
  if (!s?.refresh) return false;
  try {
    const next = await authRequest('token?grant_type=refresh_token', { refresh_token: s.refresh });
    saveSession({ ...s, access: next.access, refresh: next.refresh });
    return true;
  } catch { return false; }
}

class AuthError extends Error {}
class ForbiddenError extends Error {}

async function api(path, params = {}, retry = true) {
  const s = loadSession();
  if (!s) throw new AuthError('signed out');
  const qs = new URLSearchParams(params);
  const res = await fetch(`${API}/${path}?${qs}`, { headers: { Authorization: `Bearer ${s.access}` } });
  if (res.status === 401) {
    if (retry && (await refreshSession())) return api(path, params, false);
    throw new AuthError('session expired');
  }
  if (res.status === 403) throw new ForbiddenError('not authorized');
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.message || `Request failed (${res.status})`);
  }
  return res.json();
}

function showLogin(message) {
  $('app').hidden = true;
  $('login').hidden = false;
  const err = $('login-error');
  err.hidden = !message;
  err.textContent = message || '';
}

function signOut(message) {
  clearSession();
  showLogin(message);
}

/* ---------------------------------------------------------------- helpers */
function rangeParams() {
  const p = { range: state.range, tz: TZ };
  if (state.range === 'custom') { p.from = state.from; p.to = state.to; }
  return p;
}

function fmtDuration(sec) {
  sec = Math.round(Number(sec) || 0);
  if (sec < 60) return `${sec}s`;
  const m = Math.floor(sec / 60);
  if (m < 60) return `${m}m ${sec % 60}s`;
  return `${Math.floor(m / 60)}h ${m % 60}m`;
}

function fmtDateTime(iso) {
  if (!iso) return '—';
  return new Intl.DateTimeFormat('en-GB', { dateStyle: 'medium', timeStyle: 'short', timeZone: TZ }).format(new Date(iso));
}

function el(tag, props = {}, children = []) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') e.className = v; else if (k === 'text') e.textContent = v; else e.setAttribute(k, v);
  }
  for (const c of children) e.appendChild(c);
  return e;
}

function banner(msg) {
  const b = $('banner');
  b.hidden = !msg;
  b.textContent = msg || '';
}

/* --------------------------------------------------------------- rendering */
function renderCards(o) {
  const items = [
    ['Registered users', o.total_registered_users, 'Unique accounts'],
    ['Android app users', o.android_users, 'Used the Android app'],
    ['Web users', o.web_users, `${nf.format(o.users_on_both)} use both`],
    ['Active today', o.active_today, 'Unique users'],
    ['Active last 7 days', o.active_7d, 'Unique users'],
    ['Active last 30 days', o.active_30d, 'Unique users'],
    ['New today', o.new_today, 'Registrations'],
    ['New this week', o.new_this_week, 'Since Monday'],
    ['New this month', o.new_this_month, 'Registrations'],
    ['Online now (estimate)', o.online_now_estimate, 'Heartbeat in last 2.5 min'],
    ['Total sessions', o.total_sessions, 'All time'],
    ['Avg session duration', fmtDuration(o.avg_session_seconds), 'Capped at 4h per session'],
    ['Posts created', o.posts_created, 'Tracked events'],
    ['Posts published', o.posts_published, 'Tracked events'],
    ['Posts scheduled', o.posts_scheduled, 'Tracked events'],
  ];
  const root = $('cards');
  root.replaceChildren(...items.map(([label, value, hint]) => el('div', { class: 'card stat' }, [
    el('div', { class: 'label', text: label }),
    el('div', { class: 'value', text: typeof value === 'number' ? nf.format(value) : String(value) }),
    el('div', { class: 'hint', text: hint }),
  ])));
  $('as-of').textContent = `As of ${fmtDateTime(o.as_of)} · timezone ${o.timezone}`;
}

function drawCharts() {
  const d = state.lastData;
  if (!d) return;
  const c1 = css('--series-1'); const c2 = css('--series-2'); const c3 = css('--series-3'); const c4 = css('--series-4');
  const days = d.daily.rows;
  const labels = days.map((r) => r.day);

  renderChart($('c-dau'), { title: 'Daily active users', labels, xLabel: fmtDate, series: [{ name: 'Active users', color: c1, values: days.map((r) => r.active_users) }] });
  renderChart($('c-platform-dau'), { title: 'Android vs Web daily active users', labels, xLabel: fmtDate, series: [
    { name: 'Android', color: c1, values: days.map((r) => r.android_active_users) },
    { name: 'Web', color: c2, values: days.map((r) => r.web_active_users) },
  ] });
  renderChart($('c-reg'), { title: 'New registrations per day', kind: 'bar', labels, xLabel: fmtDate, series: [{ name: 'New users', color: c1, values: days.map((r) => r.new_users) }] });
  renderChart($('c-posts'), { title: 'Posts created vs published per day', labels, xLabel: fmtDate, series: [
    { name: 'Created', color: c1, values: days.map((r) => r.posts_created) },
    { name: 'Published', color: c2, values: days.map((r) => r.posts_published) },
  ] });

  const trend = [['login', 'Logins', c1], ['post_created', 'Posts created', c2], ['post_published', 'Posts published', c3], ['ai_generation', 'AI generations', c4]];
  const byKey = new Map(d.events.rows.map((r) => [`${r.day}|${r.event_name}`, r.events]));
  renderChart($('c-events'), { title: 'User activity trends', labels, xLabel: fmtDate, series: trend.map(([key, name, color]) => ({
    name, color, values: labels.map((l) => byKey.get(`${l}|${key}`) ?? 0),
  })) });

  drawGrowth();
  renderPlatformTable(d.platforms.rows);
  renderDevices(d.devices);
}

function drawGrowth() {
  const g = state.lastData?.growth;
  if (!g) return;
  const labels = g.rows.map((r) => r.bucket_start);
  const fmt = state.bucket === 'month'
    ? (l) => { const [y, m] = l.split('-').map(Number); return new Intl.DateTimeFormat('en-US', { month: 'short', year: '2-digit', timeZone: 'UTC' }).format(new Date(Date.UTC(y, m - 1, 1))); }
    : (l) => `Wk ${fmtDate(l)}`;
  renderChart($('c-growth-new'), { title: 'New users', kind: 'bar', labels, xLabel: fmt, series: [{ name: 'New users', color: css('--series-1'), values: g.rows.map((r) => r.new_users) }] });
  renderChart($('c-growth-total'), { title: 'Total registered users', labels, xLabel: fmt, series: [{ name: 'Registered users', color: css('--series-1'), values: g.rows.map((r) => r.cumulative_users) }] });
}

function renderPlatformTable(rows) {
  const t = $('t-platforms');
  const head = ['Platform', 'Total users', 'Active in range', 'Sessions', 'Avg session', 'Events'];
  const thead = el('thead', {}, [el('tr', {}, head.map((x, i) => el('th', { class: i ? 'num' : '', text: x })))]);
  const tbody = el('tbody', {}, rows.map((r) => el('tr', {}, [
    el('td', { text: r.platform === 'android' ? 'Android' : 'Web' }),
    el('td', { class: 'num', text: nf.format(r.total_users) }),
    el('td', { class: 'num', text: nf.format(r.active_users) }),
    el('td', { class: 'num', text: nf.format(r.sessions) }),
    el('td', { class: 'num', text: fmtDuration(r.avg_session_seconds) }),
    el('td', { class: 'num', text: nf.format(r.events) }),
  ])));
  t.replaceChildren(thead, tbody);
}

function miniTable(title, rows, cols) {
  const table = el('table', { class: 'data' }, [
    el('thead', {}, [el('tr', {}, cols.map((c, i) => el('th', { class: i ? 'num' : '', text: c.label })))]),
    el('tbody', {}, rows.length
      ? rows.map((r) => el('tr', {}, cols.map((c, i) => el('td', { class: i ? 'num' : '', text: String(c.get(r)) }))))
      : [el('tr', {}, [el('td', { text: 'No data yet' })])]),
  ]);
  return el('article', { class: 'card' }, [el('h3', { text: title }), el('div', { class: 'table-scroll' }, [table])]);
}

function renderDevices(dev) {
  const label = (p) => (p === 'android' ? 'Android' : 'Web');
  $('devices').replaceChildren(
    miniTable('App version', dev.app_versions, [
      { label: 'Platform · version', get: (r) => `${label(r.platform)} · ${r.app_version}` },
      { label: 'Users', get: (r) => nf.format(r.users) },
    ]),
    miniTable('Android OS version', dev.android_os_versions, [
      { label: 'Android', get: (r) => r.os_version },
      { label: 'Users', get: (r) => nf.format(r.users) },
    ]),
    miniTable('Android device model (top 20)', dev.android_device_models, [
      { label: 'Model', get: (r) => r.device_model },
      { label: 'Users', get: (r) => nf.format(r.users) },
    ]),
  );
}

function renderUsers(res) {
  const tbody = document.querySelector('#t-users tbody');
  tbody.replaceChildren(...res.rows.map((u) => el('tr', {}, [
    el('td', { class: 'mono', text: u.user_id }),
    el('td', { text: u.display_name || '—' }),
    el('td', { text: u.email || '—' }),
    el('td', { text: fmtDateTime(u.registered_at) }),
    el('td', { text: fmtDateTime(u.last_active_at) }),
    el('td', { text: { android: 'Android', web: 'Web', both: 'Android + Web', unknown: '—' }[u.platform] ?? u.platform }),
    el('td', { text: u.app_version || '—' }),
    el('td', { class: 'num', text: nf.format(u.total_sessions) }),
    el('td', {}, [el('span', { class: `status ${u.status}`, text: u.status })]),
  ])));
  if (!res.rows.length) tbody.replaceChildren(el('tr', {}, [el('td', { colspan: 9, text: 'No users match.' })]));
  const first = res.total ? (res.page - 1) * res.pageSize + 1 : 0;
  const last = Math.min(res.page * res.pageSize, res.total);
  $('user-count').textContent = `${nf.format(first)}–${nf.format(last)} of ${nf.format(res.total)} users`;
  $('prev').disabled = res.page <= 1;
  $('next').disabled = res.page * res.pageSize >= res.total;
}

/* ---------------------------------------------------------------- loading */
async function loadUsers() {
  const res = await api('users', {
    q: $('q').value.trim(), platform: $('f-platform').value, status: $('f-status').value,
    sort: $('f-sort').value, page: state.page, pageSize: state.pageSize,
  });
  renderUsers(res);
}

async function loadGrowth() {
  state.lastData.growth = await api('growth', { bucket: state.bucket, tz: TZ });
  drawGrowth();
}

async function loadAll() {
  banner('');
  try {
    const rp = rangeParams();
    const [overview, daily, platforms, events, devices, growth] = await Promise.all([
      api('overview', { tz: TZ }),
      api('daily', rp), api('platforms', rp), api('events', rp), api('devices'),
      api('growth', { bucket: state.bucket, tz: TZ }),
    ]);
    state.lastData = { daily, platforms, events, devices, growth };
    renderCards(overview);
    $('range-label').textContent = `${daily.range.from} to ${daily.range.to} (${TZ})`;
    drawCharts();
    await loadUsers();
  } catch (err) {
    if (err instanceof AuthError) return signOut('Your session expired. Please sign in again.');
    if (err instanceof ForbiddenError) return signOut('This account is not authorized to view analytics.');
    banner(err.message || 'Could not load analytics.');
  }
}

/* ------------------------------------------------------------------- boot */
async function enter() {
  // Ask the server whether this user is an admin before showing anything.
  try {
    await api('me');
  } catch (err) {
    if (err instanceof ForbiddenError) return signOut('This account is not authorized to view analytics.');
    if (err instanceof AuthError) return showLogin('');
    return showLogin(err.message);
  }
  $('login').hidden = true;
  $('app').hidden = false;
  $('who').textContent = loadSession()?.email ?? '';
  await loadAll();
}

$('login-form').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  try {
    const s = await authRequest('token?grant_type=password', { email: $('email').value.trim(), password: $('password').value });
    $('password').value = '';
    saveSession(s);
    await enter();
  } catch (err) {
    showLogin(err.message);
  }
});

$('signout').addEventListener('click', () => signOut(''));
$('refresh').addEventListener('click', () => loadAll());

document.querySelectorAll('[data-range]').forEach((btn) => btn.addEventListener('click', () => {
  document.querySelectorAll('[data-range]').forEach((b) => b.setAttribute('aria-pressed', String(b === btn)));
  state.range = btn.dataset.range;
  $('custom-range').hidden = state.range !== 'custom';
  if (state.range !== 'custom') loadAll();
}));

$('custom-range').addEventListener('submit', (ev) => {
  ev.preventDefault();
  state.from = $('from').value; state.to = $('to').value;
  loadAll();
});

document.querySelectorAll('[data-bucket]').forEach((btn) => btn.addEventListener('click', async () => {
  document.querySelectorAll('[data-bucket]').forEach((b) => b.setAttribute('aria-pressed', String(b === btn)));
  state.bucket = btn.dataset.bucket;
  try { await loadGrowth(); } catch (err) { banner(err.message); }
}));

let searchTimer;
function usersChanged() {
  state.page = 1;
  loadUsers().catch((err) => banner(err.message));
}
$('q').addEventListener('input', () => { clearTimeout(searchTimer); searchTimer = setTimeout(usersChanged, 300); });
$('user-filters').addEventListener('submit', (ev) => ev.preventDefault());
['f-platform', 'f-status', 'f-sort'].forEach((id) => $(id).addEventListener('change', usersChanged));
$('prev').addEventListener('click', () => { state.page -= 1; loadUsers().catch((e) => banner(e.message)); });
$('next').addEventListener('click', () => { state.page += 1; loadUsers().catch((e) => banner(e.message)); });

let resizeTimer;
window.addEventListener('resize', () => { clearTimeout(resizeTimer); resizeTimer = setTimeout(drawCharts, 150); });
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', drawCharts);

if (loadSession()) enter(); else showLogin('');
