// Framework-agnostic analytics API. `handle()` takes a plain request description
// and returns {status, headers, body}; index.js adapts it to node:http, and it
// can equally be wrapped in a Next.js / Express / edge route.
//
// Request pipeline for EVERY /api/admin/* path (including unknown ones):
//   1. Bearer token present and well-formed            else 401
//   2. Token verified by Supabase Auth                 else 401
//   3. is_admin() == true, checked in Postgres          else 403
//   4. per-user rate limit                              else 429
//   5. method + query validation                        else 405 / 400
//   6. RPC executed WITH THE CALLER'S JWT (DB re-checks admin; RLS applies)
// Admin status is never taken from the request body, query string or headers.

import { ValidationError, resolveRange, validateTimezone } from './dates.js';
import { UpstreamError } from './supabase.js';

const PLATFORMS = new Set(['android', 'web', 'both', 'unknown']);
const STATUSES = new Set(['active', 'suspended', 'unconfirmed']);
const SORTS = new Set(['registered_desc', 'registered_asc', 'last_active_desc', 'sessions_desc', 'email_asc', 'name_asc']);
const JWT_RE = /^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*$/;
const API_PREFIX = '/api/admin/analytics';

const SECURITY_HEADERS = {
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'no-store',
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
  'X-Robots-Tag': 'noindex, nofollow',
};

const json = (status, body, extra = {}) => ({
  status,
  headers: { ...SECURITY_HEADERS, ...extra },
  body: JSON.stringify(body),
});

function clampInt(raw, { min, max, fallback, name }) {
  if (raw == null || raw === '') return fallback;
  if (!/^\d{1,9}$/.test(raw)) throw new ValidationError(`${name} must be an integer`);
  const n = Number(raw);
  if (n < min || n > max) throw new ValidationError(`${name} must be between ${min} and ${max}`);
  return n;
}

function oneOf(raw, allowed, name) {
  if (raw == null || raw === '') return null;
  if (!allowed.has(raw)) throw new ValidationError(`invalid ${name}`);
  return raw;
}

export function createApp({ supabase, now = () => new Date(), log = console, rateLimitPerMinute = 120 }) {
  const hits = new Map(); // userId -> {count, windowStart}

  function rateLimited(userId) {
    const t = now().getTime();
    const h = hits.get(userId);
    if (!h || t - h.windowStart >= 60_000) {
      hits.set(userId, { count: 1, windowStart: t });
      return false;
    }
    h.count += 1;
    return h.count > rateLimitPerMinute;
  }

  const routes = {
    async me() {
      return { admin: true };
    },
    async overview({ jwt, q }) {
      const tz = validateTimezone(q.get('tz'));
      return supabase.rpc(jwt, 'admin_analytics_overview', { p_tz: tz });
    },
    async daily({ jwt, q }) {
      const tz = validateTimezone(q.get('tz'));
      const r = resolveRange(Object.fromEntries(q), tz, now());
      const rows = await supabase.rpc(jwt, 'admin_analytics_daily', { p_from: r.from, p_to: r.to, p_tz: tz });
      return { range: { ...r, tz }, rows };
    },
    async growth({ jwt, q }) {
      const tz = validateTimezone(q.get('tz'));
      const bucket = oneOf(q.get('bucket'), new Set(['week', 'month']), 'bucket') ?? 'week';
      // growth looks further back by default: 12 weeks / 12 months
      const raw = Object.fromEntries(q);
      if (!raw.range) raw.range = 'custom';
      let r;
      if (raw.range === 'custom' && !raw.from) {
        const today = resolveRange({ range: 'today' }, tz, now());
        const back = bucket === 'week' ? 84 : 365;
        r = resolveRange({ range: 'custom', from: shiftDays(today.to, -back), to: today.to }, tz, now(), 1100);
      } else {
        r = resolveRange(raw, tz, now(), 1100);
      }
      const rows = await supabase.rpc(jwt, 'admin_analytics_growth', {
        p_from: r.from, p_to: r.to, p_bucket: bucket, p_tz: tz,
      });
      return { range: { ...r, tz }, bucket, rows };
    },
    async platforms({ jwt, q }) {
      const tz = validateTimezone(q.get('tz'));
      const r = resolveRange(Object.fromEntries(q), tz, now());
      const rows = await supabase.rpc(jwt, 'admin_analytics_platforms', { p_from: r.from, p_to: r.to, p_tz: tz });
      return { range: { ...r, tz }, rows };
    },
    async events({ jwt, q }) {
      const tz = validateTimezone(q.get('tz'));
      const r = resolveRange(Object.fromEntries(q), tz, now());
      const rows = await supabase.rpc(jwt, 'admin_analytics_event_series', { p_from: r.from, p_to: r.to, p_tz: tz });
      return { range: { ...r, tz }, rows };
    },
    async devices({ jwt }) {
      return supabase.rpc(jwt, 'admin_analytics_devices', {});
    },
    async users({ jwt, q }) {
      const search = (q.get('q') ?? '').trim();
      if (search.length > 100) throw new ValidationError('search too long');
      const platform = oneOf(q.get('platform'), PLATFORMS, 'platform');
      const status = oneOf(q.get('status'), STATUSES, 'status');
      const sort = oneOf(q.get('sort'), SORTS, 'sort') ?? 'registered_desc';
      const page = clampInt(q.get('page'), { min: 1, max: 100000, fallback: 1, name: 'page' });
      const pageSize = clampInt(q.get('pageSize'), { min: 1, max: 100, fallback: 25, name: 'pageSize' });
      const rows = await supabase.rpc(jwt, 'admin_analytics_users', {
        p_search: search || null,
        p_platform: platform,
        p_status: status,
        p_sort: sort,
        p_limit: pageSize,
        p_offset: (page - 1) * pageSize,
      });
      const total = rows.length ? Number(rows[0].total_count) : 0;
      return {
        page, pageSize, total,
        rows: rows.map(({ total_count, ...rest }) => rest), // eslint-disable-line no-unused-vars
      };
    },
  };

  function shiftDays(ymd, n) {
    const d = new Date(`${ymd}T00:00:00Z`);
    d.setUTCDate(d.getUTCDate() + n);
    return d.toISOString().slice(0, 10);
  }

  async function handle({ method, url, headers }) {
    const u = new URL(url, 'http://local');
    if (!u.pathname.startsWith('/api/admin/')) return json(404, { error: 'not_found' });

    // 1. token shape
    const auth = headers.authorization ?? headers.Authorization ?? '';
    const m = /^Bearer (\S+)$/.exec(auth);
    if (!m || m[1].length > 4096 || !JWT_RE.test(m[1])) {
      return json(401, { error: 'unauthenticated' }, { 'WWW-Authenticate': 'Bearer' });
    }
    const jwt = m[1];

    try {
      // 2. verify the token with Supabase Auth
      const user = await supabase.getUser(jwt);
      if (!user) return json(401, { error: 'unauthenticated' }, { 'WWW-Authenticate': 'Bearer' });

      // 3. admin check, enforced by Postgres
      const isAdmin = await supabase.rpc(jwt, 'is_admin', {});
      if (isAdmin !== true) {
        log.warn?.(`[admin-analytics] denied user=${user.id} path=${u.pathname}`);
        return json(403, { error: 'forbidden' });
      }

      // 4. rate limit
      if (rateLimited(user.id)) return json(429, { error: 'rate_limited' }, { 'Retry-After': '60' });

      // 5. method + route
      if (method !== 'GET') return json(405, { error: 'method_not_allowed' }, { Allow: 'GET' });
      const name = u.pathname.startsWith(`${API_PREFIX}/`) ? u.pathname.slice(API_PREFIX.length + 1) : '';
      const route = Object.hasOwn(routes, name) ? routes[name] : null;
      if (!route) return json(404, { error: 'not_found' });

      // 6. run as the caller
      const data = await route({ jwt, q: u.searchParams, user });
      return json(200, data);
    } catch (err) {
      if (err instanceof ValidationError) return json(400, { error: 'bad_request', message: err.message });
      if (err instanceof UpstreamError) {
        if (err.code === '42501' || err.status === 403) return json(403, { error: 'forbidden' });
        if (err.code === '22023') return json(400, { error: 'bad_request', message: 'invalid parameter' });
        if (err.status === 401) return json(401, { error: 'unauthenticated' }, { 'WWW-Authenticate': 'Bearer' });
      }
      log.error?.('[admin-analytics] upstream failure', err?.status, err?.code, err?.message);
      return json(502, { error: 'upstream_error' }); // never leak internals
    }
  }

  return { handle };
}
