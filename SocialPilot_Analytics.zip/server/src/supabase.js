// Tiny dependency-free Supabase REST client.
//
// SECURITY MODEL: the API never uses the service-role key. Every database call
// is made with the CALLER's own JWT (plus the public anon key), so Postgres
// itself (is_admin() + RLS + the guard inside each function) is the final
// authority. A bug in this Node layer cannot widen access.

export class UpstreamError extends Error {
  constructor(status, code, message) {
    super(message);
    this.name = 'UpstreamError';
    this.status = status;
    this.code = code;
  }
}

export function createSupabase({ url, anonKey, fetchImpl = fetch, timeoutMs = 10000 }) {
  const base = url.replace(/\/+$/, '');

  async function call(path, { method = 'GET', jwt, body } = {}) {
    const res = await fetchImpl(`${base}${path}`, {
      method,
      headers: {
        apikey: anonKey,
        Authorization: `Bearer ${jwt}`,
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: AbortSignal.timeout(timeoutMs),
    });
    let json = null;
    try {
      json = await res.json();
    } catch { /* empty body */ }
    return { status: res.status, json };
  }

  return {
    /** Verifies the JWT with Supabase Auth. Returns {id,email} or null. */
    async getUser(jwt) {
      const { status, json } = await call('/auth/v1/user', { jwt });
      if (status === 401 || status === 403) return null;
      if (status !== 200 || !json || !json.id) throw new UpstreamError(status, 'auth', 'auth lookup failed');
      return { id: json.id, email: json.email ?? null };
    },

    /** Calls a Postgres function as the caller. Throws UpstreamError on failure. */
    async rpc(jwt, fn, args = {}) {
      const { status, json } = await call(`/rest/v1/rpc/${encodeURIComponent(fn)}`, {
        method: 'POST', jwt, body: args,
      });
      if (status >= 200 && status < 300) return json;
      throw new UpstreamError(status, json?.code ?? 'unknown', json?.message ?? 'rpc failed');
    },
  };
}
