// Date-range + timezone parsing and validation (server-side, never trust the client).

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const TZ_RE = /^(UTC|[A-Za-z_]+(?:\/[A-Za-z0-9_+-]+){1,2})$/;

export class ValidationError extends Error {
  constructor(message) {
    super(message);
    this.name = 'ValidationError';
  }
}

export function validateTimezone(tz) {
  const value = tz == null || tz === '' ? 'UTC' : String(tz);
  if (value.length > 64 || !TZ_RE.test(value)) throw new ValidationError('invalid timezone');
  try {
    new Intl.DateTimeFormat('en-US', { timeZone: value });
  } catch {
    throw new ValidationError('invalid timezone');
  }
  return value;
}

/** "YYYY-MM-DD" of `now` as seen in `tz`. */
export function localToday(now, tz) {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit',
  }).format(now);
}

function parseYmd(s) {
  if (typeof s !== 'string' || !DATE_RE.test(s)) throw new ValidationError('dates must be YYYY-MM-DD');
  const [y, m, d] = s.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  // round-trip rejects 2026-02-31 and similar
  if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== m - 1 || dt.getUTCDate() !== d) {
    throw new ValidationError('invalid calendar date');
  }
  return dt;
}

function fmt(dt) {
  return dt.toISOString().slice(0, 10);
}

export function addDays(ymd, n) {
  const dt = parseYmd(ymd);
  dt.setUTCDate(dt.getUTCDate() + n);
  return fmt(dt);
}

export function daysBetween(from, to) {
  return Math.round((parseYmd(to) - parseYmd(from)) / 86400000);
}

const PRESET_DAYS = { today: 1, '7d': 7, '30d': 30, '90d': 90 };

/**
 * Resolve a range request into concrete inclusive dates in the admin's tz.
 * range = today | 7d | 30d | 90d | custom (needs from+to).
 */
export function resolveRange({ range, from, to }, tz, now = new Date(), maxDays = 366) {
  const today = localToday(now, tz);
  const r = range || '30d';
  let start;
  let end;
  if (r === 'custom') {
    if (!from || !to) throw new ValidationError('custom range needs from and to');
    start = fmt(parseYmd(from));
    end = fmt(parseYmd(to));
    if (end < start) throw new ValidationError('from must be on or before to');
    if (end > today) end = today; // never report the future
    if (end < start) throw new ValidationError('range is entirely in the future');
  } else if (r in PRESET_DAYS) {
    end = today;
    start = addDays(today, -(PRESET_DAYS[r] - 1));
  } else {
    throw new ValidationError('range must be today, 7d, 30d, 90d or custom');
  }
  if (daysBetween(start, end) + 1 > maxDays) throw new ValidationError(`range cannot exceed ${maxDays} days`);
  return { from: start, to: end, range: r };
}
