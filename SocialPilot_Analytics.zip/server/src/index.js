// Standalone server: serves the dashboard at /admin/analytics and the API at
// /api/admin/analytics/*. Zero npm dependencies (Node 20+).
//
//   SUPABASE_URL=https://xxx.supabase.co SUPABASE_ANON_KEY=... node src/index.js
//
// The anon key is PUBLIC by design (it ships in every web/Android client). The
// service-role key is never used or needed here.

import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { createApp } from './app.js';
import { createSupabase } from './supabase.js';

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY;
const PORT = Number(process.env.PORT || 8787);
const HOST = process.env.HOST || '127.0.0.1';

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  console.error('Set SUPABASE_URL and SUPABASE_ANON_KEY');
  process.exit(1);
}

const here = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(here, '..', 'public', 'admin', 'analytics');

// Whitelist (no path joining from user input => no traversal).
const STATIC = {
  '/admin/analytics': ['index.html', 'text/html; charset=utf-8'],
  '/admin/analytics/': ['index.html', 'text/html; charset=utf-8'],
  '/admin/analytics/app.js': ['app.js', 'text/javascript; charset=utf-8'],
  '/admin/analytics/charts.js': ['charts.js', 'text/javascript; charset=utf-8'],
  '/admin/analytics/styles.css': ['styles.css', 'text/css; charset=utf-8'],
};

const PAGE_HEADERS = {
  'Cache-Control': 'no-store',
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'X-Robots-Tag': 'noindex, nofollow',
  'Content-Security-Policy': [
    "default-src 'none'",
    "script-src 'self'",
    "style-src 'self'",
    `connect-src 'self' ${new URL(SUPABASE_URL).origin}`,
    "img-src 'self' data:",
    "base-uri 'none'",
    "form-action 'none'",
    "frame-ancestors 'none'",
  ].join('; '),
};

const supabase = createSupabase({ url: SUPABASE_URL, anonKey: SUPABASE_ANON_KEY });
const app = createApp({ supabase });

const server = http.createServer(async (req, res) => {
  try {
    const { pathname } = new URL(req.url, 'http://local');

    if (pathname === '/admin/analytics/config.js') {
      // public values only
      const body = `window.__CONFIG__=${JSON.stringify({ supabaseUrl: SUPABASE_URL, anonKey: SUPABASE_ANON_KEY })};`;
      res.writeHead(200, { ...PAGE_HEADERS, 'Content-Type': 'text/javascript; charset=utf-8' });
      return res.end(body);
    }

    if (pathname.startsWith('/api/')) {
      const out = await app.handle({ method: req.method, url: req.url, headers: req.headers });
      res.writeHead(out.status, out.headers);
      return res.end(out.body);
    }

    const entry = STATIC[pathname];
    if (entry && (req.method === 'GET' || req.method === 'HEAD')) {
      const data = await readFile(path.join(publicDir, entry[0]));
      res.writeHead(200, { ...PAGE_HEADERS, 'Content-Type': entry[1] });
      return res.end(req.method === 'HEAD' ? undefined : data);
    }

    res.writeHead(404, { 'Content-Type': 'text/plain', 'Cache-Control': 'no-store' });
    res.end('Not found');
  } catch (err) {
    console.error(err);
    res.writeHead(500, { 'Content-Type': 'text/plain' });
    res.end('Server error');
  }
});

server.listen(PORT, HOST, () => console.log(`SocialPilot analytics on http://${HOST}:${PORT}/admin/analytics`));
