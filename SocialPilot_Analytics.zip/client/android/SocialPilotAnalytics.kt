package com.socialpilot.analytics

// SocialPilot AI — Android analytics tracker (privacy-first).
//
// NOTE: written against OkHttp 4.x, kotlinx-coroutines and androidx.lifecycle
// (process). It has not been compiled in the environment where it was authored;
// build it in Android Studio and run the manual test in SETUP.md.
//
// Gradle (app module):
//   implementation("com.squareup.okhttp3:okhttp:4.12.0")
//   implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
//   implementation("androidx.lifecycle:lifecycle-process:2.8.4")
//
// Setup (Application.onCreate):
//   SocialPilotAnalytics.init(
//       context = this,
//       supabaseUrl = BuildConfig.SUPABASE_URL,
//       anonKey = BuildConfig.SUPABASE_ANON_KEY,                  // public anon key
//       accessTokenProvider = { authRepo.currentAccessToken() },  // user's own JWT, or null if signed out
//       requireConsent = false                                    // true where opt-in consent is required
//   )
//   // after sign-in:   SocialPilotAnalytics.track("login", mapOf("method" to "password"))
//   // on logout:       SocialPilotAnalytics.logout()   // BEFORE clearing the auth session
//
// What is collected: event name, app version, OS version (Build.VERSION.RELEASE),
// device model (Build.MODEL), a session id, whitelisted non-sensitive metadata.
// NOT collected: contacts, messages, location, advertising/Android IDs, IMEI,
// post content, AI prompts, emails or names. The server derives the user id from
// the user's own token; the app never sends a user id.

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object SocialPilotAnalytics : DefaultLifecycleObserver {

    private val ALLOWED_EVENTS = setOf(
        "app_open", "login", "logout", "post_created", "draft_saved",
        "post_scheduled", "post_published", "ai_generation", "account_connected"
    )
    // Must match public.analytics_clean_metadata() in the database.
    private val ALLOWED_METADATA_KEYS =
        setOf("provider", "post_type", "feature", "method", "success", "error_code", "count")

    private const val PREFS = "sp_analytics"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_CONSENT_SET = "consent_set"
    private const val KEY_QUEUE = "queue"
    private const val HEARTBEAT_MS = 30_000L
    private const val MAX_QUEUE = 100

    private lateinit var appContext: Context
    private lateinit var prefs: SharedPreferences
    private lateinit var baseUrl: String
    private lateinit var anonKey: String
    private lateinit var tokenProvider: suspend () -> String?
    private var requireConsent = false
    private var appVersion: String? = null

    private val http = OkHttpClient.Builder()
        .callTimeout(15, TimeUnit.SECONDS)
        .build()
    private val json = "application/json; charset=utf-8".toMediaType()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lock = Mutex()

    @Volatile private var sessionId: String? = null
    private var heartbeatJob: Job? = null
    private var initialized = false

    fun init(
        context: Context,
        supabaseUrl: String,
        anonKey: String,
        accessTokenProvider: suspend () -> String?,
        requireConsent: Boolean = false,
    ) {
        if (initialized) return
        appContext = context.applicationContext
        prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        this.baseUrl = supabaseUrl.trimEnd('/')
        this.anonKey = anonKey
        this.tokenProvider = accessTokenProvider
        this.requireConsent = requireConsent
        this.appVersion = runCatching {
            appContext.packageManager.getPackageInfo(appContext.packageName, 0).versionName
        }.getOrNull()
        initialized = true
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
    }

    /** Wire to a privacy-settings switch. Disabling also discards queued events. */
    fun setEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_ENABLED, enabled).putBoolean(KEY_CONSENT_SET, true).apply()
        if (!enabled) prefs.edit().remove(KEY_QUEUE).apply()
    }

    fun isEnabled(): Boolean {
        val consentSet = prefs.getBoolean(KEY_CONSENT_SET, false)
        if (requireConsent && !consentSet) return false
        return prefs.getBoolean(KEY_ENABLED, true)
    }

    // ---- lifecycle: app foregrounded / backgrounded ----------------------------

    override fun onStart(owner: LifecycleOwner) {
        if (!isEnabled()) return
        scope.launch {
            ensureSession(isForegroundOpen = true)
            startHeartbeat()
        }
    }

    override fun onStop(owner: LifecycleOwner) {
        // Backgrounding is not the end of a session: the server resumes an open
        // session if the user returns within 30 minutes.
        heartbeatJob?.cancel()
    }

    // ---- public API --------------------------------------------------------------

    fun track(event: String, metadata: Map<String, Any?> = emptyMap()) {
        if (!initialized || !isEnabled() || event !in ALLOWED_EVENTS) return
        enqueue(event, sanitize(metadata))
        scope.launch { flush() }
    }

    /** Call BEFORE clearing the auth session so the token is still valid. */
    fun logout() {
        if (!initialized) return
        scope.launch {
            if (isEnabled()) {
                enqueue("logout", JSONObject())
                flush()
            }
            sessionId?.let { rpc("end_session", JSONObject().put("p_session_id", it)) }
            sessionId = null
            heartbeatJob?.cancel()
        }
    }

    // ---- internals -------------------------------------------------------------

    private fun sanitize(meta: Map<String, Any?>): JSONObject {
        val out = JSONObject()
        for ((k, v) in meta) {
            if (k !in ALLOWED_METADATA_KEYS) continue
            when (v) {
                is String -> if (v.length <= 64) out.put(k, v)
                is Boolean -> out.put(k, v)
                is Int, is Long -> out.put(k, v)
                is Float, is Double -> if (!(v as Number).toDouble().isNaN()) out.put(k, v)
            }
        }
        return out
    }

    private suspend fun ensureSession(isForegroundOpen: Boolean) {
        lock.withLock {
            val existing = sessionId
            if (existing != null) {
                val alive = rpc("session_heartbeat", JSONObject().put("p_session_id", existing))
                if (alive?.trim() == "true") {
                    if (isForegroundOpen) enqueue("app_open", JSONObject())
                    return@withLock
                }
            }
            val body = JSONObject()
                .put("p_platform", "android")
                .put("p_app_version", appVersion ?: JSONObject.NULL)
                .put("p_os_version", Build.VERSION.RELEASE ?: JSONObject.NULL)   // e.g. "14"
                .put("p_device_model", Build.MODEL ?: JSONObject.NULL)           // e.g. "Pixel 8"
            val res = rpc("start_session", body)
            // PostgREST returns a bare JSON string: "uuid"
            sessionId = res?.trim()?.removeSurrounding("\"")?.takeIf { it.length == 36 }
            if (sessionId != null && isForegroundOpen) enqueue("app_open", JSONObject())
        }
        flush()
    }

    private fun startHeartbeat() {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            while (isActive) {
                delay(HEARTBEAT_MS)
                if (!isEnabled()) continue
                val sid = sessionId
                val alive = sid?.let { rpc("session_heartbeat", JSONObject().put("p_session_id", it)) }
                if (alive?.trim() != "true") ensureSession(isForegroundOpen = false) else flush()
            }
        }
    }

    // Offline-tolerant queue persisted in SharedPreferences (event name + safe metadata only).
    @Synchronized
    private fun enqueue(event: String, metadata: JSONObject) {
        val arr = JSONArray(prefs.getString(KEY_QUEUE, "[]"))
        val item = JSONObject().put("n", event).put("m", metadata)
        val trimmed = JSONArray()
        val start = if (arr.length() >= MAX_QUEUE) arr.length() - MAX_QUEUE + 1 else 0
        for (i in start until arr.length()) trimmed.put(arr.get(i))
        trimmed.put(item)
        prefs.edit().putString(KEY_QUEUE, trimmed.toString()).apply()
    }

    @Synchronized
    private fun popQueueHead() {
        val arr = JSONArray(prefs.getString(KEY_QUEUE, "[]"))
        val rest = JSONArray()
        for (i in 1 until arr.length()) rest.put(arr.get(i))
        prefs.edit().putString(KEY_QUEUE, rest.toString()).apply()
    }

    private suspend fun flush() {
        val sid = sessionId ?: return
        while (true) {
            val arr = JSONArray(prefs.getString(KEY_QUEUE, "[]"))
            if (arr.length() == 0) return
            val item = arr.getJSONObject(0)
            val body = JSONObject()
                .put("p_event_name", item.getString("n"))
                .put("p_platform", "android")
                .put("p_app_version", appVersion ?: JSONObject.NULL)
                .put("p_session_id", sid)
                .put("p_metadata", item.getJSONObject("m"))
            val status = rpcStatus("track_event", body)
            when {
                status in 200..299 -> popQueueHead()
                status in 400..499 && status != 429 -> popQueueHead()   // will never succeed: drop
                else -> return                                          // offline / 5xx / 429: retry later
            }
        }
    }

    private suspend fun rpc(fn: String, body: JSONObject): String? = runCatching {
        val token = tokenProvider() ?: return null
        val req = Request.Builder()
            .url("$baseUrl/rest/v1/rpc/$fn")
            .header("apikey", anonKey)
            .header("Authorization", "Bearer $token")
            .post(body.toString().toRequestBody(json))
            .build()
        http.newCall(req).execute().use { if (it.isSuccessful) it.body?.string() else null }
    }.getOrNull()

    private suspend fun rpcStatus(fn: String, body: JSONObject): Int = runCatching {
        val token = tokenProvider() ?: return 401
        val req = Request.Builder()
            .url("$baseUrl/rest/v1/rpc/$fn")
            .header("apikey", anonKey)
            .header("Authorization", "Bearer $token")
            .post(body.toString().toRequestBody(json))
            .build()
        http.newCall(req).execute().use { it.code }
    }.getOrDefault(0)
}
