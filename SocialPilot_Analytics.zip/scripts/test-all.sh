#!/usr/bin/env bash
# Full verification against a DISPOSABLE Postgres 15+ server.
#   PGHOST=... PGPORT=... PGUSER=postgres ./scripts/test-all.sh
# Creates a fresh database, applies the Supabase stub + all migrations, then runs
# SQL tests, unit tests, API end-to-end tests and (if Playwright is installed) browser checks.
# Never point this at a real Supabase project: it creates roles and a fake auth schema.
set -euo pipefail
cd "$(dirname "$0")/.."
DB=${TEST_DB:-sp_ci}
psql -X -q -d postgres -c "drop database if exists $DB" -c "create database $DB"
export PGDATABASE=$DB
psql -X -q -v ON_ERROR_STOP=1 -f tests/sql/supabase_stub.sql
for f in supabase/migrations/*.sql; do psql -X -q -v ON_ERROR_STOP=1 -f "$f" >/dev/null 2>&1; done
echo "== SQL tests"
psql -X -q -t -A -v ON_ERROR_STOP=1 -f tests/sql/analytics_test.sql 2>&1 | grep -E "FAIL|ALL SQL TESTS PASSED"
echo "== Node tests (dates, web tracker, API end-to-end)"
node --test tests/dates.test.js tests/web-tracker.test.js tests/api.e2e.test.js 2>&1 | grep -E "^# (tests|pass|fail)"
if [ "${BROWSER:-0}" = "1" ]; then
  echo "== Browser checks"
  psql -X -q -v ON_ERROR_STOP=1 -f tests/helpers/seed-demo.sql
  node tests/browser/dashboard.check.mjs "${SHOTS:-/tmp}" 2>&1 | grep -E "^(ok|FAIL|ALL|[0-9]+ FAILED)"
fi
