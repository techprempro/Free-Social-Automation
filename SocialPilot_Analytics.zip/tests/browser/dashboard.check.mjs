// Browser check of the real dashboard against the Postgres-backed shim.
// Usage: PG* env set, then:  node tests/browser/dashboard.check.mjs <screenshot-dir>
import { spawn, execSync } from 'node:child_process';
import { createRequire } from 'node:module';
import path from 'node:path';
import assert from 'node:assert/strict';
import { startShim, fakeJwt } from '../helpers/pg-supabase-shim.js';

const require = createRequire(import.meta.url);
const { chromium } = require(require.resolve('playwright', { paths: [execSync('npm root -g').toString().trim()] }));
const outDir = process.argv[2] || '.';
const OWNER = '00000000-0000-4000-8000-0000000000aa';
const REGULAR = '00000000-0000-4000-8000-0000000000bb';

const shim = await startShim();
const server = spawn('node', ['server/src/index.js'], {
  env: { ...process.env, SUPABASE_URL: shim.url, SUPABASE_ANON_KEY: 'anon', PORT: '8799' }, stdio: 'inherit',
});
await new Promise((r) => setTimeout(r, 800));
const base = 'http://127.0.0.1:8799';
const browser = await chromium.launch();
let failures = 0;
const check = (name, fn) => fn().then(() => console.log('ok -', name), (e) => { failures++; console.log('FAIL -', name, '\n   ', e.message); });

async function open(token, { width = 1280, height = 900, scheme = 'light' } = {}) {
  const ctx = await browser.newContext({ viewport: { width, height }, colorScheme: scheme, timezoneId: 'Asia/Dhaka' });
  if (token) await ctx.addInitScript((t) => sessionStorage.setItem('sp_admin_session', JSON.stringify({ access: t, refresh: 'r', email: 'x@y.z' })), token);
  const page = await ctx.newPage();
  const errors = []; const dialogs = []; const apiCalls = [];
  page.on('pageerror', (e) => errors.push(e.message));
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  page.on('dialog', (d) => { dialogs.push(d.message()); d.dismiss(); });
  page.on('response', (r) => r.url().includes('/api/admin/') && apiCalls.push(r.status()));
  return { ctx, page, errors, dialogs, apiCalls };
}

await check('admin sees overview, charts, devices and users', async () => {
  const { ctx, page, errors, dialogs } = await open(fakeJwt(OWNER));
  await page.goto(`${base}/admin/analytics`);
  await page.waitForSelector('#cards .stat', { timeout: 15000 });
  await page.waitForSelector('#t-users tbody tr td.mono');
  assert.equal(await page.locator('#cards .stat').count(), 15);
  assert.equal(await page.locator('#login').isVisible(), false, 'sign-in form must be hidden when signed in');
  assert.equal(await page.locator('#custom-range').isVisible(), false, 'custom range hidden until chosen');
  assert.ok((await page.locator('#cards').innerText()).includes('Online now (estimate)'));
  assert.equal(await page.locator('#c-dau svg').count(), 1);
  assert.equal(await page.locator('#c-platform-dau .legend-item').count(), 2);
  assert.equal(await page.locator('#c-events .legend-item').count(), 4);
  assert.equal(await page.locator('#devices .card').count(), 3);
  assert.ok((await page.locator('#t-platforms').innerText()).includes('Android'));
  // hover tooltip
  await page.locator('#c-dau svg').scrollIntoViewIfNeeded();
  const box = await page.locator('#c-dau svg').boundingBox();
  await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
  await page.waitForSelector('#c-dau .tooltip:not([hidden])');
  await page.screenshot({ path: path.join(outDir, 'dashboard-admin-light.png'), fullPage: true });
  // hostile display name is rendered as inert text
  await page.fill('#q', 'regular@');
  await page.waitForFunction(() => document.querySelectorAll('#t-users tbody tr').length === 1 && document.querySelector('#t-users tbody').innerText.includes('regular@example.com'));
  assert.ok((await page.locator('#t-users tbody').innerText()).includes('<img src=x onerror=alert(1)>'));
  assert.equal(await page.locator('#t-users img').count(), 0);
  assert.deepEqual(dialogs, []);
  assert.deepEqual(errors, []);
  await ctx.close();
});

await check('date filters, custom range, growth bucket and user filters work', async () => {
  const { ctx, page, errors } = await open(fakeJwt(OWNER));
  await page.goto(`${base}/admin/analytics`);
  await page.waitForSelector('#cards .stat');
  for (const [range, n] of [['today', 1], ['7d', 7], ['90d', 90], ['30d', 30]]) {
    await page.click(`[data-range="${range}"]`);
    await page.waitForFunction((n) => document.querySelectorAll('#c-dau .table-view tbody tr').length === n, n, { timeout: 8000 }).catch((e) => { throw new Error(`preset ${range} (${e.message.split('\n')[0]})`); });
  }
  await page.click('[data-range="custom"]');
  assert.equal(await page.locator('#custom-range').isVisible(), true);
  await page.fill('#from', '2026-11-01'); await page.fill('#to', '2026-11-10');
  await page.click('#custom-range button[type=submit]');
  await page.waitForFunction(() => document.querySelectorAll('#c-dau .table-view tbody tr').length === 10, null, { timeout: 8000 }).catch((e) => { throw new Error('custom range'); });
  await page.click('[data-bucket="month"]');
  await page.waitForFunction(() => /[A-Z][a-z]{2} \d\d/.test(document.querySelector('#c-growth-new .table-view tbody td')?.textContent ?? ''), null, { timeout: 8000 }).catch(async () => { throw new Error('growth month label: ' + await page.locator('#c-growth-new .table-view tbody td').first().textContent()); });
  await page.selectOption('#f-platform', 'both');
  await page.waitForFunction(() => /of \d+ users/.test(document.querySelector('#user-count').innerText));
  await page.selectOption('#f-platform', '');
  await page.selectOption('#f-status', 'suspended');
  await page.waitForFunction(() => document.querySelector('#user-count').innerText.includes('of 2 users'));
  assert.deepEqual(errors, []);
  await ctx.close();
});

await check('regular (non-admin) user is shown "not authorized" and never sees the dashboard', async () => {
  const { ctx, page, apiCalls } = await open(fakeJwt(REGULAR));
  await page.goto(`${base}/admin/analytics`);
  await page.waitForSelector('#login:not([hidden])');
  assert.ok((await page.locator('#login-error').innerText()).includes('not authorized'));
  assert.equal(await page.locator('#app').isVisible(), false);
  assert.equal(await page.locator('#cards .stat').count(), 0);
  assert.ok(apiCalls.length >= 1 && apiCalls.every((s) => s === 403), `API statuses: ${apiCalls}`);
  assert.equal(await page.evaluate(() => sessionStorage.getItem('sp_admin_session')), null);
  await page.screenshot({ path: path.join(outDir, 'dashboard-nonadmin.png') });
  await ctx.close();
});

await check('signed-out visitor sees only the sign-in form', async () => {
  const { ctx, page, apiCalls } = await open(null);
  await page.goto(`${base}/admin/analytics`);
  await page.waitForSelector('#login:not([hidden])');
  assert.equal(await page.locator('#app').isVisible(), false);
  assert.equal(apiCalls.length, 0);
  await ctx.close();
});

await check('security headers on the page and API', async () => {
  const r = await fetch(`${base}/admin/analytics`);
  assert.match(r.headers.get('content-security-policy'), /script-src 'self'/);
  assert.equal(r.headers.get('x-frame-options'), 'DENY');
  assert.match(r.headers.get('x-robots-tag'), /noindex/);
  const api = await fetch(`${base}/api/admin/analytics/overview`);
  assert.equal(api.status, 401);
  assert.equal(api.headers.get('cache-control'), 'no-store');
  assert.equal((await fetch(`${base}/admin/analytics/../../package.json`)).status, 404);
});

await check('dark mode and phone width render without errors', async () => {
  const dark = await open(fakeJwt(OWNER), { scheme: 'dark' });
  await dark.page.goto(`${base}/admin/analytics`);
  await dark.page.waitForSelector('#cards .stat');
  await dark.page.waitForSelector('#t-users tbody td.mono');
  await dark.page.screenshot({ path: path.join(outDir, 'dashboard-admin-dark.png'), fullPage: true });
  assert.deepEqual(dark.errors, []);
  await dark.ctx.close();
  const phone = await open(fakeJwt(OWNER), { width: 390, height: 800 });
  await phone.page.goto(`${base}/admin/analytics`);
  await phone.page.waitForSelector('#cards .stat');
  await phone.page.waitForSelector('#c-dau svg');
  const overflow = await phone.page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  assert.ok(overflow <= 1, `page scrolls horizontally by ${overflow}px`);
  await phone.page.screenshot({ path: path.join(outDir, 'dashboard-admin-phone.png') });
  assert.deepEqual(phone.errors, []);
  await phone.ctx.close();
});

await browser.close(); server.kill(); await shim.close();
console.log(failures ? `${failures} FAILED` : 'ALL BROWSER CHECKS PASSED');
process.exit(failures ? 1 : 0);
