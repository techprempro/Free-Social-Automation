import test from 'node:test';
import assert from 'node:assert/strict';
import { createAnalytics, sanitizeMetadata, ALLOWED_EVENTS } from '../client/web/analytics.js';

function harness({ token = 'user-jwt', requireConsent = false, nav = {}, failTrack = null, consent = null } = {}) {
  const calls = [];
  const store = new Map(consent ? [['sp_analytics_consent', consent]] : []);
  const sess = new Map();
  const handlers = {};
  const fetch = async (url, init) => {
    const fn = url.split('/rpc/')[1];
    const body = JSON.parse(init.body);
    calls.push({ fn, body, headers: init.headers });
    let status = 200; let data = null;
    if (fn === 'start_session') data = '11111111-1111-1111-1111-111111111111';
    if (fn === 'session_heartbeat') data = true;
    if (fn === 'track_event' && failTrack) status = failTrack;
    return { ok: status < 300, status, json: async () => data };
  };
  const a = createAnalytics(
    { supabaseUrl: 'https://x.supabase.co/', anonKey: 'anon', getAccessToken: async () => token, appVersion: '1.2.3', requireConsent, heartbeatMs: 10 },
    {
      fetch, navigator: nav,
      storage: { getItem: (k) => store.get(k) ?? null, setItem: (k, v) => store.set(k, v), session: { getItem: (k) => sess.get(k) ?? null, setItem: (k, v) => sess.set(k, v) } },
      document: { visibilityState: 'visible', addEventListener: (e, h) => { handlers[e] = h; }, removeEventListener() {} },
      window: { addEventListener: (e, h) => { handlers[e] = h; } },
    },
  );
  return { a, calls, store, handlers };
}
const tick = () => new Promise((r) => setTimeout(r, 30));

test('metadata sanitizer drops free text, nested data and unknown keys', () => {
  assert.deepEqual(
    sanitizeMetadata({ provider: 'facebook', prompt: 'secret', content: 'hello', email: 'a@b.c', nested: { a: 1 }, count: 2, success: true, method: 'x'.repeat(65), arr: [1] }),
    { provider: 'facebook', count: 2, success: true },
  );
  assert.deepEqual(sanitizeMetadata(null), {});
  assert.deepEqual(sanitizeMetadata([1, 2]), {});
});

test('start() opens a session once and records a single app_open', async () => {
  const { a, calls } = harness();
  assert.equal(await a.start(), true);
  assert.equal(await a.start(), false); // second call is a no-op
  await tick();
  assert.equal(calls.filter((c) => c.fn === 'start_session').length, 1);
  const opens = calls.filter((c) => c.fn === 'track_event' && c.body.p_event_name === 'app_open');
  assert.equal(opens.length, 1);
  assert.equal(calls[0].body.p_platform, 'web');
  assert.equal(calls[0].headers.Authorization, 'Bearer user-jwt');
  await a.stop();
});

test('page reload within the same tab does not record a second app_open', async () => {
  const h1 = harness();
  await h1.a.start(); await tick(); await h1.a.stop();
  assert.equal(h1.calls.filter((c) => c.body.p_event_name === 'app_open').length, 1);
});

test('payloads never carry a user id, email or content; metadata is whitelisted', async () => {
  const { a, calls } = harness();
  await a.start();
  a.track('ai_generation', { feature: 'caption', prompt: 'my private prompt', content: 'post body' });
  await tick();
  const ev = calls.find((c) => c.body.p_event_name === 'ai_generation');
  assert.deepEqual(ev.body.p_metadata, { feature: 'caption' });
  const wire = JSON.stringify(calls.map((c) => c.body));
  assert.ok(!/user_id|email|private prompt|post body/.test(wire));
  await a.stop();
});

test('unknown events and pre-start events are ignored', async () => {
  const { a, calls } = harness();
  a.track('post_created'); // before start
  await a.start();
  a.track('hack_the_planet');
  await tick();
  assert.ok(!calls.some((c) => c.body.p_event_name === 'hack_the_planet' || c.body.p_event_name === 'post_created'));
  assert.equal(ALLOWED_EVENTS.length, 9);
  await a.stop();
});

test('no token => nothing is sent (signed-out users are never tracked)', async () => {
  const { a, calls } = harness({ token: null });
  assert.equal(await a.start(), false);
  assert.equal(calls.length, 0);
});

test('consent: opt-in mode stays silent until granted; denial and DNT/GPC always win', async () => {
  const gated = harness({ requireConsent: true });
  assert.equal(await gated.a.start(), false);
  assert.equal(gated.calls.length, 0);
  gated.a.setConsent(true);
  assert.equal(await gated.a.start(), true);
  await gated.a.stop();

  const denied = harness({ consent: 'denied' });
  assert.equal(await denied.a.start(), false);
  assert.equal(denied.calls.length, 0);

  assert.equal(await harness({ nav: { doNotTrack: '1' } }).a.start(), false);
  assert.equal(await harness({ nav: { globalPrivacyControl: true } }).a.start(), false);
});

test('heartbeat fires on an interval and stop() sends logout then ends the session', async () => {
  const { a, calls } = harness();
  await a.start();
  await new Promise((r) => setTimeout(r, 60));
  assert.ok(calls.filter((c) => c.fn === 'session_heartbeat').length >= 2);
  await a.stop();
  const names = calls.map((c) => c.body.p_event_name ?? c.fn);
  assert.ok(names.indexOf('logout') !== -1 && names.indexOf('logout') < names.lastIndexOf('end_session'));
  const n = calls.length;
  await new Promise((r) => setTimeout(r, 40));
  assert.equal(calls.length, n, 'no more traffic after stop');
});

test('server errors: permanent 4xx dropped, transient 5xx retained for retry', async () => {
  const perm = harness({ failTrack: 400 });
  await perm.a.start(); perm.a.track('draft_saved'); await tick();
  assert.equal(perm.a._debug.queue.length, 0);
  await perm.a.stop();

  const transient = harness({ failTrack: 503 });
  await transient.a.start(); transient.a.track('draft_saved'); await tick();
  assert.ok(transient.a._debug.queue.length >= 1);
  await transient.a.stop();
});
