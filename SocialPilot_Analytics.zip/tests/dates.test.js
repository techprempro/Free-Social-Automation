import test from 'node:test';
import assert from 'node:assert/strict';
import { resolveRange, validateTimezone, localToday, addDays, ValidationError } from '../server/src/dates.js';

const NOW = new Date('2026-11-24T20:30:00Z'); // 02:30 on Nov 25 in Dhaka

test('"today" follows the admin timezone, not the server clock', () => {
  assert.equal(localToday(NOW, 'UTC'), '2026-11-24');
  assert.equal(localToday(NOW, 'Asia/Dhaka'), '2026-11-25');
});

test('presets are inclusive calendar-day windows', () => {
  assert.deepEqual(resolveRange({ range: 'today' }, 'UTC', NOW), { from: '2026-11-24', to: '2026-11-24', range: 'today' });
  assert.deepEqual(resolveRange({ range: '7d' }, 'UTC', NOW), { from: '2026-11-18', to: '2026-11-24', range: '7d' });
  assert.equal(resolveRange({ range: '30d' }, 'UTC', NOW).from, '2026-10-26');
  assert.equal(resolveRange({ range: '90d' }, 'UTC', NOW).from, '2026-08-27');
  assert.equal(resolveRange({}, 'UTC', NOW).range, '30d');
});

test('custom ranges: validated, future clamped', () => {
  assert.deepEqual(resolveRange({ range: 'custom', from: '2026-11-01', to: '2026-11-10' }, 'UTC', NOW), { from: '2026-11-01', to: '2026-11-10', range: 'custom' });
  assert.equal(resolveRange({ range: 'custom', from: '2026-11-01', to: '2027-01-01' }, 'UTC', NOW).to, '2026-11-24');
  for (const bad of [
    { range: 'custom' }, { range: 'custom', from: '2026-11-10', to: '2026-11-01' },
    { range: 'custom', from: '2026-02-30', to: '2026-03-01' }, { range: 'custom', from: 'yesterday', to: 'today' },
    { range: 'custom', from: '2027-01-01', to: '2027-02-01' }, { range: 'custom', from: '2024-01-01', to: '2026-11-01' },
    { range: 'bogus' },
  ]) assert.throws(() => resolveRange(bad, 'UTC', NOW), ValidationError, JSON.stringify(bad));
});

test('timezone validation', () => {
  assert.equal(validateTimezone(undefined), 'UTC');
  assert.equal(validateTimezone('Asia/Dhaka'), 'Asia/Dhaka');
  assert.equal(validateTimezone('America/Argentina/Buenos_Aires'), 'America/Argentina/Buenos_Aires');
  for (const bad of ["UTC'; drop", 'Mars/Phobos', '../etc/passwd', 'x'.repeat(100), 'Asia/Dhaka\n']) {
    assert.throws(() => validateTimezone(bad), ValidationError, bad);
  }
});

test('addDays crosses month and year boundaries', () => {
  assert.equal(addDays('2026-03-01', -1), '2026-02-28');
  assert.equal(addDays('2026-12-31', 1), '2027-01-01');
});
