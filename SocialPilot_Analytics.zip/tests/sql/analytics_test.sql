-- ============================================================================
-- SocialPilot AI analytics: SQL test suite (queries, privacy, RLS, security)
--
-- Run against a disposable database that already has the stub + migrations:
--   psql -v ON_ERROR_STOP=1 -d sp_test -f tests/sql/analytics_test.sql
-- Everything runs inside one transaction that is ROLLED BACK at the end.
-- Any failed expectation raises an exception and stops the script.
-- ============================================================================
\set ON_ERROR_STOP on
set client_min_messages = notice;
begin;

-- ---------------------------------------------------------------- helpers --
create schema t;
grant usage on schema t to public;

create table t.ctx (k text primary key, v uuid);
grant all on t.ctx to public;

create function t.eq(label text, actual text, expected text) returns void
language plpgsql as $$
begin
  if actual is distinct from expected then
    raise exception 'FAIL [%]: expected <%>, got <%>', label, expected, actual;
  end if;
  raise notice 'ok - %', label;
end $$;

-- Runs q in the CURRENT role and requires it to fail with the given SQLSTATE.
create function t.expect_error(label text, q text, code text) returns void
language plpgsql as $$
declare ok boolean := false;
begin
  begin
    execute q;
  exception when others then
    if sqlstate = code then
      ok := true;
    else
      raise exception 'FAIL [%]: expected SQLSTATE % but got % (%)', label, code, sqlstate, sqlerrm;
    end if;
  end;
  if not ok then
    raise exception 'FAIL [%]: query unexpectedly succeeded: %', label, q;
  end if;
  raise notice 'ok - % (blocked)', label;
end $$;

create function t.as_user(p uuid) returns void language plpgsql as $$
begin
  perform set_config('role', 'postgres', true);
  perform set_config('request.jwt.claims', json_build_object('sub', p, 'role', 'authenticated')::text, true);
  perform set_config('role', 'authenticated', true);
end $$;

create function t.as_anon() returns void language plpgsql as $$
begin
  perform set_config('role', 'postgres', true);
  perform set_config('request.jwt.claims', '{"role":"anon"}', true);
  perform set_config('role', 'anon', true);
end $$;

create function t.as_super() returns void language plpgsql as $$
begin
  perform set_config('role', 'postgres', true);
  perform set_config('request.jwt.claims', '', true);
end $$;

-- superuser privileges BUT with a user's JWT claims (simulates a SECURITY
-- DEFINER code path acting on behalf of a signed-in user)
create function t.as_super_with_claims(p uuid) returns void language plpgsql as $$
begin
  perform set_config('role', 'postgres', true);
  perform set_config('request.jwt.claims', json_build_object('sub', p)::text, true);
end $$;

create function t.today() returns date language sql stable as
  $$ select (now() at time zone 'UTC')::date $$;

-- ------------------------------------------------------------------ users --
\echo '--- setup'
insert into auth.users (id, email, created_at, raw_user_meta_data, banned_until, email_confirmed_at, deleted_at) values
 ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','alice@example.com', now()-interval '100 days','{"full_name":"Alice Owner"}', null, now(), null),
 ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb','bob@example.com',   now()-interval '100 days','{"full_name":"Bob Builder"}', null, now(), null),
 ('cccccccc-cccc-cccc-cccc-cccccccccccc','carol@example.com', now()-interval '100 days','{"name":"Carol"}',            null, now(), null),
 ('dddddddd-dddd-dddd-dddd-dddddddddddd','dave@example.com',  now(),                    '{}', now()+interval '1 year', now(), null),
 ('eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee','erin@example.com',  now(),                    '{}', null, now(), now()),
 ('ffffffff-ffff-ffff-ffff-ffffffffffff','frank@example.com', now(),                    '{}', null, null,  null),
 ('99999999-9999-9999-9999-999999999999','gina_g@example.com',now()-interval '100 days','{}', null, now(), null);

-- Only the project owner (no JWT => auth.uid() is null) can grant roles.
insert into public.admin_roles (user_id, role) values ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'owner');

-- Historical android devices / sessions / events (inserted directly with fixed ages)
insert into public.user_devices (user_id, platform, first_seen_at, last_seen_at, app_version, os_version, device_model) values
 ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb','android', now()-interval '3 days',  now()-interval '3 days',  '2.4.0','14','Pixel 8'),
 ('cccccccc-cccc-cccc-cccc-cccccccccccc','android', now()-interval '10 days', now()-interval '10 days', '2.3.1','13','Galaxy S23'),
 ('99999999-9999-9999-9999-999999999999','android', now()-interval '5 days',  now()-interval '5 days',  '2.4.0','14','Pixel 8');

insert into public.user_sessions (user_id, platform, app_version, started_at, last_seen_at, ended_at) values
 -- B: 30 min, ended
 ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb','android','2.4.0', now()-interval '3 days',  now()-interval '3 days'  + interval '30 minutes', now()-interval '3 days' + interval '30 minutes'),
 -- C: 60 min, never ended (stale OPEN session: must NOT count as online)
 ('cccccccc-cccc-cccc-cccc-cccccccccccc','android','2.3.1', now()-interval '10 days', now()-interval '10 days' + interval '60 minutes', null),
 -- G: 15 min, ended
 ('99999999-9999-9999-9999-999999999999','android','2.4.0', now()-interval '5 days',  now()-interval '5 days'  + interval '15 minutes', now()-interval '5 days' + interval '15 minutes');

insert into public.analytics_events (user_id, event_name, platform, app_version, created_at) values
 ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb','app_open',      'android','2.4.0', now()-interval '3 days'),
 ('cccccccc-cccc-cccc-cccc-cccccccccccc','app_open',      'android','2.3.1', now()-interval '10 days'),
 ('cccccccc-cccc-cccc-cccc-cccccccccccc','post_created',  'android','2.3.1', now()-interval '10 days'),
 ('cccccccc-cccc-cccc-cccc-cccccccccccc','post_created',  'android','2.3.1', now()-interval '10 days'),
 ('cccccccc-cccc-cccc-cccc-cccccccccccc','post_published','android','2.3.1', now()-interval '10 days'),
 ('99999999-9999-9999-9999-999999999999','app_open',      'android','2.4.0', now()-interval '5 days'),
 ('99999999-9999-9999-9999-999999999999','post_scheduled','android','2.4.0', now()-interval '5 days'),
 -- D only ever logged out: logout is NOT a qualifying activity
 ('dddddddd-dddd-dddd-dddd-dddddddddddd','logout',        'web',    '1.0.0', now()-interval '2 days'),
 -- fixed instant for timezone test: 2020-03-10 20:00 UTC == 2020-03-11 02:00 Asia/Dhaka
 ('99999999-9999-9999-9999-999999999999','login',         'android','2.4.0', timestamptz '2020-03-10 20:00:00+00');

-- ------------------------------------------------------- ingestion (as users)
\echo '--- ingestion as signed-in users'
select t.as_user('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa');
insert into t.ctx select 'a_sess',  public.start_session('web', '1.0.0<script>', null, null);
insert into t.ctx select 'a_sess2', public.start_session('web', null, null, null);  -- null must not erase the known version

select t.eq('repeat app open reuses the open session',
  (select (a.v = b.v)::text from t.ctx a, t.ctx b where a.k='a_sess' and b.k='a_sess2'), 'true');

select public.track_event('app_open',     'web', '1.0.0', (select v from t.ctx where k='a_sess'));
select public.track_event('login',        'web', '1.0.0', (select v from t.ctx where k='a_sess'), '{"method":"password"}');
select public.track_event('post_created', 'web', '1.0.0', (select v from t.ctx where k='a_sess'));
select public.track_event('draft_saved',  'web', '1.0.0', (select v from t.ctx where k='a_sess'));
-- hostile metadata: free text, nested objects, over-long strings must be dropped
select public.track_event('ai_generation','web', '1.0.0', (select v from t.ctx where k='a_sess'),
  jsonb_build_object('provider','openai','feature','caption','success',true,'error_code','x',
                     'prompt','my secret prompt','content','post text here','email','a@b.c',
                     'nested', jsonb_build_object('a',1), 'count', 3,
                     'method', repeat('z', 65)));

select t.as_user('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb');
insert into t.ctx select 'b_sess', public.start_session('web', '1.0.1', null, null);
select public.track_event('app_open',       'web', '1.0.1', (select v from t.ctx where k='b_sess'));
select public.track_event('post_created',   'web', '1.0.1', (select v from t.ctx where k='b_sess'));
select public.track_event('post_scheduled', 'web', '1.0.1', (select v from t.ctx where k='b_sess'));
select public.track_event('post_published', 'web', '1.0.1', (select v from t.ctx where k='b_sess'));

select t.as_super();
select t.eq('app_version sanitized (angle brackets stripped)',
  (select app_version from public.user_devices where user_id='aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa' and platform='web'), '1.0.0script');
select t.eq('metadata whitelist keeps only safe scalar keys',
  (select metadata::text from public.analytics_events where event_name='ai_generation' and platform='web'),
  '{"count": 3, "feature": "caption", "provider": "openai", "success": true, "error_code": "x"}'::jsonb::text);
select t.eq('no prompt/content/email stored anywhere',
  (select count(*) from public.analytics_events where metadata::text ~* '(secret prompt|post text|a@b\.c)')::text, '0');
select t.eq('one device row per (user,platform) after repeated opens',
  (select count(*) from public.user_devices where user_id='aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa')::text, '1');

-- ------------------------------------------------- admin queries (as owner)
\echo '--- admin analytics queries as owner'
select t.as_user('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa');
select t.eq('is_admin() true for owner', public.is_admin()::text, 'true');

-- overview ------------------------------------------------------------------
select t.eq('overview: registered users (deleted excluded)', public.admin_analytics_overview('UTC')->>'total_registered_users', '6');
select t.eq('overview: android users', public.admin_analytics_overview('UTC')->>'android_users', '3');
select t.eq('overview: web users',     public.admin_analytics_overview('UTC')->>'web_users', '2');
select t.eq('overview: users on both', public.admin_analytics_overview('UTC')->>'users_on_both', '1');
select t.eq('overview: active today (distinct)', public.admin_analytics_overview('UTC')->>'active_today', '2');
select t.eq('overview: active 7d (logout not counted)', public.admin_analytics_overview('UTC')->>'active_7d', '3');
select t.eq('overview: active 30d', public.admin_analytics_overview('UTC')->>'active_30d', '4');
select t.eq('overview: new today',  public.admin_analytics_overview('UTC')->>'new_today', '2');
select t.eq('overview: new this week',  public.admin_analytics_overview('UTC')->>'new_this_week', '2');
select t.eq('overview: new this month', public.admin_analytics_overview('UTC')->>'new_this_month', '2');
select t.eq('overview: online now (stale open session excluded)', public.admin_analytics_overview('UTC')->>'online_now_estimate', '2');
select t.eq('overview: total sessions', public.admin_analytics_overview('UTC')->>'total_sessions', '5');
select t.eq('overview: avg session seconds', public.admin_analytics_overview('UTC')->>'avg_session_seconds', '1260.0');
select t.eq('overview: posts created',   public.admin_analytics_overview('UTC')->>'posts_created', '4');
select t.eq('overview: posts published', public.admin_analytics_overview('UTC')->>'posts_published', '2');
select t.eq('overview: posts scheduled', public.admin_analytics_overview('UTC')->>'posts_scheduled', '2');
select t.eq('overview works in Asia/Dhaka', (public.admin_analytics_overview('Asia/Dhaka')->>'total_registered_users'), '6');

-- daily series ----------------------------------------------------------------
select t.eq('daily: zero-filled 30 rows',
  (select count(*) from public.admin_analytics_daily(t.today()-29, t.today(), 'UTC'))::text, '30');
select t.eq('daily today: DAU',
  (select active_users from public.admin_analytics_daily(t.today()-29, t.today(), 'UTC') where day = t.today())::text, '2');
select t.eq('daily today: android/web DAU',
  (select android_active_users||'/'||web_active_users from public.admin_analytics_daily(t.today()-29, t.today(), 'UTC') where day = t.today()), '0/2');
select t.eq('daily today: new users / sessions / logins',
  (select new_users||'/'||sessions||'/'||logins from public.admin_analytics_daily(t.today()-29, t.today(), 'UTC') where day = t.today()), '2/2/1');
select t.eq('daily today: created/drafts/scheduled/published/ai',
  (select posts_created||'/'||drafts_saved||'/'||posts_scheduled||'/'||posts_published||'/'||ai_generations
     from public.admin_analytics_daily(t.today()-29, t.today(), 'UTC') where day = t.today()), '2/1/1/1/1');
select t.eq('daily 3 days ago: android DAU',
  (select android_active_users from public.admin_analytics_daily(t.today()-29, t.today(), 'UTC') where day = t.today()-3)::text, '1');
select t.eq('daily 10 days ago: created/published',
  (select posts_created||'/'||posts_published from public.admin_analytics_daily(t.today()-29, t.today(), 'UTC') where day = t.today()-10), '2/1');
select t.eq('daily: sum of posts_created over range',
  (select sum(posts_created) from public.admin_analytics_daily(t.today()-29, t.today(), 'UTC'))::text, '4');
select t.eq('daily: day with no activity is zero not missing',
  (select active_users from public.admin_analytics_daily(t.today()-29, t.today(), 'UTC') where day = t.today()-1)::text, '0');
select t.expect_error('daily: reversed range rejected', $q$select * from public.admin_analytics_daily(current_date, current_date-1, 'UTC')$q$, '22023');
select t.expect_error('daily: >366 day range rejected', $q$select * from public.admin_analytics_daily(current_date-400, current_date, 'UTC')$q$, '22023');
select t.expect_error('daily: invalid timezone rejected', $q$select * from public.admin_analytics_daily(current_date-1, current_date, 'Mars/Phobos')$q$, '22023');

-- growth ----------------------------------------------------------------------
select t.eq('growth/week: new users sum',
  (select sum(new_users) from public.admin_analytics_growth(t.today()-120, t.today(), 'week', 'UTC'))::text, '6');
select t.eq('growth/week: final cumulative = registered users',
  (select cumulative_users from public.admin_analytics_growth(t.today()-120, t.today(), 'week', 'UTC') order by bucket_start desc limit 1)::text, '6');
select t.eq('growth/month: new users sum',
  (select sum(new_users) from public.admin_analytics_growth(t.today()-120, t.today(), 'month', 'UTC'))::text, '6');
select t.eq('growth/month: final cumulative',
  (select cumulative_users from public.admin_analytics_growth(t.today()-120, t.today(), 'month', 'UTC') order by bucket_start desc limit 1)::text, '6');
select t.eq('growth: cumulative starts from baseline of earlier users',
  (select cumulative_users from public.admin_analytics_growth(t.today()-10, t.today(), 'week', 'UTC') order by bucket_start desc limit 1)::text, '6');
select t.eq('growth: window sum excludes pre-window users',
  (select sum(new_users) from public.admin_analytics_growth(t.today()-10, t.today(), 'week', 'UTC'))::text, '2');
select t.expect_error('growth: bad bucket rejected', $q$select * from public.admin_analytics_growth(current_date-10, current_date, 'year', 'UTC')$q$, '22023');

-- platforms (Android vs Web) --------------------------------------------------
select t.eq('platforms: android row',
  (select total_users||'/'||active_users||'/'||sessions||'/'||avg_session_seconds||'/'||events
     from public.admin_analytics_platforms(t.today()-29, t.today(), 'UTC') where platform='android'), '3/3/3/2100.0/7');
select t.eq('platforms: web row',
  (select total_users||'/'||active_users||'/'||sessions||'/'||avg_session_seconds||'/'||events
     from public.admin_analytics_platforms(t.today()-29, t.today(), 'UTC') where platform='web'), '2/2/2/0.0/10');  -- A:5 + B:4 + D's logout:1

-- event series / trends -------------------------------------------------------
select t.eq('event series: post_created today (events/users)',
  (select events||'/'||users from public.admin_analytics_event_series(t.today()-29, t.today(), 'UTC')
    where day = t.today() and event_name = 'post_created'), '2/2');
select t.eq('timezone: login at 20:00Z counts on 03-10 in UTC',
  (select string_agg(day::text, ',') from public.admin_analytics_event_series('2020-03-10','2020-03-11','UTC') where event_name='login'), '2020-03-10');
select t.eq('timezone: same login counts on 03-11 in Asia/Dhaka',
  (select string_agg(day::text, ',') from public.admin_analytics_event_series('2020-03-10','2020-03-11','Asia/Dhaka') where event_name='login'), '2020-03-11');

-- devices ---------------------------------------------------------------------
select t.eq('devices: android app version distribution',
  (select string_agg(app_version||'='||users, ',' order by users desc, app_version)
     from jsonb_to_recordset(public.admin_analytics_devices()->'app_versions') as x(platform text, app_version text, users int)
    where platform = 'android'), '2.4.0=2,2.3.1=1');
select t.eq('devices: android OS distribution',
  (select string_agg(os_version||'='||users, ',' order by users desc, os_version)
     from jsonb_to_recordset(public.admin_analytics_devices()->'android_os_versions') as x(os_version text, users int)), '14=2,13=1');
select t.eq('devices: top model',
  (select device_model||'='||users from jsonb_to_recordset(public.admin_analytics_devices()->'android_device_models') as x(device_model text, users int) limit 1), 'Pixel 8=2');

-- user list -------------------------------------------------------------------
select t.eq('users: total_count', (select total_count from public.admin_analytics_users() limit 1)::text, '6');
select t.eq('users: search by name', (select string_agg(email, ',') from public.admin_analytics_users('bob builder')), 'bob@example.com');
select t.eq('users: search by email fragment', (select string_agg(email, ',') from public.admin_analytics_users('CAROL@')), 'carol@example.com');
select t.eq('users: search by id', (select string_agg(email, ',') from public.admin_analytics_users('99999999-9999')), 'gina_g@example.com');
select t.eq('users: LIKE wildcard % is literal', (select count(*) from public.admin_analytics_users('a%g'))::text, '0');
select t.eq('users: LIKE wildcard _ is literal', (select count(*) from public.admin_analytics_users('gin_'))::text, '0');
select t.eq('users: literal underscore still matches', (select string_agg(email, ',') from public.admin_analytics_users('a_g')), 'gina_g@example.com');
select t.eq('users: SQL injection string is inert', (select count(*) from public.admin_analytics_users($s$' or 1=1; drop table public.analytics_events; --$s$))::text, '0');
select t.eq('users: platform=both', (select string_agg(email, ',') from public.admin_analytics_users(null,'both')), 'bob@example.com');
select t.eq('users: platform=android', (select string_agg(email, ',' order by email) from public.admin_analytics_users(null,'android')), 'carol@example.com,gina_g@example.com');
select t.eq('users: platform=web', (select string_agg(email, ',') from public.admin_analytics_users(null,'web')), 'alice@example.com');
select t.eq('users: platform=unknown', (select string_agg(email, ',' order by email) from public.admin_analytics_users(null,'unknown')), 'dave@example.com,frank@example.com');
select t.eq('users: status=suspended',   (select string_agg(email, ',') from public.admin_analytics_users(null,null,'suspended')), 'dave@example.com');
select t.eq('users: status=unconfirmed', (select string_agg(email, ',') from public.admin_analytics_users(null,null,'unconfirmed')), 'frank@example.com');
select t.eq('users: deleted user never listed', (select count(*) from public.admin_analytics_users('erin'))::text, '0');
select t.eq('users: B has 2 sessions, platform both, latest app version',
  (select total_sessions||'/'||platform||'/'||app_version from public.admin_analytics_users('bob@')), '2/both/1.0.1');
select t.eq('users: display name from metadata', (select display_name from public.admin_analytics_users('bob@')), 'Bob Builder');
select t.eq('users: never-active user has null last_active (logout ignored)',
  (select (last_active_at is null)::text from public.admin_analytics_users('dave@')), 'true');
select t.eq('users: sort last_active_desc puts never-active last',
  ((select email from public.admin_analytics_users(null,null,null,'last_active_desc') offset 5 limit 1) in ('dave@example.com','frank@example.com'))::text, 'true');
select t.eq('users: pagination returns page but full total',
  (select count(*)||'/'||max(total_count) from public.admin_analytics_users(null,null,null,'email_asc',2,2)), '2/6');
select t.eq('users: email_asc first row', (select email from public.admin_analytics_users(null,null,null,'email_asc',1,0)), 'alice@example.com');
select t.eq('users: limit capped at 100 (no error)', (select count(*) from public.admin_analytics_users(null,null,null,'registered_desc',100000,0))::text, '6');
select t.expect_error('users: invalid sort rejected', $q$select * from public.admin_analytics_users(null,null,null,'password_asc')$q$, '22023');
select t.expect_error('users: invalid platform filter rejected', $q$select * from public.admin_analytics_users(null,'ios')$q$, '22023');
select t.expect_error('users: invalid status filter rejected', $q$select * from public.admin_analytics_users(null,null,'deleted')$q$, '22023');

-- privacy ---------------------------------------------------------------------
select t.eq('privacy: password hash never in user list',
  (select count(*) from public.admin_analytics_users(null,null,null,'registered_desc',100,0) x where x::text like '%SECRET-HASH%')::text, '0');
select t.eq('privacy: password hash never in overview',
  (public.admin_analytics_overview('UTC')::text like '%SECRET-HASH%')::text, 'false');
select t.eq('privacy: user list exposes only the documented columns',
  (select pg_get_function_result(p.oid) from pg_proc p where p.proname = 'admin_analytics_users'),
  'TABLE(total_count bigint, user_id uuid, display_name text, email text, registered_at timestamp with time zone, last_active_at timestamp with time zone, platform text, app_version text, total_sessions integer, status text)');

select t.eq('owner sees all events via admin RLS policy',
  (select count(*) from public.analytics_events)::text, '18');
select t.eq('owner sees all sessions via admin RLS policy',
  (select count(*) from public.user_sessions)::text, '5');

-- ----------------------------------------------- regular user: must be blocked
\echo '--- regular user (bob) must be blocked from every admin report'
select t.as_user('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb');
select t.eq('is_admin() false for regular user', public.is_admin()::text, 'false');
select t.expect_error('overview denied',      $q$select public.admin_analytics_overview('UTC')$q$, '42501');
select t.expect_error('daily denied',         $q$select * from public.admin_analytics_daily(current_date-1, current_date, 'UTC')$q$, '42501');
select t.expect_error('growth denied',        $q$select * from public.admin_analytics_growth(current_date-30, current_date, 'week', 'UTC')$q$, '42501');
select t.expect_error('platforms denied',     $q$select * from public.admin_analytics_platforms(current_date-1, current_date, 'UTC')$q$, '42501');
select t.expect_error('event series denied',  $q$select * from public.admin_analytics_event_series(current_date-1, current_date, 'UTC')$q$, '42501');
select t.expect_error('devices denied',       $q$select public.admin_analytics_devices()$q$, '42501');
select t.expect_error('user list denied',     $q$select * from public.admin_analytics_users()$q$, '42501');
select t.expect_error('internal admin guard not callable', $q$select public.analytics_require_admin()$q$, '42501');
select t.expect_error('internal tz helper not callable',   $q$select public.analytics_check_tz('UTC')$q$, '42501');
select t.expect_error('activity view not readable', $q$select count(*) from public.v_user_activity$q$, '42501');
select t.expect_error('auth.users not readable',    $q$select count(*) from auth.users$q$, '42501');

select t.eq('RLS: user sees only own sessions', (select count(*) from public.user_sessions)::text, '2');
select t.eq('RLS: user sees only own events',   (select count(*) from public.analytics_events)::text, '5');
select t.eq('RLS: user sees only own device rows', (select count(*) from public.user_devices)::text, '2');
select t.eq('RLS: user cannot see other users sessions by id',
  (select count(*) from public.user_sessions where user_id = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa')::text, '0');
select t.eq('RLS: user cannot see admin_roles rows (not even the owner)',
  (select count(*) from public.admin_roles)::text, '0');

select t.expect_error('direct insert into events denied',   $q$insert into public.analytics_events (user_id,event_name,platform) values ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb','app_open','web')$q$, '42501');
select t.expect_error('direct insert into sessions denied', $q$insert into public.user_sessions (user_id,platform) values ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb','web')$q$, '42501');
select t.expect_error('update of own session denied',       $q$update public.user_sessions set ended_at = now()$q$, '42501');
select t.expect_error('delete of own events denied',        $q$delete from public.analytics_events$q$, '42501');
select t.expect_error('self-promotion: insert admin_roles denied', $q$insert into public.admin_roles (user_id, role) values ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb','owner')$q$, '42501');
select t.expect_error('self-promotion: update admin_roles denied', $q$update public.admin_roles set role = 'owner' where user_id = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'$q$, '42501');
select t.expect_error('delete admin_roles denied',          $q$delete from public.admin_roles$q$, '42501');

-- ingestion hardening (as bob)
select t.expect_error('invalid event name rejected',  $q$select public.track_event('drop_tables','web')$q$, '22023');
select t.expect_error('invalid platform rejected',    $q$select public.track_event('app_open','ios')$q$, '22023');
select t.expect_error('invalid platform on session',  $q$select public.start_session('ios')$q$, '22023');

-- bob uses alice's session id: must not attach to it nor touch it
select public.track_event('app_open', 'web', '1.0.1', (select v from t.ctx where k='a_sess'));
select t.eq('foreign session id ignored (event stored without it)',
  (select count(*) from public.analytics_events where session_id = (select v from t.ctx where k='a_sess'))::text, '0');
select t.eq('heartbeat on someone elses session returns false',
  public.session_heartbeat((select v from t.ctx where k='a_sess'))::text, 'false');
select t.eq('heartbeat on unknown session returns false',
  public.session_heartbeat('00000000-0000-0000-0000-000000000001')::text, 'false');
select t.eq('heartbeat on own session returns true',
  public.session_heartbeat((select v from t.ctx where k='b_sess'))::text, 'true');
select public.end_session((select v from t.ctx where k='a_sess'));   -- silently a no-op for a foreign session

select t.as_super();
select t.eq('end_session on foreign session had no effect',
  (select (ended_at is null)::text from public.user_sessions where id = (select v from t.ctx where k='a_sess')), 'true');

-- admin cannot edit own role through the API either
select t.as_user('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa');
select t.expect_error('owner cannot edit admin_roles via API (update)', $q$update public.admin_roles set role = 'admin'$q$, '42501');
select t.expect_error('owner cannot edit admin_roles via API (delete)', $q$delete from public.admin_roles$q$, '42501');

-- trigger: even a privileged code path with a user JWT cannot change roles
select t.as_super_with_claims('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb');
select t.expect_error('guard trigger blocks insert when a JWT user is present',
  $q$insert into public.admin_roles (user_id, role) values ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb','owner')$q$, '42501');
select t.expect_error('guard trigger blocks delete when a JWT user is present',
  $q$delete from public.admin_roles$q$, '42501');

-- anonymous (not signed in) -------------------------------------------------
\echo '--- anonymous caller'
select t.as_anon();
select t.expect_error('anon: overview denied',  $q$select public.admin_analytics_overview('UTC')$q$, '42501');
select t.expect_error('anon: users denied',     $q$select * from public.admin_analytics_users()$q$, '42501');
select t.expect_error('anon: start_session denied', $q$select public.start_session('web')$q$, '42501');
select t.expect_error('anon: track_event denied',   $q$select public.track_event('app_open','web')$q$, '42501');
select t.expect_error('anon: events table denied',  $q$select count(*) from public.analytics_events$q$, '42501');
select t.expect_error('anon: is_admin denied',      $q$select public.is_admin()$q$, '42501');

-- authenticated role but token without a subject
select set_config('role', 'postgres', true);
select set_config('request.jwt.claims', '{"role":"authenticated"}', true);
select set_config('role', 'authenticated', true);
select t.expect_error('no sub claim: start_session rejected', $q$select public.start_session('web')$q$, '42501');
select t.expect_error('no sub claim: admin report rejected',  $q$select public.admin_analytics_overview('UTC')$q$, '42501');

-- ---------------------------------------------- session lifecycle + rate limit
\echo '--- session lifecycle and rate limiting'
select t.as_super();
insert into auth.users (id, email) values
  ('88888888-8888-8888-8888-888888888888','hank@example.com'),
  ('77777777-7777-7777-7777-777777777777','ivy@example.com');

-- hank: an open android session idle 31 minutes (stale)
insert into public.user_sessions (id, user_id, platform, started_at, last_seen_at)
values ('00000000-0000-0000-0000-0000000000a1','88888888-8888-8888-8888-888888888888','android',
        now()-interval '2 hours', now()-interval '31 minutes');
-- ivy: an open web session idle 5 minutes (still resumable)
insert into public.user_sessions (id, user_id, platform, started_at, last_seen_at)
values ('00000000-0000-0000-0000-0000000000b1','77777777-7777-7777-7777-777777777777','web',
        now()-interval '1 hour', now()-interval '5 minutes');

select t.as_user('88888888-8888-8888-8888-888888888888');
select t.eq('stale (>30 min) session heartbeat returns false',
  public.session_heartbeat('00000000-0000-0000-0000-0000000000a1')::text, 'false');
insert into t.ctx select 'h_new', public.start_session('android', '2.4.0', '14', 'Pixel 8');
select t.eq('stale session is not resumed: a new session starts',
  (select (v <> '00000000-0000-0000-0000-0000000000a1')::text from t.ctx where k='h_new'), 'true');
select public.end_session((select v from t.ctx where k='h_new'));
select t.eq('heartbeat after end_session returns false',
  public.session_heartbeat((select v from t.ctx where k='h_new'))::text, 'false');

select t.as_user('77777777-7777-7777-7777-777777777777');
select t.eq('recent open session (5 min idle) is resumed, not duplicated',
  public.start_session('web', '1.0.0')::text, '00000000-0000-0000-0000-0000000000b1');

-- rate limit: 60 events / minute / user
select t.as_user('88888888-8888-8888-8888-888888888888');
do $$ begin
  for i in 1..60 loop perform public.track_event('app_open', 'android'); end loop;
end $$;
select t.expect_error('61st event within a minute is rate limited',
  $q$select public.track_event('app_open', 'android')$q$, '54000');
select t.eq('exactly 60 events stored', (select count(*) from public.analytics_events)::text, '60');

select t.as_super();
rollback;
\echo 'ALL SQL TESTS PASSED'
