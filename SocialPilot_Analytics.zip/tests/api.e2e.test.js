// End-to-end: HTTP API -> (Supabase-compatible shim) -> REAL Postgres with the
// real migrations. Proves admins get data and regular users / anonymous callers
// never do. Skipped unless PGHOST/PGDATABASE point at a migrated test database.
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../server/src/app.js';
import { createSupabase } from '../server/src/supabase.js';
import { psql, fakeJwt, startShim } from './helpers/pg-supabase-shim.js';

const ENABLED = Boolean(process.env.PGDATABASE);
const opts = { skip: ENABLED ? false : 'set PGHOST/PGPORT/PGUSER/PGDATABASE to a migrated test DB' };

const ALICE = 'a1111111-1111-1111-1111-111111111111'; // owner
const BOB = 'b2222222-2222-2222-2222-222222222222';   // regular user
const CARL = 'c3333333-3333-3333-3333-333333333333';  // regular user with data
const GHOST = 'f9999999-9999-9999-9999-999999999999'; // validly signed token, no such user

let shim; let app; let warnings;
const ADMIN = fakeJwt(ALICE);
const REGULAR = fakeJwt(BOB);

const ROUTES = [
  'me', 'overview?tz=UTC', 'daily?range=30d', 'growth?bucket=week', 'platforms?range=30d',
  'events?range=30d', 'devices', 'users',
];
const get = (path, token, method = 'GET', headers = {}) => app.handle({
  method, url: `/api/admin/analytics/${path}`,
  headers: { ...(token ? { authorization: `Bearer ${token}` } : {}), ...headers },
});

before(async () => {
  if (!ENABLED) return;
  await psql(`delete from public.admin_roles; delete from auth.users where id in ('${ALICE}','${BOB}','${CARL}')`);
  await psql(`insert into auth.users (id, email, created_at, raw_user_meta_data) values
    ('${ALICE}','alice.owner@example.com', now() - interval '60 days', '{"full_name":"Alice Owner"}'),
    ('${BOB}','bob.regular@example.com',   now() - interval '30 days', '{"full_name":"Bob Regular"}'),
    ('${CARL}','carl.data@example.com',    now() - interval '2 days',  '{"name":"Carl"}')`);
  await psql(`insert into public.admin_roles (user_id, role) values ('${ALICE}','owner')`);
  shim = await startShim();
  warnings = [];
  const supabase = createSupabase({ url: shim.url, anonKey: 'anon-key' });
  app = createApp({ supabase, log: { warn: (m) => warnings.push(m), error: () => {} } });

  // real ingestion through the same RPC path the apps use
  const ingest = createSupabase({ url: shim.url, anonKey: 'anon-key' });
  const carl = fakeJwt(CARL);
  const sid = await ingest.rpc(carl, 'start_session', { p_platform: 'android', p_app_version: '2.4.0', p_os_version: '14', p_device_model: 'Pixel 8' });
  await ingest.rpc(carl, 'track_event', { p_event_name: 'app_open', p_platform: 'android', p_session_id: sid });
  await ingest.rpc(carl, 'track_event', { p_event_name: 'post_created', p_platform: 'android', p_session_id: sid, p_metadata: { post_type: 'image', prompt: 'SECRET PROMPT' } });
  await ingest.rpc(carl, 'track_event', { p_event_name: 'post_published', p_platform: 'android', p_session_id: sid });
});

after(async () => {
  if (!ENABLED) return;
  await shim.close();
  await psql(`delete from public.admin_roles; delete from auth.users where id in ('${ALICE}','${BOB}','${CARL}')`);
});

test('anonymous requests are rejected with 401 on every route', opts, async () => {
  for (const r of ROUTES) assert.equal((await get(r)).status, 401, r);
});

test('unknown admin paths also demand auth first (no route enumeration)', opts, async () => {
  assert.equal((await get('does-not-exist')).status, 401);
  assert.equal((await app.handle({ method: 'GET', url: '/api/admin/other', headers: {} })).status, 401);
});

test('malformed / forged / unknown-user tokens are rejected with 401', opts, async () => {
  for (const t of ['garbage', 'a.b', 'x'.repeat(5000), `${ADMIN}tampered!`]) {
    assert.equal((await get('overview', t)).status, 401, t.slice(0, 20));
  }
  assert.equal((await get('overview', fakeJwt(GHOST))).status, 401);
});

test('regular user is forbidden (403) on EVERY analytics route and sees no data', opts, async () => {
  for (const r of ROUTES) {
    const res = await get(r, REGULAR);
    assert.equal(res.status, 403, r);
    assert.deepEqual(JSON.parse(res.body), { error: 'forbidden' }, r);
  }
  assert.ok(warnings.some((w) => w.includes(BOB)), 'denied attempts are logged');
});

test('regular user cannot escalate with headers, query flags or other methods', opts, async () => {
  const spoof = { 'x-admin': 'true', 'x-user-role': 'owner', 'x-forwarded-user': ALICE };
  assert.equal((await get('overview?admin=true&role=owner&user_id=' + ALICE, REGULAR, 'GET', spoof)).status, 403);
  assert.equal((await get('users?role=admin', REGULAR, 'GET', spoof)).status, 403);
  for (const method of ['POST', 'PUT', 'PATCH', 'DELETE']) {
    assert.equal((await get('overview', REGULAR, method)).status, 403, method);
  }
});

test('the database, not just the API, refuses a regular user (defense in depth)', opts, async () => {
  const direct = createSupabase({ url: shim.url, anonKey: 'anon-key' });
  await assert.rejects(direct.rpc(REGULAR, 'admin_analytics_overview', { p_tz: 'UTC' }), (e) => e.code === '42501');
  await assert.rejects(direct.rpc(REGULAR, 'admin_analytics_users', {}), (e) => e.code === '42501');
  assert.equal(await direct.rpc(REGULAR, 'is_admin', {}), false);
});

test('admin: /me, overview and counts match the database', opts, async () => {
  assert.deepEqual(JSON.parse((await get('me', ADMIN)).body), { admin: true });
  const res = await get('overview?tz=Asia/Dhaka', ADMIN);
  assert.equal(res.status, 200);
  assert.equal(res.headers['Cache-Control'], 'no-store');
  const o = JSON.parse(res.body);
  assert.equal(o.total_registered_users, 3);
  assert.equal(o.android_users, 1);
  assert.equal(o.posts_created, 1);
  assert.equal(o.posts_published, 1);
  assert.equal(o.timezone, 'Asia/Dhaka');
  assert.ok(o.active_today >= 1);
  assert.ok(o.online_now_estimate >= 1);
});

test('admin: daily series is zero-filled and honours presets', opts, async () => {
  for (const [range, n] of [['today', 1], ['7d', 7], ['30d', 30], ['90d', 90]]) {
    const body = JSON.parse((await get(`daily?range=${range}&tz=UTC`, ADMIN)).body);
    assert.equal(body.rows.length, n, range);
  }
  const body = JSON.parse((await get('daily?range=custom&from=2026-01-01&to=2026-01-31&tz=UTC', ADMIN)).body);
  assert.equal(body.rows.length, 31);
});

test('admin: growth, platforms, events, devices', opts, async () => {
  const g = JSON.parse((await get('growth?bucket=month', ADMIN)).body);
  assert.equal(g.bucket, 'month');
  assert.equal(g.rows.at(-1).cumulative_users, 3);
  const p = JSON.parse((await get('platforms?range=30d', ADMIN)).body);
  assert.deepEqual(p.rows.map((r) => r.platform), ['android', 'web']);
  const e = JSON.parse((await get('events?range=30d', ADMIN)).body);
  assert.ok(e.rows.some((r) => r.event_name === 'post_created'));
  const d = JSON.parse((await get('devices', ADMIN)).body);
  assert.equal(d.android_device_models[0].device_model, 'Pixel 8');
});

test('admin: user list searches, filters and paginates; no secrets or private content', opts, async () => {
  const all = JSON.parse((await get('users?pageSize=2&page=1', ADMIN)).body);
  assert.equal(all.total, 3);
  assert.equal(all.rows.length, 2);
  const one = JSON.parse((await get('users?q=carl', ADMIN)).body);
  assert.equal(one.rows.length, 1);
  assert.equal(one.rows[0].platform, 'android');
  assert.equal(one.rows[0].app_version, '2.4.0');
  assert.equal(one.rows[0].total_sessions, 1);
  assert.ok(!('total_count' in one.rows[0]));
  const raw = (await get('users', ADMIN)).body + (await get('overview', ADMIN)).body + (await get('events?range=30d', ADMIN)).body;
  assert.ok(!/password|token|SECRET PROMPT|encrypted/i.test(raw), 'no secrets or prompt text in any response');
  const inj = await get(`users?q=${encodeURIComponent("' OR 1=1; DROP TABLE public.analytics_events;--")}`, ADMIN);
  assert.equal(inj.status, 200);
  assert.equal(JSON.parse(inj.body).total, 0);
  assert.equal(await psql('select count(*) from public.analytics_events'), '3');
});

test('admin: input validation returns 400', opts, async () => {
  const bad = [
    'overview?tz=Mars/Phobos', 'overview?tz=' + encodeURIComponent("UTC'; --"),
    'daily?range=forever', 'daily?range=custom', 'daily?range=custom&from=2026-02-31&to=2026-03-01',
    'daily?range=custom&from=2026-03-02&to=2026-03-01', 'daily?range=custom&from=2020-01-01&to=2026-01-01',
    'growth?bucket=year', 'users?sort=password_asc', 'users?platform=ios', 'users?status=deleted',
    'users?page=0', 'users?page=abc', 'users?pageSize=1000', 'users?q=' + 'x'.repeat(101),
  ];
  for (const r of bad) assert.equal((await get(r, ADMIN)).status, 400, r);
});

test('admin: non-GET methods are 405 and unknown routes 404', opts, async () => {
  assert.equal((await get('overview', ADMIN, 'POST')).status, 405);
  assert.equal((await get('nope', ADMIN)).status, 404);
  assert.equal((await get('__proto__', ADMIN)).status, 404);
  assert.equal((await get('constructor', ADMIN)).status, 404);
});

test('revoking admin_roles takes effect immediately', opts, async () => {
  assert.equal((await get('overview', ADMIN)).status, 200);
  await psql(`delete from public.admin_roles where user_id='${ALICE}'`);
  assert.equal((await get('overview', ADMIN)).status, 403);
  await psql(`insert into public.admin_roles (user_id, role) values ('${ALICE}','owner')`);
  assert.equal((await get('overview', ADMIN)).status, 200);
});

test('API rate limit returns 429 per user', opts, async () => {
  const limited = createApp({ supabase: createSupabase({ url: shim.url, anonKey: 'k' }), rateLimitPerMinute: 3, log: { warn() {}, error() {} } });
  const call = () => limited.handle({ method: 'GET', url: '/api/admin/analytics/me', headers: { authorization: `Bearer ${ADMIN}` } });
  assert.equal((await call()).status, 200);
  assert.equal((await call()).status, 200);
  assert.equal((await call()).status, 200);
  assert.equal((await call()).status, 429);
});

test('upstream failures never leak internals (502 generic)', opts, async () => {
  const dead = createApp({ supabase: createSupabase({ url: 'http://127.0.0.1:1', anonKey: 'k', timeoutMs: 500 }), log: { warn() {}, error() {} } });
  const res = await dead.handle({ method: 'GET', url: '/api/admin/analytics/overview', headers: { authorization: `Bearer ${ADMIN}` } });
  assert.equal(res.status, 502);
  assert.deepEqual(JSON.parse(res.body), { error: 'upstream_error' });
});
