delete from public.admin_roles;
delete from auth.users where id::text like '00000000-0000-4000-8000-%';
