// TEST-ONLY: a minimal stand-in for Supabase (GoTrue /auth/v1/user and PostgREST
// /rest/v1/rpc/*) backed by a REAL Postgres reached through `psql`.
// Each RPC runs in its own transaction as role `authenticated` with the caller's
// JWT claims, exactly the context PostgREST would create, so is_admin(), RLS and
// the admin guard inside every function are exercised for real.
//
// Needs the standard PG* env vars (PGHOST, PGPORT, PGUSER, PGDATABASE).
import http from 'node:http';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const run = promisify(execFile);
const SET_RETURNING = new Set([
  'admin_analytics_daily', 'admin_analytics_growth', 'admin_analytics_platforms',
  'admin_analytics_event_series', 'admin_analytics_users',
]);
const ALLOWED_FN = /^(is_admin|start_session|session_heartbeat|end_session|track_event|admin_analytics_[a-z_]+)$/;

export async function psql(sql) {
  const { stdout } = await run('psql', ['-X', '-q', '-t', '-A', '-v', 'ON_ERROR_STOP=1', '-v', 'VERBOSITY=verbose', '-c', sql]);
  return stdout.trim();
}

export function fakeJwt(sub) {
  const b = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
  return `${b({ alg: 'HS256', typ: 'JWT' })}.${b({ sub, role: 'authenticated' })}.c2ln`;
}

const lit = (v) => {
  if (v === null || v === undefined) return 'NULL';
  if (typeof v === 'number' && Number.isFinite(v)) return String(v);
  if (typeof v === 'boolean') return v ? 'true' : 'false';
  if (typeof v === 'string') return `'${v.replaceAll("'", "''")}'`;
  return `'${JSON.stringify(v).replaceAll("'", "''")}'::jsonb`;
};

function subjectOf(token) {
  try {
    const claims = JSON.parse(Buffer.from(token.split('.')[1], 'base64url').toString());
    return /^[0-9a-f-]{36}$/.test(claims.sub) ? claims.sub : null;
  } catch { return null; }
}

export function startShim() {
  const calls = [];
  const server = http.createServer(async (req, res) => {
    const send = (status, body) => { res.writeHead(status, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(body)); };
    try {
      const token = (req.headers.authorization ?? '').replace(/^Bearer /, '');
      const sub = subjectOf(token);

      if (req.url === '/auth/v1/user') {
        if (!sub) return send(401, { msg: 'invalid JWT' });
        const out = await psql(`select coalesce((select to_jsonb(u) from (select id, email from auth.users where id='${sub}' and deleted_at is null) u), 'null'::jsonb)`);
        const row = JSON.parse(out);
        return row ? send(200, row) : send(401, { msg: 'user not found' });
      }

      const m = /^\/rest\/v1\/rpc\/([a-z_]+)$/.exec(req.url);
      if (!m || !ALLOWED_FN.test(m[1])) return send(404, { message: 'not found' });
      if (!sub) return send(401, { message: 'JWT invalid' });

      let raw = '';
      for await (const chunk of req) raw += chunk;
      const args = raw ? JSON.parse(raw) : {};
      calls.push({ fn: m[1], sub, args });
      const named = Object.entries(args).map(([k, v]) => `${k} => ${lit(v)}`).join(', ');
      const call = `${m[1]}(${named})`;
      const query = SET_RETURNING.has(m[1])
        ? `select coalesce(jsonb_agg(to_jsonb(f)), '[]'::jsonb) from public.${call} f`
        : `select to_jsonb(public.${call})`;
      const sql = `do $$ begin
          perform set_config('request.jwt.claims', '{"sub":"${sub}","role":"authenticated"}', true);
          perform set_config('role', 'authenticated', true);
        end $$; ${query};`;
      try {
        const out = await psql(sql);
        return send(200, out === '' ? null : JSON.parse(out));
      } catch (err) {
        const mm = /ERROR:\s+([0-9A-Z]{5}):\s+(.*)/.exec(String(err.stderr ?? ''));
        const code = mm?.[1] ?? 'XX000';
        const status = code === '42501' ? 403 : code.startsWith('22') ? 400 : 500;
        return send(status, { code, message: mm?.[2] ?? 'error' });
      }
    } catch (err) {
      return send(500, { message: String(err) });
    }
  });
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve({
    url: `http://127.0.0.1:${server.address().port}`,
    calls,
    close: () => new Promise((r) => server.close(r)),
  })));
}
