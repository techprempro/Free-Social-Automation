-- Demo data for eyeballing the dashboard (committed rows; removed by cleanup-demo.sql).
insert into auth.users (id, email, created_at, raw_user_meta_data, email_confirmed_at, banned_until)
select ('00000000-0000-4000-8000-' || lpad(g::text, 12, '0'))::uuid,
       'user' || g || '@example.com',
       now() - (random() * 85 || ' days')::interval,
       jsonb_build_object('full_name', (array['Ava','Noah','Mia','Liam','Zara','Omar','Nina','Raj','Sara','Tom'])[1 + g % 10] || ' ' || (array['Khan','Lee','Silva','Roy','Park','Ali'])[1 + g % 6]),
       case when g % 13 = 0 then null else now() end,
       case when g % 29 = 0 then now() + interval '1 year' end
from generate_series(1, 60) g;
insert into auth.users (id, email, created_at, raw_user_meta_data)
values ('00000000-0000-4000-8000-0000000000aa', 'owner@example.com', now() - interval '90 days', '{"full_name":"Site Owner"}'),
       ('00000000-0000-4000-8000-0000000000bb', 'regular@example.com', now() - interval '20 days', '{"full_name":"Regular <img src=x onerror=alert(1)>"}');
insert into public.admin_roles (user_id, role) values ('00000000-0000-4000-8000-0000000000aa', 'owner');

insert into public.user_devices (user_id, platform, first_seen_at, last_seen_at, app_version, os_version, device_model)
select u.id, 'android', u.created_at, now(), (array['2.4.0','2.4.0','2.3.1','2.2.0'])[1 + (random()*3)::int],
       (array['14','14','13','12'])[1 + (random()*3)::int], (array['Pixel 8','Pixel 7','Galaxy S23','Galaxy A54','Redmi Note 12'])[1 + (random()*4)::int]
from auth.users u where u.email like 'user%' and random() < 0.6;
insert into public.user_devices (user_id, platform, first_seen_at, last_seen_at, app_version)
select u.id, 'web', u.created_at, now(), '1.8.0' from auth.users u where u.email like 'user%' and random() < 0.7
on conflict do nothing;

insert into public.user_sessions (user_id, platform, app_version, started_at, last_seen_at, ended_at)
select d.user_id, d.platform, d.app_version, s.t, s.t + s.len, s.t + s.len
from public.user_devices d
cross join lateral (
  select now() - ((abs(hashtext(d.user_id::text || d.platform || g::text)) % 6000) / 100.0 || ' days')::interval as t,
         ((abs(hashtext(g::text || d.user_id::text)) % 40) + 1 || ' minutes')::interval as len
    from generate_series(1, 1 + (abs(hashtext(d.user_id::text)) % 15)) g) s;

insert into public.analytics_events (user_id, session_id, event_name, platform, app_version, created_at)
select s.user_id, s.id,
       (array['app_open','login','post_created','post_created','draft_saved','post_scheduled','post_published','ai_generation','ai_generation','account_connected'])
         [1 + (abs(hashtext(s.id::text || g::text)) % 10)],
       s.platform, s.app_version, s.started_at + (g || ' minutes')::interval
from public.user_sessions s
cross join generate_series(1, 4) g;
