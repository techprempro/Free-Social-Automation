// Starts the Postgres-backed Supabase shim as a standalone process (for manual/browser checks).
import { startShim } from './pg-supabase-shim.js';
const s = await startShim();
console.log(`SHIM_URL=${s.url}`);
setInterval(() => {}, 1 << 30);
