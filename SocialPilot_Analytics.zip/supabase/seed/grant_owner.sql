-- Grant the first owner. Run ONCE in the Supabase SQL editor (runs as the
-- postgres role, where auth.uid() is null, so the admin_roles guard allows it).
-- This can never be done through the API or from the app.
--
-- 1. Sign up / sign in once with the owner's account so a row exists in auth.users.
-- 2. Replace the email below and run:

insert into public.admin_roles (user_id, role)
select id, 'owner'
  from auth.users
 where email = 'owner@example.com'      -- <-- CHANGE ME
on conflict (user_id) do update set role = excluded.role;

-- Add a second admin:
--   insert into public.admin_roles (user_id, role)
--   select id, 'admin' from auth.users where email = 'teammate@example.com';
--
-- Revoke:
--   delete from public.admin_roles where user_id = (select id from auth.users where email = '...');
