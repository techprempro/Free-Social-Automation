-- ============================================================================
-- Migration 4/5: ingestion functions (called by Android + web with the USER's
-- JWT). The user id always comes from auth.uid(); clients cannot write rows
-- for anyone else, and all values are sanitized server-side.
-- ============================================================================

-- start_session: begins (or resumes) a usage session. Returns the session id.
--   * Re-opening the app within 30 minutes of the last activity resumes the
--     open session instead of creating a new one.
--   * Upserts the single user_devices row for (user, platform); first_seen_at
--     is only ever set on insert, so repeated opens never look like new users.
create or replace function public.start_session(
  p_platform     text,
  p_app_version  text default null,
  p_os_version   text default null,
  p_device_model text default null
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid     uuid := auth.uid();
  v_id      uuid;
  v_version text := public.analytics_clean_text(p_app_version, 32);
  v_os      text := public.analytics_clean_text(p_os_version, 16);
  v_model   text := public.analytics_clean_text(p_device_model, 64);
begin
  if v_uid is null then
    raise exception 'not authenticated' using errcode = '42501';
  end if;
  if p_platform is null or p_platform not in ('android', 'web') then
    raise exception 'invalid platform' using errcode = '22023';
  end if;

  select s.id into v_id
    from public.user_sessions s
   where s.user_id = v_uid
     and s.platform = p_platform
     and s.ended_at is null
     and s.last_seen_at > now() - interval '30 minutes'
   order by s.last_seen_at desc
   limit 1;

  if v_id is null then
    insert into public.user_sessions (user_id, platform, app_version)
    values (v_uid, p_platform, v_version)
    returning id into v_id;
  else
    update public.user_sessions
       set last_seen_at = now(),
           app_version  = coalesce(v_version, app_version)
     where id = v_id;
  end if;

  insert into public.user_devices as d
         (user_id, platform, app_version, os_version, device_model)
  values (v_uid, p_platform, v_version, v_os, v_model)
  on conflict (user_id, platform) do update
     set last_seen_at = now(),
         app_version  = coalesce(excluded.app_version, d.app_version),
         os_version   = coalesce(excluded.os_version, d.os_version),
         device_model = coalesce(excluded.device_model, d.device_model);

  return v_id;
end;
$$;

-- session_heartbeat: keeps a session "online". Returns false when the session
-- is unknown, already ended, or idle > 30 min; the client should then call
-- start_session again. Writes are throttled to once per 15 seconds.
create or replace function public.session_heartbeat(p_session_id uuid)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid  uuid := auth.uid();
  v_last timestamptz;
begin
  if v_uid is null then
    raise exception 'not authenticated' using errcode = '42501';
  end if;

  select s.last_seen_at into v_last
    from public.user_sessions s
   where s.id = p_session_id and s.user_id = v_uid and s.ended_at is null;

  if v_last is null or v_last < now() - interval '30 minutes' then
    return false;
  end if;

  update public.user_sessions
     set last_seen_at = now()
   where id = p_session_id and user_id = v_uid
     and last_seen_at < now() - interval '15 seconds';

  return true;
end;
$$;

-- end_session: marks a session as ended (logout, app backgrounded for good).
create or replace function public.end_session(p_session_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid uuid := auth.uid();
begin
  if v_uid is null then
    raise exception 'not authenticated' using errcode = '42501';
  end if;

  update public.user_sessions
     set ended_at = now(), last_seen_at = now()
   where id = p_session_id and user_id = v_uid and ended_at is null;
end;
$$;

-- track_event: records one whitelisted event for the calling user.
--   * event name must be on the allow-list
--   * metadata is reduced to whitelisted, non-sensitive scalar keys
--   * max 60 events per user per minute (abuse protection)
--   * if a valid own session id is given, its platform wins over the argument
create or replace function public.track_event(
  p_event_name  text,
  p_platform    text,
  p_app_version text  default null,
  p_session_id  uuid  default null,
  p_metadata    jsonb default '{}'::jsonb
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_uid       uuid := auth.uid();
  v_platform  text := p_platform;
  v_session   uuid;
  v_sess_plat text;
begin
  if v_uid is null then
    raise exception 'not authenticated' using errcode = '42501';
  end if;
  if p_event_name is null or p_event_name not in (
       'app_open', 'login', 'logout', 'post_created', 'draft_saved',
       'post_scheduled', 'post_published', 'ai_generation', 'account_connected') then
    raise exception 'invalid event name' using errcode = '22023';
  end if;

  if p_session_id is not null then
    select s.id, s.platform into v_session, v_sess_plat
      from public.user_sessions s
     where s.id = p_session_id and s.user_id = v_uid;
    if v_sess_plat is not null then
      v_platform := v_sess_plat;
    end if;
  end if;

  if v_platform is null or v_platform not in ('android', 'web') then
    raise exception 'invalid platform' using errcode = '22023';
  end if;

  if (select count(*) from public.analytics_events e
       where e.user_id = v_uid and e.created_at > now() - interval '1 minute') >= 60 then
    raise exception 'rate limit exceeded' using errcode = '54000';
  end if;

  insert into public.analytics_events
         (user_id, session_id, event_name, platform, app_version, metadata)
  values (v_uid, v_session, p_event_name, v_platform,
          public.analytics_clean_text(p_app_version, 32),
          public.analytics_clean_metadata(p_metadata));

  -- An event is proof of activity: refresh the session heartbeat (throttled).
  if v_session is not null then
    update public.user_sessions
       set last_seen_at = now()
     where id = v_session and ended_at is null
       and last_seen_at < now() - interval '15 seconds';
  end if;
end;
$$;

-- Only signed-in users may call the ingestion functions.
revoke all on function public.start_session(text, text, text, text)        from public, anon, authenticated;
revoke all on function public.session_heartbeat(uuid)                      from public, anon, authenticated;
revoke all on function public.end_session(uuid)                            from public, anon, authenticated;
revoke all on function public.track_event(text, text, text, uuid, jsonb)   from public, anon, authenticated;

grant execute on function public.start_session(text, text, text, text)      to authenticated;
grant execute on function public.session_heartbeat(uuid)                    to authenticated;
grant execute on function public.end_session(uuid)                          to authenticated;
grant execute on function public.track_event(text, text, text, uuid, jsonb) to authenticated;
