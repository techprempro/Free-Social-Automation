-- ============================================================================
-- SocialPilot AI — Phase 9: App Usage Analytics
-- Migration 1/5: tables, constraints, indexes, activity view
--
-- Target: Supabase (Postgres 15+). Relies on auth.users and auth.uid().
-- Privacy by design: no passwords, tokens, post content, AI prompts, contacts,
-- messages or location are ever stored here. Event metadata is whitelisted.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- admin_roles: who may open the owner/admin analytics dashboard.
-- Rows can only be created by the project owner via SQL console / service role
-- (see supabase/seed/grant_owner.sql). No API path can write to this table.
-- ---------------------------------------------------------------------------
create table if not exists public.admin_roles (
  user_id    uuid primary key references auth.users (id) on delete cascade,
  role       text not null check (role in ('owner', 'admin')),
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- user_sessions: one row per usage session (app foreground / browser visit).
-- A session is "open" while ended_at is null; last_seen_at is refreshed by a
-- heartbeat. Sessions whose client never reports an end (killed app, closed
-- tab) simply stop updating last_seen_at; duration = last_seen_at - started_at.
-- ---------------------------------------------------------------------------
create table if not exists public.user_sessions (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references auth.users (id) on delete cascade,
  platform     text not null check (platform in ('android', 'web')),
  app_version  text,
  started_at   timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  ended_at     timestamptz,
  constraint user_sessions_time_order
    check (last_seen_at >= started_at and (ended_at is null or ended_at >= started_at))
);

-- ---------------------------------------------------------------------------
-- user_devices: ONE row per (user, platform) holding only the minimum device
-- facts the owner asked for. No device identifiers (no IMEI/ad-ID/Android ID).
-- first_seen_at = first app open on that platform; it is never overwritten.
-- ---------------------------------------------------------------------------
create table if not exists public.user_devices (
  user_id       uuid not null references auth.users (id) on delete cascade,
  platform      text not null check (platform in ('android', 'web')),
  first_seen_at timestamptz not null default now(),
  last_seen_at  timestamptz not null default now(),
  app_version   text,
  os_version    text,
  device_model  text,
  primary key (user_id, platform)
);

-- ---------------------------------------------------------------------------
-- analytics_events: append-only product events. metadata is whitelisted and
-- size-limited by public.analytics_clean_metadata() and a CHECK constraint.
-- ---------------------------------------------------------------------------
create table if not exists public.analytics_events (
  id          bigint generated always as identity primary key,
  user_id     uuid not null references auth.users (id) on delete cascade,
  session_id  uuid references public.user_sessions (id) on delete set null,
  event_name  text not null check (event_name in (
                'app_open', 'login', 'logout', 'post_created', 'draft_saved',
                'post_scheduled', 'post_published', 'ai_generation',
                'account_connected')),
  platform    text not null check (platform in ('android', 'web')),
  app_version text,
  created_at  timestamptz not null default now(),
  metadata    jsonb not null default '{}'::jsonb,
  constraint analytics_events_metadata_shape
    check (jsonb_typeof(metadata) = 'object' and pg_column_size(metadata) <= 1024)
);

-- ---------------------------------------------------------------------------
-- Indexes (sized for time-range scans, per-user lookups and "online now").
-- ---------------------------------------------------------------------------
create index if not exists analytics_events_created_at_idx
  on public.analytics_events (created_at);
create index if not exists analytics_events_user_created_idx
  on public.analytics_events (user_id, created_at desc);
create index if not exists analytics_events_name_created_idx
  on public.analytics_events (event_name, created_at);
create index if not exists analytics_events_platform_created_idx
  on public.analytics_events (platform, created_at);

create index if not exists user_sessions_user_started_idx
  on public.user_sessions (user_id, started_at desc);
create index if not exists user_sessions_started_at_idx
  on public.user_sessions (started_at);
create index if not exists user_sessions_platform_started_idx
  on public.user_sessions (platform, started_at);
-- Partial index: only open sessions, used for "currently online" and for
-- reusing a recent open session instead of creating a duplicate.
create index if not exists user_sessions_open_idx
  on public.user_sessions (last_seen_at desc) where ended_at is null;

create index if not exists user_devices_platform_seen_idx
  on public.user_devices (platform, last_seen_at);

-- ---------------------------------------------------------------------------
-- v_user_activity: the single definition of a "qualifying activity".
--   Qualifying activity = any analytics event except 'logout', or a session
--   start. Heartbeats alone never count, and neither does a background ping.
--   Daily active users = DISTINCT users with >= 1 row here on that day.
-- security_invoker: the view obeys the caller's RLS; direct access is also
-- revoked from API roles in the RLS migration.
-- ---------------------------------------------------------------------------
create or replace view public.v_user_activity
with (security_invoker = true) as
  select e.user_id, e.platform, e.created_at as activity_at
    from public.analytics_events e
   where e.event_name <> 'logout'
  union all
  select s.user_id, s.platform, s.started_at as activity_at
    from public.user_sessions s;
