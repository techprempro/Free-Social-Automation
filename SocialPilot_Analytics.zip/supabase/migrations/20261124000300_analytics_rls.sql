-- ============================================================================
-- Migration 3/5: Row Level Security + grants
--
-- Model:
--   * Regular users: may READ only their own rows. They can never write
--     directly; all writes go through validated SECURITY DEFINER functions
--     (start_session / session_heartbeat / end_session / track_event) which
--     always use auth.uid(), never a client-supplied user id.
--   * Admins/owners: may read everything (RLS policy + admin RPCs).
--   * anon: nothing.
-- ============================================================================

alter table public.admin_roles      enable row level security;
alter table public.user_sessions    enable row level security;
alter table public.user_devices     enable row level security;
alter table public.analytics_events enable row level security;

-- Supabase grants broad default privileges to anon/authenticated. Remove them
-- first, then grant back the minimum.
revoke all on table public.admin_roles      from anon, authenticated;
revoke all on table public.user_sessions    from anon, authenticated;
revoke all on table public.user_devices     from anon, authenticated;
revoke all on table public.analytics_events from anon, authenticated;
revoke all on table public.v_user_activity  from anon, authenticated;

grant select on table public.admin_roles      to authenticated;
grant select on table public.user_sessions    to authenticated;
grant select on table public.user_devices     to authenticated;
grant select on table public.analytics_events to authenticated;
-- Note: no INSERT/UPDATE/DELETE grants and no write policies exist for any
-- API role on any of these tables.

-- admin_roles: a user may see only their own role row (lets the app check
-- "am I an admin?"); nobody can write through the API.
drop policy if exists admin_roles_select_own on public.admin_roles;
create policy admin_roles_select_own on public.admin_roles
  for select to authenticated
  using (user_id = (select auth.uid()));

-- user_sessions
drop policy if exists user_sessions_select_own on public.user_sessions;
create policy user_sessions_select_own on public.user_sessions
  for select to authenticated
  using (user_id = (select auth.uid()));

drop policy if exists user_sessions_select_admin on public.user_sessions;
create policy user_sessions_select_admin on public.user_sessions
  for select to authenticated
  using ((select public.is_admin()));

-- user_devices
drop policy if exists user_devices_select_own on public.user_devices;
create policy user_devices_select_own on public.user_devices
  for select to authenticated
  using (user_id = (select auth.uid()));

drop policy if exists user_devices_select_admin on public.user_devices;
create policy user_devices_select_admin on public.user_devices
  for select to authenticated
  using ((select public.is_admin()));

-- analytics_events
drop policy if exists analytics_events_select_own on public.analytics_events;
create policy analytics_events_select_own on public.analytics_events
  for select to authenticated
  using (user_id = (select auth.uid()));

drop policy if exists analytics_events_select_admin on public.analytics_events;
create policy analytics_events_select_admin on public.analytics_events
  for select to authenticated
  using ((select public.is_admin()));
