-- ============================================================================
-- Migration 2/5: security helpers (is_admin, role-table guard, sanitizers)
-- ============================================================================

-- is_admin(): true when the CURRENT JWT user has a row in admin_roles.
-- SECURITY DEFINER so it can read admin_roles regardless of the caller's RLS.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.admin_roles r where r.user_id = (select auth.uid())
  );
$$;

revoke all on function public.is_admin() from public, anon, authenticated;
grant execute on function public.is_admin() to authenticated;

-- Internal guard used by every admin analytics function. Not callable by
-- API roles directly (only from other SECURITY DEFINER functions).
create or replace function public.analytics_require_admin()
returns void
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
  if not public.is_admin() then
    raise exception 'forbidden' using errcode = '42501';
  end if;
end;
$$;

revoke all on function public.analytics_require_admin() from public, anon, authenticated;

-- Validates an IANA timezone name (e.g. 'Asia/Dhaka').
create or replace function public.analytics_check_tz(p_tz text)
returns void
language plpgsql
stable
set search_path = ''
as $$
begin
  if p_tz is null
     or not exists (select 1 from pg_catalog.pg_timezone_names n where n.name = p_tz) then
    raise exception 'invalid timezone' using errcode = '22023';
  end if;
end;
$$;

revoke all on function public.analytics_check_tz(text) from public, anon, authenticated;

-- ---------------------------------------------------------------------------
-- Defense in depth: nobody authenticated through the API (i.e. any request
-- where auth.uid() is set) may insert/update/delete admin_roles — not even
-- through a SECURITY DEFINER function. Only the SQL console / service role
-- (auth.uid() is null) can grant or revoke roles.
-- ---------------------------------------------------------------------------
create or replace function public.guard_admin_roles()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if auth.uid() is not null then
    raise exception 'admin_roles can only be changed by the project owner via the SQL console'
      using errcode = '42501';
  end if;
  return coalesce(new, old);
end;
$$;

drop trigger if exists guard_admin_roles on public.admin_roles;
create trigger guard_admin_roles
  before insert or update or delete on public.admin_roles
  for each row execute function public.guard_admin_roles();

-- ---------------------------------------------------------------------------
-- Sanitizers: clients are untrusted, so values are cleaned server-side.
-- ---------------------------------------------------------------------------

-- Keeps a short, printable token (version strings, OS versions, device models).
create or replace function public.analytics_clean_text(p text, p_max int default 32)
returns text
language sql
immutable
set search_path = ''
as $$
  select nullif(left(regexp_replace(coalesce(p, ''), '[^0-9A-Za-z ._+/()-]', '', 'g'), p_max), '');
$$;

-- Keeps ONLY whitelisted, non-sensitive metadata keys with scalar values.
-- Free-text (post content, prompts, titles, emails...) cannot be stored: any
-- unknown key is dropped, strings are capped at 64 chars, objects/arrays are
-- dropped.
create or replace function public.analytics_clean_metadata(p jsonb)
returns jsonb
language sql
immutable
set search_path = ''
as $$
  select coalesce(jsonb_object_agg(kv.key, kv.value), '{}'::jsonb)
    from jsonb_each(case when jsonb_typeof(p) = 'object' then p else '{}'::jsonb end) as kv
   where kv.key in ('provider', 'post_type', 'feature', 'method', 'success', 'error_code', 'count')
     and (
       (jsonb_typeof(kv.value) = 'string' and length(kv.value #>> '{}') <= 64)
       or jsonb_typeof(kv.value) in ('number', 'boolean')
     );
$$;

revoke all on function public.analytics_clean_text(text, int) from public, anon, authenticated;
revoke all on function public.analytics_clean_metadata(jsonb) from public, anon, authenticated;
