-- ============================================================================
-- Migration 5/5: admin-only analytics queries
--
-- Every function:
--   * is SECURITY DEFINER with an empty search_path
--   * calls analytics_require_admin() FIRST (raises 42501 'forbidden')
--   * takes the admin's IANA timezone so "today"/"this week" match their clock
--   * never returns passwords, tokens or any content of posts / AI prompts
--
-- Definitions (also shown in the dashboard):
--   Registered users  = auth.users rows that are not deleted.
--   Active user (day) = DISTINCT user with >= 1 qualifying activity that day
--                       (see v_user_activity: any event except logout, or a
--                       session start). Repeat opens never add registered users.
--   Online now        = DISTINCT users with an OPEN session whose heartbeat is
--                       < 150 seconds old. This is an ESTIMATE.
--   Rolling windows   = calendar days in the admin's timezone, including today
--                       (7d = today + 6 previous days).
--   Session duration  = (ended_at or last_seen_at) - started_at, capped at 4h
--                       so a forgotten tab cannot skew the average.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- Overview cards
-- ---------------------------------------------------------------------------
create or replace function public.admin_analytics_overview(p_tz text default 'UTC')
returns jsonb
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  v_today date;
  v_t0     timestamptz;
  v_w0     timestamptz;
  v_m0     timestamptz;
  v_d7     timestamptz;
  v_d30    timestamptz;
  v_result jsonb;
begin
  perform public.analytics_require_admin();
  perform public.analytics_check_tz(p_tz);

  v_today := (now() at time zone p_tz)::date;
  v_t0  := v_today::timestamp at time zone p_tz;
  v_w0  := date_trunc('week',  v_today::timestamp) at time zone p_tz;   -- ISO week, Monday
  v_m0  := date_trunc('month', v_today::timestamp) at time zone p_tz;
  v_d7  := (v_today - 6)::timestamp  at time zone p_tz;
  v_d30 := (v_today - 29)::timestamp at time zone p_tz;

  select jsonb_build_object(
    'as_of',                 now(),
    'timezone',              p_tz,
    'total_registered_users',(select count(*) from auth.users u where u.deleted_at is null),
    'android_users',         (select count(*) from public.user_devices d where d.platform = 'android'),
    'web_users',             (select count(*) from public.user_devices d where d.platform = 'web'),
    'users_on_both',         (select count(*) from public.user_devices a
                                join public.user_devices w on w.user_id = a.user_id and w.platform = 'web'
                               where a.platform = 'android'),
    'active_today',          (select count(distinct a.user_id) from public.v_user_activity a where a.activity_at >= v_t0),
    'active_7d',             (select count(distinct a.user_id) from public.v_user_activity a where a.activity_at >= v_d7),
    'active_30d',            (select count(distinct a.user_id) from public.v_user_activity a where a.activity_at >= v_d30),
    'new_today',             (select count(*) from auth.users u where u.deleted_at is null and u.created_at >= v_t0),
    'new_this_week',         (select count(*) from auth.users u where u.deleted_at is null and u.created_at >= v_w0),
    'new_this_month',        (select count(*) from auth.users u where u.deleted_at is null and u.created_at >= v_m0),
    'online_now_estimate',   (select count(distinct s.user_id) from public.user_sessions s
                               where s.ended_at is null and s.last_seen_at > now() - interval '150 seconds'),
    'online_window_seconds', 150,
    'total_sessions',        (select count(*) from public.user_sessions),
    'avg_session_seconds',   (select coalesce(round(avg(least(
                                 extract(epoch from (coalesce(s.ended_at, s.last_seen_at) - s.started_at)), 14400))::numeric, 1), 0)
                                from public.user_sessions s),
    'posts_created',         (select count(*) from public.analytics_events e where e.event_name = 'post_created'),
    'posts_published',       (select count(*) from public.analytics_events e where e.event_name = 'post_published'),
    'posts_scheduled',       (select count(*) from public.analytics_events e where e.event_name = 'post_scheduled')
  ) into v_result;

  return v_result;
end;
$$;

-- ---------------------------------------------------------------------------
-- Daily series (zero-filled): DAU, platform split, registrations, sessions,
-- and post/AI activity.
-- ---------------------------------------------------------------------------
create or replace function public.admin_analytics_daily(
  p_from date,
  p_to   date,
  p_tz   text default 'UTC'
)
returns table (
  day                  date,
  active_users         int,
  android_active_users int,
  web_active_users     int,
  new_users            int,
  sessions             int,
  logins               int,
  posts_created        int,
  drafts_saved         int,
  posts_scheduled      int,
  posts_published      int,
  ai_generations       int
)
language plpgsql
stable
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_start timestamptz;
  v_end   timestamptz;
begin
  perform public.analytics_require_admin();
  perform public.analytics_check_tz(p_tz);
  if p_from is null or p_to is null or p_to < p_from or p_to - p_from > 366 then
    raise exception 'invalid date range' using errcode = '22023';
  end if;

  v_start := p_from::timestamp at time zone p_tz;
  v_end   := (p_to + 1)::timestamp at time zone p_tz;

  return query
  with days as (
    select p_from + g as day from generate_series(0, p_to - p_from) as g
  ),
  act as (
    select (a.activity_at at time zone p_tz)::date as day,
           count(distinct a.user_id)::int                                         as au,
           (count(distinct a.user_id) filter (where a.platform = 'android'))::int as aau,
           (count(distinct a.user_id) filter (where a.platform = 'web'))::int     as wau
      from public.v_user_activity a
     where a.activity_at >= v_start and a.activity_at < v_end
     group by 1
  ),
  reg as (
    select (u.created_at at time zone p_tz)::date as day, count(*)::int as n
      from auth.users u
     where u.deleted_at is null and u.created_at >= v_start and u.created_at < v_end
     group by 1
  ),
  ses as (
    select (s.started_at at time zone p_tz)::date as day, count(*)::int as n
      from public.user_sessions s
     where s.started_at >= v_start and s.started_at < v_end
     group by 1
  ),
  ev as (
    select (e.created_at at time zone p_tz)::date as day,
           (count(*) filter (where e.event_name = 'login'))::int          as logins,
           (count(*) filter (where e.event_name = 'post_created'))::int   as created,
           (count(*) filter (where e.event_name = 'draft_saved'))::int    as drafts,
           (count(*) filter (where e.event_name = 'post_scheduled'))::int as scheduled,
           (count(*) filter (where e.event_name = 'post_published'))::int as published,
           (count(*) filter (where e.event_name = 'ai_generation'))::int  as ai
      from public.analytics_events e
     where e.created_at >= v_start and e.created_at < v_end
     group by 1
  )
  select days.day,
         coalesce(act.au, 0), coalesce(act.aau, 0), coalesce(act.wau, 0),
         coalesce(reg.n, 0),  coalesce(ses.n, 0),
         coalesce(ev.logins, 0), coalesce(ev.created, 0), coalesce(ev.drafts, 0),
         coalesce(ev.scheduled, 0), coalesce(ev.published, 0), coalesce(ev.ai, 0)
    from days
    left join act on act.day = days.day
    left join reg on reg.day = days.day
    left join ses on ses.day = days.day
    left join ev  on ev.day  = days.day
   order by days.day;
end;
$$;

-- ---------------------------------------------------------------------------
-- Weekly / monthly growth: new registrations, cumulative registered users,
-- and distinct active users per bucket.
-- ---------------------------------------------------------------------------
create or replace function public.admin_analytics_growth(
  p_from   date,
  p_to     date,
  p_bucket text default 'week',
  p_tz     text default 'UTC'
)
returns table (
  bucket_start     date,
  new_users        int,
  cumulative_users int,
  active_users     int
)
language plpgsql
stable
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_step  interval;
  v_first timestamp;
  v_last  timestamp;
  v_start timestamptz;
  v_end   timestamptz;
  v_base  bigint;
begin
  perform public.analytics_require_admin();
  perform public.analytics_check_tz(p_tz);
  if p_bucket is null or p_bucket not in ('week', 'month') then
    raise exception 'invalid bucket' using errcode = '22023';
  end if;
  if p_from is null or p_to is null or p_to < p_from or p_to - p_from > 1100 then
    raise exception 'invalid date range' using errcode = '22023';
  end if;

  v_step  := case p_bucket when 'week' then interval '1 week' else interval '1 month' end;
  v_first := date_trunc(p_bucket, p_from::timestamp);
  v_last  := date_trunc(p_bucket, p_to::timestamp);
  v_start := v_first at time zone p_tz;
  v_end   := (v_last + v_step) at time zone p_tz;

  select count(*) into v_base
    from auth.users u
   where u.deleted_at is null and u.created_at < v_start;

  return query
  with buckets as (
    select g::date as bucket_start
      from generate_series(v_first, v_last, v_step) as g
  ),
  reg as (
    select date_trunc(p_bucket, u.created_at at time zone p_tz)::date as bucket_start,
           count(*)::int as n
      from auth.users u
     where u.deleted_at is null and u.created_at >= v_start and u.created_at < v_end
     group by 1
  ),
  act as (
    select date_trunc(p_bucket, a.activity_at at time zone p_tz)::date as bucket_start,
           count(distinct a.user_id)::int as n
      from public.v_user_activity a
     where a.activity_at >= v_start and a.activity_at < v_end
     group by 1
  )
  select b.bucket_start,
         coalesce(reg.n, 0),
         (v_base + sum(coalesce(reg.n, 0)) over (order by b.bucket_start))::int,
         coalesce(act.n, 0)
    from buckets b
    left join reg on reg.bucket_start = b.bucket_start
    left join act on act.bucket_start = b.bucket_start
   order by b.bucket_start;
end;
$$;

-- ---------------------------------------------------------------------------
-- Android vs Web summary for a date range.
-- ---------------------------------------------------------------------------
create or replace function public.admin_analytics_platforms(
  p_from date,
  p_to   date,
  p_tz   text default 'UTC'
)
returns table (
  platform             text,
  total_users          int,
  active_users         int,
  sessions             int,
  avg_session_seconds  numeric,
  events               int
)
language plpgsql
stable
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_start timestamptz;
  v_end   timestamptz;
begin
  perform public.analytics_require_admin();
  perform public.analytics_check_tz(p_tz);
  if p_from is null or p_to is null or p_to < p_from or p_to - p_from > 366 then
    raise exception 'invalid date range' using errcode = '22023';
  end if;

  v_start := p_from::timestamp at time zone p_tz;
  v_end   := (p_to + 1)::timestamp at time zone p_tz;

  return query
  with plats(platform) as (values ('android'), ('web')),
  tot as (
    select d.platform, count(*)::int as n from public.user_devices d group by 1
  ),
  act as (
    select a.platform, count(distinct a.user_id)::int as n
      from public.v_user_activity a
     where a.activity_at >= v_start and a.activity_at < v_end
     group by 1
  ),
  ses as (
    select s.platform,
           count(*)::int as n,
           round(avg(least(extract(epoch from (coalesce(s.ended_at, s.last_seen_at) - s.started_at)), 14400))::numeric, 1) as avg_s
      from public.user_sessions s
     where s.started_at >= v_start and s.started_at < v_end
     group by 1
  ),
  ev as (
    select e.platform, count(*)::int as n
      from public.analytics_events e
     where e.created_at >= v_start and e.created_at < v_end
     group by 1
  )
  select p.platform,
         coalesce(tot.n, 0), coalesce(act.n, 0), coalesce(ses.n, 0),
         coalesce(ses.avg_s, 0), coalesce(ev.n, 0)
    from plats p
    left join tot on tot.platform = p.platform
    left join act on act.platform = p.platform
    left join ses on ses.platform = p.platform
    left join ev  on ev.platform  = p.platform
   order by p.platform;
end;
$$;

-- ---------------------------------------------------------------------------
-- Activity trends: events per day per event name.
-- ---------------------------------------------------------------------------
create or replace function public.admin_analytics_event_series(
  p_from date,
  p_to   date,
  p_tz   text default 'UTC'
)
returns table (
  day        date,
  event_name text,
  events     int,
  users      int
)
language plpgsql
stable
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_start timestamptz;
  v_end   timestamptz;
begin
  perform public.analytics_require_admin();
  perform public.analytics_check_tz(p_tz);
  if p_from is null or p_to is null or p_to < p_from or p_to - p_from > 366 then
    raise exception 'invalid date range' using errcode = '22023';
  end if;

  v_start := p_from::timestamp at time zone p_tz;
  v_end   := (p_to + 1)::timestamp at time zone p_tz;

  return query
  select (e.created_at at time zone p_tz)::date as day,
         e.event_name,
         count(*)::int,
         count(distinct e.user_id)::int
    from public.analytics_events e
   where e.created_at >= v_start and e.created_at < v_end
   group by 1, 2
   order by 1, 2;
end;
$$;

-- ---------------------------------------------------------------------------
-- Device / app analytics (aggregated; no identifiers).
-- ---------------------------------------------------------------------------
create or replace function public.admin_analytics_devices()
returns jsonb
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
  perform public.analytics_require_admin();

  return jsonb_build_object(
    'app_versions', (
      select coalesce(jsonb_agg(t order by t.platform, t.users desc, t.app_version), '[]'::jsonb)
        from (select d.platform, coalesce(d.app_version, 'unknown') as app_version, count(*)::int as users
                from public.user_devices d group by 1, 2) t),
    'android_os_versions', (
      select coalesce(jsonb_agg(t order by t.users desc, t.os_version), '[]'::jsonb)
        from (select coalesce(d.os_version, 'unknown') as os_version, count(*)::int as users
                from public.user_devices d where d.platform = 'android' group by 1) t),
    'android_device_models', (
      select coalesce(jsonb_agg(t order by t.users desc, t.device_model), '[]'::jsonb)
        from (select coalesce(d.device_model, 'unknown') as device_model, count(*)::int as users
                from public.user_devices d where d.platform = 'android'
               group by 1 order by 2 desc, 1 limit 20) t)
  );
end;
$$;

-- ---------------------------------------------------------------------------
-- Searchable, paginated user list. Returns identity + usage facts only.
-- Never selects password hashes, tokens, phone, IPs or raw metadata.
-- ---------------------------------------------------------------------------
create or replace function public.admin_analytics_users(
  p_search   text default null,
  p_platform text default null,
  p_status   text default null,
  p_sort     text default 'registered_desc',
  p_limit    int  default 25,
  p_offset   int  default 0
)
returns table (
  total_count    bigint,
  user_id        uuid,
  display_name   text,
  email          text,
  registered_at  timestamptz,
  last_active_at timestamptz,
  platform       text,
  app_version    text,
  total_sessions int,
  status         text
)
language plpgsql
stable
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_limit  int  := least(greatest(coalesce(p_limit, 25), 1), 100);
  v_offset int  := greatest(coalesce(p_offset, 0), 0);
  v_sort   text := coalesce(p_sort, 'registered_desc');
  v_like   text;
begin
  perform public.analytics_require_admin();

  if v_sort not in ('registered_desc', 'registered_asc', 'last_active_desc',
                    'sessions_desc', 'email_asc', 'name_asc') then
    raise exception 'invalid sort' using errcode = '22023';
  end if;
  if p_platform is not null and p_platform not in ('android', 'web', 'both', 'unknown') then
    raise exception 'invalid platform filter' using errcode = '22023';
  end if;
  if p_status is not null and p_status not in ('active', 'suspended', 'unconfirmed') then
    raise exception 'invalid status filter' using errcode = '22023';
  end if;

  if p_search is not null and btrim(p_search) <> '' then
    -- escape LIKE wildcards so user input is matched literally
    v_like := '%' || replace(replace(replace(left(btrim(p_search), 100), '\', '\\'), '%', '\%'), '_', '\_') || '%';
  end if;

  return query
  with base as (
    select u.id,
           coalesce(nullif(u.raw_user_meta_data ->> 'full_name', ''),
                    nullif(u.raw_user_meta_data ->> 'name', ''),
                    nullif(u.raw_user_meta_data ->> 'display_name', '')) as display_name,
           u.email::text as email,
           u.created_at  as registered_at,
           case when u.banned_until is not null and u.banned_until > now() then 'suspended'
                when u.email_confirmed_at is null                          then 'unconfirmed'
                else 'active' end as status
      from auth.users u
     where u.deleted_at is null
  ),
  dev as (
    select d.user_id,
           case when count(*) > 1 then 'both' else min(d.platform) end as platform,
           (array_agg(d.app_version order by d.last_seen_at desc))[1]  as app_version
      from public.user_devices d
     group by d.user_id
  ),
  ses as (
    select s.user_id, count(*)::int as n from public.user_sessions s group by s.user_id
  ),
  act as (
    select a.user_id, max(a.activity_at) as last_active from public.v_user_activity a group by a.user_id
  ),
  joined as (
    select b.id, b.display_name, b.email, b.registered_at, b.status,
           coalesce(dev.platform, 'unknown') as platform,
           dev.app_version,
           coalesce(ses.n, 0)  as sessions,
           act.last_active
      from base b
      left join dev on dev.user_id = b.id
      left join ses on ses.user_id = b.id
      left join act on act.user_id = b.id
  ),
  filtered as (
    select j.*
      from joined j
     where (v_like is null
            or j.email        ilike v_like
            or j.display_name ilike v_like
            or j.id::text     ilike v_like)
       and (p_platform is null or j.platform = p_platform)
       and (p_status   is null or j.status   = p_status)
  )
  select count(*) over ()::bigint,
         f.id, f.display_name, f.email, f.registered_at, f.last_active,
         f.platform, f.app_version, f.sessions, f.status
    from filtered f
   order by
     case when v_sort = 'registered_asc'   then f.registered_at end asc,
     case when v_sort = 'registered_desc'  then f.registered_at end desc,
     case when v_sort = 'last_active_desc' then f.last_active   end desc nulls last,
     case when v_sort = 'sessions_desc'    then f.sessions      end desc,
     case when v_sort = 'email_asc'        then f.email         end asc,
     case when v_sort = 'name_asc'         then lower(f.display_name) end asc nulls last,
     f.id
   limit v_limit offset v_offset;
end;
$$;

-- ---------------------------------------------------------------------------
-- Grants: callable by signed-in users, but every body starts with the admin
-- check, so non-admins always get 42501 'forbidden'. anon cannot call at all.
-- ---------------------------------------------------------------------------
revoke all on function public.admin_analytics_overview(text)                         from public, anon, authenticated;
revoke all on function public.admin_analytics_daily(date, date, text)                from public, anon, authenticated;
revoke all on function public.admin_analytics_growth(date, date, text, text)         from public, anon, authenticated;
revoke all on function public.admin_analytics_platforms(date, date, text)            from public, anon, authenticated;
revoke all on function public.admin_analytics_event_series(date, date, text)         from public, anon, authenticated;
revoke all on function public.admin_analytics_devices()                              from public, anon, authenticated;
revoke all on function public.admin_analytics_users(text, text, text, text, int, int) from public, anon, authenticated;

grant execute on function public.admin_analytics_overview(text)                         to authenticated;
grant execute on function public.admin_analytics_daily(date, date, text)                to authenticated;
grant execute on function public.admin_analytics_growth(date, date, text, text)         to authenticated;
grant execute on function public.admin_analytics_platforms(date, date, text)            to authenticated;
grant execute on function public.admin_analytics_event_series(date, date, text)         to authenticated;
grant execute on function public.admin_analytics_devices()                              to authenticated;
grant execute on function public.admin_analytics_users(text, text, text, text, int, int) to authenticated;
