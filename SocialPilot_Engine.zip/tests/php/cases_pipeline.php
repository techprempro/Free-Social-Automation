<?php

declare(strict_types=1);

use SocialPilot\App;
use SocialPilot\Http\HttpResponse;
use SocialPilot\Publish\LinkedInPublisher;
use SocialPilot\Publish\TelegramPublisher;
use SocialPilot\Support\Clock;

const TG_TOKEN = '123456789:AAEhBP0av28Abcdefghijklmnopqrstuv';
const LI_TOKEN = 'AQXlinkedin-secret-token-0123456789';
const ADMIN = 'a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f6';

// ------------------------------------------------------------ Telegram

T::test('Telegram: posts text + link, returns message id', function () {
    $http = (new FakeHttp())->on('~POST https://api\.telegram\.org/bot~', FakeHttp::json(200, ['ok' => true, 'result' => ['message_id' => 77]]));
    $r = (new TelegramPublisher($http, TG_TOKEN, '@mychannel'))->publish(['text' => 'Hello', 'link' => 'https://e.com/1']);
    T::ok($r->ok); T::eq($r->remoteId, '77');
    $b = json_decode((string) $http->log[0]['body'], true);
    T::eq($b, ['chat_id' => '@mychannel', 'text' => "Hello\n\nhttps://e.com/1"]);
    T::ok(str_ends_with($http->log[0]['url'], '/sendMessage'));
});

T::test('Telegram: bad token/chat id never reach the network; errors never leak the token', function () {
    $http = new FakeHttp();
    foreach ([['bad token', '@mychannel'], [TG_TOKEN, 'no spaces allowed'], [TG_TOKEN, '../x']] as [$t, $c]) {
        $r = (new TelegramPublisher($http, $t, $c))->publish(['text' => 'x']);
        T::ok(!$r->ok);
    }
    T::eq(count($http->log), 0);
    $http->on('~telegram~', FakeHttp::json(429, ['ok' => false, 'description' => 'Too Many Requests: ' . TG_TOKEN, 'parameters' => ['retry_after' => 12]]));
    $r = (new TelegramPublisher($http, TG_TOKEN, '-1001234567890'))->publish(['text' => 'x']);
    T::ok(!$r->ok);
    T::ok(!str_contains((string) $r->error, TG_TOKEN), 'token redacted');
    T::ok(str_contains((string) $r->error, '12'), 'retry_after shown');
});

// ------------------------------------------------------------ LinkedIn

T::test('LinkedIn: escapes Little Text Format characters', function () {
    T::eq(LinkedInPublisher::escapeCommentary('a (b) #tag @x [y] *z* _u_ ~t~ {k} <l> | \\'),
        'a \\(b\\) \\#tag \\@x \\[y\\] \\*z\\* \\_u\\_ \\~t\\~ \\{k\\} \\<l\\> \\| \\\\');
    T::eq(LinkedInPublisher::escapeCommentary('বাংলা পোস্ট'), 'বাংলা পোস্ট');
});

T::test('LinkedIn: sends versioned headers, article link, reads x-restli-id', function () {
    $http = (new FakeHttp())->on('~POST https://api\.linkedin\.com/rest/posts~', new HttpResponse(201, '', ['x-restli-id' => 'urn:li:share:99']));
    $r = (new LinkedInPublisher($http, LI_TOKEN, 'urn:li:person:abc123', '202607'))->publish(['text' => 'Great news (really)', 'link' => 'https://e.com/a']);
    T::ok($r->ok); T::eq($r->remoteId, 'urn:li:share:99');
    $req = $http->log[0];
    T::eq($req['headers']['Authorization'], 'Bearer ' . LI_TOKEN);
    T::eq($req['headers']['Linkedin-Version'], '202607');
    T::eq($req['headers']['X-Restli-Protocol-Version'], '2.0.0');
    $b = json_decode((string) $req['body'], true);
    T::eq($b['author'], 'urn:li:person:abc123');
    T::eq($b['visibility'], 'PUBLIC');
    T::eq($b['lifecycleState'], 'PUBLISHED');
    T::eq($b['commentary'], 'Great news \\(really\\)');
    T::eq($b['content']['article']['source'], 'https://e.com/a');
});

T::test('LinkedIn: 401 mentions expired token without leaking it; invalid urn/version rejected offline', function () {
    $http = (new FakeHttp())->on('~linkedin~', FakeHttp::json(401, ['message' => 'bad ' . LI_TOKEN]));
    $r = (new LinkedInPublisher($http, LI_TOKEN, 'urn:li:organization:5', '202607'))->publish(['text' => 'x']);
    T::ok(!$r->ok);
    T::ok(!str_contains((string) $r->error, LI_TOKEN));
    T::ok(stripos((string) $r->error, 'expired') !== false);
    $n = count($http->log);
    T::ok(!(new LinkedInPublisher($http, LI_TOKEN, 'urn:li:bogus:1', '202607'))->publish(['text' => 'x'])->ok);
    T::ok(!(new LinkedInPublisher($http, LI_TOKEN, 'urn:li:person:1', 'latest'))->publish(['text' => 'x'])->ok);
    T::eq(count($http->log), $n, 'no request sent');
});

// ------------------------------------------------------------ pipeline

function appFixture(array $cfg = [], ?FakeHttp $http = null): array
{
    $clock = new Clock(utc('2026-11-25 08:00:00'));
    $http ??= new FakeHttp();
    $http->on('~news\.google\.com/rss/search~', new HttpResponse(200, newsRss([
        ['title' => 'Cricket team wins final - Prothom Alo', 'link' => 'https://e.com/a1', 'date' => 'Wed, 25 Nov 2026 07:00:00 GMT', 'source' => 'Prothom Alo'],
        ['title' => 'Cricket team wins the final - Daily Star', 'link' => 'https://e.com/a2', 'date' => 'Wed, 25 Nov 2026 06:30:00 GMT', 'source' => 'Daily Star'],
    ])));
    $http->on('~trends\.google\.com~', new HttpResponse(200, '<rss><channel></channel></rss>'));
    $http->on('~generateContent~', geminiReply(['pick_id' => 0, 'virality_score' => 80, 'reason' => 'hot', 'safe' => true, 'sensitivity' => 'none',
        'posts' => ['telegram' => 'Fun cricket win today', 'linkedin' => 'A reflection on teamwork']]));
    $http->on('~api\.telegram\.org~', FakeHttp::json(200, ['ok' => true, 'result' => ['message_id' => 5]]));
    $http->on('~api\.linkedin\.com~', new HttpResponse(201, '', ['x-restli-id' => 'urn:li:share:1']));
    $pdo = sqlite();
    $app = App::build($cfg + [
        'admin_token' => ADMIN, 'gemini' => ['api_key' => 'gem-key-123456'],
        'telegram' => ['bot_token' => TG_TOKEN, 'chat_id' => '@chan'],
        'linkedin' => ['access_token' => LI_TOKEN, 'author_urn' => 'urn:li:person:abc'],
    ], $pdo, $http, $clock);
    return [$app, $http, $clock];
}

function newTopic(App $app, array $over = []): array
{
    $id = $app->store->saveTopic(\SocialPilot\Api\TopicValidator::clean($over + [
        'name' => 'Cricket', 'keywords' => ['cricket'], 'language' => 'en', 'region' => 'BD',
        'platforms' => ['telegram', 'linkedin'], 'auto_publish' => true,
    ]));
    return $app->store->getTopic($id);
}

T::test('Pipeline: topic run publishes one story to Telegram and LinkedIn, then cooldown blocks a repeat', function () {
    [$app, $http, $clock] = appFixture();
    $res = $app->runner->runTopic(newTopic($app));
    T::eq($res['status'], 'published', json_encode($res));
    T::eq(count($res['posts']), 2);
    T::eq(count($http->requests('~api\.telegram\.org~')), 1);
    T::eq(count($http->requests('~api\.linkedin\.com~')), 1);
    $again = $app->runner->runTopic(newTopic($app, ['name' => 'Cricket']));
    T::ok(in_array($again['status'], ['cooldown', 'quota_reached', 'limit', 'duplicate_story'], true), $again['status']);
    T::eq(count($http->requests('~api\.telegram\.org~')), 1, 'no second post');
});

T::test('Pipeline: dry run publishes nothing and stores no posts', function () {
    [$app, $http] = appFixture();
    $res = $app->runner->runTopic(newTopic($app), true);
    T::eq($res['status'], 'dry_run');
    T::eq(count($http->requests('~api\.telegram\.org|api\.linkedin\.com~')), 0);
    T::eq($app->store->listPosts(null, 10, 0), []);
});

T::test('Pipeline: auto_publish=false saves drafts; publishSaved sends them; reject works', function () {
    [$app, $http] = appFixture();
    $res = $app->runner->runTopic(newTopic($app, ['auto_publish' => false]));
    T::eq(count($http->requests('~api\.telegram\.org~')), 0);
    $drafts = $app->store->listPosts('draft', 10, 0);
    T::eq(count($drafts), 2);
    $r = $app->runner->publishSaved((int) $drafts[0]['id']);
    T::ok($r['ok'], json_encode($r));
    T::eq($app->store->getPost((int) $drafts[0]['id'])['status'], 'published');
    [$code] = $app->admin->handle('POST', '/posts/' . $drafts[1]['id'] . '/reject', [], null, 'Bearer ' . ADMIN);
    T::eq($code, 200);
    T::eq($app->store->getPost((int) $drafts[1]['id'])['status'], 'rejected');
    T::ok(!$app->runner->publishSaved((int) $drafts[1]['id'])['ok'], 'rejected cannot be published');
});

T::test('Pipeline: sensitive story or review keyword never auto-publishes', function () {
    [$app, $http] = appFixture();
    $http->on('~generateContent~', geminiReply(['pick_id' => 0, 'virality_score' => 90, 'reason' => 'x', 'safe' => true, 'sensitivity' => 'tragedy',
        'posts' => ['telegram' => 'sad news', 'linkedin' => 'sad news']]));
    $res = $app->runner->runTopic(newTopic($app));
    T::eq(count($http->requests('~api\.telegram\.org~')), 0);
    T::ok(count($app->store->listPosts('draft', 10, 0)) >= 1, json_encode($res));
});

T::test('Pipeline: AI text with a URL is blocked, not published', function () {
    [$app, $http] = appFixture();
    $http->on('~generateContent~', geminiReply(['pick_id' => 0, 'virality_score' => 90, 'reason' => 'x', 'safe' => true, 'sensitivity' => 'none',
        'posts' => ['telegram' => 'visit http://evil.example now', 'linkedin' => 'fine text']]));
    $app->runner->runTopic(newTopic($app));
    T::eq(count($http->requests('~api\.telegram\.org~')), 0);
    T::eq(count($app->store->listPosts('blocked', 10, 0)), 1);
});

T::test('Pipeline: pause stops runs; no AI key reports ai_not_configured', function () {
    [$app] = appFixture();
    $app->store->setSetting('paused', '1');
    T::eq($app->runner->runTopic(newTopic($app))['status'], 'paused');
    [$app2] = appFixture(['gemini' => ['api_key' => '']]);
    T::eq($app2->runner->runTopic(newTopic($app2))['status'], 'ai_not_configured');
});

T::test('Pipeline: daily cap stops extra posts', function () {
    [$app, $http, $clock] = appFixture(['limits' => ['telegram' => ['daily' => 1, 'gap_minutes' => 0], 'linkedin' => ['daily' => 1, 'gap_minutes' => 0]], 'cooldown_minutes' => 0]);
    $app->runner->runTopic(newTopic($app));
    $http->on('~news\.google\.com/rss/search~', new HttpResponse(200, newsRss([
        ['title' => 'Different story entirely - Jugantor', 'link' => 'https://e.com/z', 'date' => 'Wed, 25 Nov 2026 07:30:00 GMT', 'source' => 'Jugantor'],
    ])));
    $clock->advance(3600);
    $app->runner->runTopic($app->store->getTopic(1));
    T::eq(count($http->requests('~api\.telegram\.org~')), 1, 'cap respected');
});

// ------------------------------------------------------------ admin API + tracker

T::test('AdminApi: rejects missing/wrong token, disabled without a long token, never returns secrets', function () {
    [$app] = appFixture();
    T::eq($app->admin->handle('GET', '/status', [], null, null)[0], 401);
    T::eq($app->admin->handle('GET', '/status', [], null, 'Bearer wrong')[0], 401);
    [$c, $d] = $app->admin->handle('GET', '/status', [], null, 'Bearer ' . ADMIN);
    T::eq($c, 200);
    T::eq($d['platforms_configured']['telegram'], true);
    T::eq($d['platforms_configured']['x'], false);
    $json = json_encode($d);
    T::ok(!str_contains($json, TG_TOKEN) && !str_contains($json, LI_TOKEN) && !str_contains($json, 'gem-key'));
    [$short] = appFixture(['admin_token' => 'short']);
    T::eq($short->admin->handle('GET', '/status', [], null, 'Bearer short')[0], 503);
});

T::test('AdminApi: topic CRUD + validation errors + 404', function () {
    [$app] = appFixture();
    $h = fn ($m, $p, $b = null) => $app->admin->handle($m, $p, [], $b, 'Bearer ' . ADMIN);
    [$c, $d] = $h('POST', '/topics', ['name' => 'Tech', 'keywords' => ['ai'], 'platforms' => ['linkedin']]);
    T::eq($c, 201);
    $id = $d['topic']['id'];
    T::eq($h('POST', '/topics', ['name' => '', 'keywords' => [], 'platforms' => ['myspace']])[0], 422);
    T::eq($h('PUT', "/topics/$id", ['name' => 'Tech2', 'keywords' => ['ai'], 'platforms' => ['telegram']])[1]['topic']['name'], 'Tech2');
    T::eq($h('PUT', '/topics/999', ['name' => 'x', 'keywords' => ['ai'], 'platforms' => ['x']])[0], 404);
    T::eq($h('DELETE', "/topics/$id")[0], 200);
    T::eq($h('GET', '/nope')[0], 404);
    T::eq($app->admin->handle('GET', '/posts', ['status' => 'bogus'], null, 'Bearer ' . ADMIN)[0], 422);
    T::eq($app->admin->handle('GET', '/posts', ['status' => 'draft'], null, 'Bearer ' . ADMIN)[0], 200);
});

T::test('AdminApi: image URLs must be https', function () {
    [$app] = appFixture();
    $h = fn ($b) => $app->admin->handle('POST', '/images', [], $b, 'Bearer ' . ADMIN)[0];
    T::eq($h(['url' => 'http://x.com/a.jpg']), 422);
    T::eq($h(['url' => 'javascript:alert(1)']), 422);
    T::eq($h(['url' => 'https://x.com/a.jpg']), 201);
});

T::test('AppTracker: accepts valid app ping, rejects bad data, counts one install per id', function () {
    [$app] = appFixture();
    $ok = ['installation_id' => 'abcdef0123456789abcd', 'device_name' => 'Samsung SM-A135F', 'platform' => 'android', 'app_version' => '1.0.0'];
    T::eq($app->tracker->record($ok)[0], 200);
    T::eq($app->tracker->record($ok)[0], 200);
    foreach ([['installation_id' => 'short'] + $ok, ['platform' => 'tv'] + $ok, ['app_version' => '<script>'] + $ok] as $bad) {
        T::eq($app->tracker->record($bad)[0], 422);
    }
    $now = $app->store->installStats('2026-11-25 00:00:00', '2026-11-19 00:00:00', '2026-11-01 00:00:00');
    T::ok(json_encode($now) !== '', 'stats readable');
});
