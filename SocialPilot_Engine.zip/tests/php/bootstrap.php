<?php

declare(strict_types=1);

// Tiny dependency-free test harness (no PHPUnit/composer needed) + fakes used by every test file.

use SocialPilot\Http\HttpClient;
use SocialPilot\Http\HttpException;
use SocialPilot\Http\HttpResponse;

spl_autoload_register(function (string $class): void {
    $prefix = 'SocialPilot\\';
    if (str_starts_with($class, $prefix)) {
        $file = __DIR__ . '/../../laravel/src/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
        if (is_file($file)) {
            require $file;
        }
    }
});

final class T
{
    public static int $passed = 0;
    /** @var string[] */
    public static array $failures = [];
    public static string $current = '';

    public static function test(string $name, callable $fn): void
    {
        self::$current = $name;
        try {
            $fn();
            self::$passed++;
            echo "ok - $name\n";
        } catch (\Throwable $e) {
            self::$failures[] = $name . ': ' . $e->getMessage() . ' (' . basename($e->getFile()) . ':' . $e->getLine() . ')';
            echo "FAIL - $name\n    " . $e->getMessage() . ' (' . basename($e->getFile()) . ':' . $e->getLine() . ")\n";
        }
    }

    public static function eq(mixed $actual, mixed $expected, string $msg = ''): void
    {
        if ($actual !== $expected) {
            throw new \RuntimeException(($msg ? "$msg: " : '') . 'expected ' . var_export($expected, true) . ' got ' . var_export($actual, true));
        }
    }

    public static function ok(bool $cond, string $msg = 'condition failed'): void
    {
        if (!$cond) {
            throw new \RuntimeException($msg);
        }
    }

    public static function throws(callable $fn, string $class, string $msg = ''): void
    {
        try {
            $fn();
        } catch (\Throwable $e) {
            if ($e instanceof $class) {
                return;
            }
            throw new \RuntimeException(($msg ? "$msg: " : '') . "expected $class, got " . get_class($e) . ': ' . $e->getMessage());
        }
        throw new \RuntimeException(($msg ? "$msg: " : '') . "expected $class but nothing was thrown");
    }
}

/** Scripted HTTP: routes are regexes matched against "METHOD url"; every request is recorded. */
final class FakeHttp implements HttpClient
{
    /** @var array<int,array{0:string,1:mixed}> */
    private array $routes = [];
    /** @var array<int,array{method:string,url:string,headers:array<string,string>,body:?string}> */
    public array $log = [];

    /** @param HttpResponse|callable $response */
    public function on(string $regex, mixed $response): self
    {
        array_unshift($this->routes, [$regex, $response]); // later routes win
        return $this;
    }

    public static function json(int $status, array $data): HttpResponse
    {
        return new HttpResponse($status, (string) json_encode($data, JSON_UNESCAPED_UNICODE));
    }

    public function request(string $method, string $url, array $headers = [], ?string $body = null, int $timeout = 20): HttpResponse
    {
        $this->log[] = ['method' => $method, 'url' => $url, 'headers' => $headers, 'body' => $body];
        foreach ($this->routes as [$regex, $resp]) {
            if (preg_match($regex, "$method $url")) {
                return is_callable($resp) ? $resp($method, $url, $headers, $body) : $resp;
            }
        }
        throw new HttpException("no fake route for $method $url");
    }

    /** @return array<int,array{method:string,url:string,headers:array<string,string>,body:?string}> */
    public function requests(string $regex): array
    {
        return array_values(array_filter($this->log, fn ($r) => preg_match($regex, $r['method'] . ' ' . $r['url']) === 1));
    }
}

function newsRss(array $items): string
{
    $x = '<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>feed</title>';
    foreach ($items as $i) {
        $x .= '<item><title>' . htmlspecialchars($i['title'], ENT_XML1) . '</title><link>' . htmlspecialchars($i['link'], ENT_XML1) . '</link>'
            . '<pubDate>' . $i['date'] . '</pubDate>' . (isset($i['source']) ? '<source url="https://x.example">' . $i['source'] . '</source>' : '') . '</item>';
    }
    return $x . '</channel></rss>';
}

function geminiReply(array $json): HttpResponse
{
    return FakeHttp::json(200, ['candidates' => [['content' => ['parts' => [['text' => json_encode($json, JSON_UNESCAPED_UNICODE)]]]]]]);
}

function sqlite(): PDO
{
    $pdo = new PDO('sqlite::memory:');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    \SocialPilot\Storage\SchemaInstaller::install($pdo);
    return $pdo;
}

function utc(string $s): DateTimeImmutable
{
    return new DateTimeImmutable($s, new DateTimeZone('UTC'));
}
