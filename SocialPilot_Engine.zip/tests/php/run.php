<?php

declare(strict_types=1);

// Runs every tests/php/cases_*.php file.   Usage: php tests/php/run.php [filter]
// Exit code 1 if any test fails, so CI can gate on it. No composer / PHPUnit needed.

date_default_timezone_set('UTC');
require __DIR__ . '/bootstrap.php';

$filter = $argv[1] ?? '';
$files = glob(__DIR__ . '/cases_*.php') ?: [];
sort($files);
foreach ($files as $file) {
    if ($filter !== '' && !str_contains(basename($file), $filter)) {
        continue;
    }
    echo "\n# " . basename($file) . "\n";
    require $file;
}

echo "\n" . T::$passed . ' passed, ' . count(T::$failures) . " failed\n";
if (T::$failures) {
    foreach (T::$failures as $f) {
        echo " - $f\n";
    }
    exit(1);
}
