<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use SocialPilot\Storage\SchemaInstaller;

/** Creates the sp_* tables with the same DDL the tests run (MySQL, utf8mb4). */
return new class extends Migration {
    public function up(): void
    {
        SchemaInstaller::install(DB::connection()->getPdo());
    }

    public function down(): void
    {
        foreach (['sp_installs', 'sp_settings', 'sp_images', 'sp_events', 'sp_posts', 'sp_candidates', 'sp_topics'] as $table) {
            DB::statement("DROP TABLE IF EXISTS $table");
        }
    }
};
