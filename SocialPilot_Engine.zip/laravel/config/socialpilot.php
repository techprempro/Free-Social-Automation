<?php

/*
 * Copy to config/socialpilot.php in your Laravel app and put the values in .env (never commit secrets).
 * Anything left empty simply disables that platform / feature.
 */
return [
    'timezone' => env('SOCIALPILOT_TIMEZONE', 'Asia/Dhaka'),

    // Owner token for the panel and /api/socialpilot/admin/*. Use 32+ random characters:
    //   php -r "echo bin2hex(random_bytes(24)), PHP_EOL;"
    'admin_token' => env('SOCIALPILOT_ADMIN_TOKEN', ''),

    // Google AI Studio key (https://aistudio.google.com/apikey). Check the model name is still available.
    'gemini' => [
        'api_key' => env('GEMINI_API_KEY', ''),
        'model' => env('GEMINI_MODEL', 'gemini-3.8-flash'),
        // Backup models, comma separated, used when the main one is busy (503/429) or unavailable (404).
        'fallback_models' => array_values(array_filter(array_map('trim', explode(',', (string) env('GEMINI_FALLBACK_MODELS', ''))))),
    ],

    // Facebook Page you manage: Page ID + a Page access token with pages_manage_posts.
    'facebook' => [
        'page_id' => env('FACEBOOK_PAGE_ID', ''),
        'page_token' => env('FACEBOOK_PAGE_TOKEN', ''),
        'graph_version' => env('META_GRAPH_VERSION', 'v26.0'),
    ],

    // Instagram professional account linked to the Page: IG user ID + token with instagram_content_publish.
    'instagram' => [
        'user_id' => env('INSTAGRAM_USER_ID', ''),
        'token' => env('INSTAGRAM_TOKEN', ''),
        'graph_version' => env('META_GRAPH_VERSION', 'v26.0'),
    ],

    // X developer app (OAuth 1.0a keys + access token of YOUR account, "Read and write" permission).
    'x' => [
        'consumer_key' => env('X_API_KEY', ''),
        'consumer_secret' => env('X_API_SECRET', ''),
        'access_token' => env('X_ACCESS_TOKEN', ''),
        'access_token_secret' => env('X_ACCESS_TOKEN_SECRET', ''),
    ],

    // Telegram channel: create a bot with @BotFather, add it as ADMIN of the channel. chat_id = @channelname or -100...
    'telegram' => [
        'bot_token' => env('TELEGRAM_BOT_TOKEN', ''),
        'chat_id' => env('TELEGRAM_CHAT_ID', ''),
    ],

    // LinkedIn: author_urn = urn:li:person:{id} (token scope w_member_social) or urn:li:organization:{id}
    // (w_organization_social, needs LinkedIn approval). Tokens last ~60 days. version = API version YYYYMM.
    'linkedin' => [
        'access_token' => env('LINKEDIN_ACCESS_TOKEN', ''),
        'author_urn' => env('LINKEDIN_AUTHOR_URN', ''),
        'version' => env('LINKEDIN_API_VERSION', '202607'),
    ],

    // Hard safety limits so automation can never flood a page.
    'limits' => [
        'facebook' => ['daily' => 6, 'gap_minutes' => 90],
        'x' => ['daily' => 8, 'gap_minutes' => 60],
        'instagram' => ['daily' => 3, 'gap_minutes' => 240],
        'telegram' => ['daily' => 10, 'gap_minutes' => 30],
        'linkedin' => ['daily' => 3, 'gap_minutes' => 240],
    ],

    'candidates_for_ai' => 12,
    'cooldown_minutes' => 60,

    // Words that are never allowed in a post.
    'blocked_terms' => [],
];
