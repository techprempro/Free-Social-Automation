<?php

declare(strict_types=1);

namespace SocialPilot;

use SocialPilot\Ai\Editor;
use SocialPilot\Ai\GeminiClient;
use SocialPilot\Api\AdminApi;
use SocialPilot\Api\AppTracker;
use SocialPilot\Api\Report;
use SocialPilot\Http\CurlHttpClient;
use SocialPilot\Http\HttpClient;
use SocialPilot\Pipeline\PostLimiter;
use SocialPilot\Pipeline\Runner;
use SocialPilot\Publish\FacebookPagePublisher;
use SocialPilot\Publish\InstagramPublisher;
use SocialPilot\Publish\LinkedInPublisher;
use SocialPilot\Publish\OAuth1Signer;
use SocialPilot\Publish\TelegramPublisher;
use SocialPilot\Publish\XPublisher;
use SocialPilot\Safety\ContentGuard;
use SocialPilot\Storage\Store;
use SocialPilot\Support\Clock;
use SocialPilot\Support\Config;
use SocialPilot\Trends\TrendCollector;

/** Wires everything together from one config array. Used by the Laravel service provider and by the tests. */
final class App
{
    public function __construct(
        public readonly Config $config,
        public readonly Store $store,
        public readonly Runner $runner,
        public readonly AdminApi $admin,
        public readonly AppTracker $tracker,
    ) {
    }

    /** @return array<string,mixed> */
    public static function defaults(): array
    {
        return [
            'timezone' => 'Asia/Dhaka',
            'admin_token' => '',
            'gemini' => ['api_key' => '', 'model' => 'gemini-3.8-flash', 'fallback_models' => []],
            'facebook' => ['page_id' => '', 'page_token' => '', 'graph_version' => 'v26.0'],
            'instagram' => ['user_id' => '', 'token' => '', 'graph_version' => 'v26.0'],
            'x' => ['consumer_key' => '', 'consumer_secret' => '', 'access_token' => '', 'access_token_secret' => ''],
            'telegram' => ['bot_token' => '', 'chat_id' => ''],
            'linkedin' => ['access_token' => '', 'author_urn' => '', 'version' => '202607'],
            'limits' => [
                'facebook' => ['daily' => 6, 'gap_minutes' => 90],
                'x' => ['daily' => 8, 'gap_minutes' => 60],
                'instagram' => ['daily' => 3, 'gap_minutes' => 240],
                'telegram' => ['daily' => 10, 'gap_minutes' => 30],
                'linkedin' => ['daily' => 3, 'gap_minutes' => 240],
            ],
            'candidates_for_ai' => 12,
            'cooldown_minutes' => 60,
            'blocked_terms' => [],
            // Posts containing these words are never auto-published: they wait for one tap in the panel.
            'review_keywords' => [
                'killed', 'dead', 'death', 'died', 'murder', 'rape', 'suicide', 'terror', 'attack', 'accident', 'crash', 'shooting',
                'নিহত', 'মৃত্যু', 'খুন', 'ধর্ষণ', 'আত্মহত্যা', 'হামলা', 'দুর্ঘটনা', 'লাশ', 'গুলি',
            ],
        ];
    }

    /** @param array<string,mixed> $userConfig */
    public static function build(array $userConfig, \PDO $pdo, ?HttpClient $http = null, ?Clock $clock = null): self
    {
        $merged = array_replace_recursive(self::defaults(), $userConfig);
        foreach (['review_keywords', 'blocked_terms'] as $listKey) { // lists must be replaced, not merged index by index
            if (array_key_exists($listKey, $userConfig)) {
                $merged[$listKey] = $userConfig[$listKey];
            }
        }
        $config = new Config($merged);
        $http ??= new CurlHttpClient();
        $clock ??= new Clock();
        $store = new Store($pdo, $clock);

        $publishers = [];
        if ($config->has('facebook.page_id') && $config->has('facebook.page_token')) {
            $publishers['facebook'] = new FacebookPagePublisher($http, $config->string('facebook.page_id'), $config->string('facebook.page_token'), $config->string('facebook.graph_version'));
        }
        if ($config->has('instagram.user_id') && $config->has('instagram.token')) {
            $publishers['instagram'] = new InstagramPublisher($http, $config->string('instagram.user_id'), $config->string('instagram.token'), $config->string('instagram.graph_version'));
        }
        if ($config->has('x.consumer_key') && $config->has('x.consumer_secret') && $config->has('x.access_token') && $config->has('x.access_token_secret')) {
            $publishers['x'] = new XPublisher(
                $http,
                new OAuth1Signer($config->string('x.consumer_key'), $config->string('x.consumer_secret'), $config->string('x.access_token'), $config->string('x.access_token_secret')),
                [$config->string('x.consumer_secret'), $config->string('x.access_token'), $config->string('x.access_token_secret')],
            );
        }

        if ($config->has('telegram.bot_token') && $config->has('telegram.chat_id')) {
            $publishers['telegram'] = new TelegramPublisher($http, $config->string('telegram.bot_token'), $config->string('telegram.chat_id'));
        }
        if ($config->has('linkedin.access_token') && $config->has('linkedin.author_urn')) {
            $publishers['linkedin'] = new LinkedInPublisher($http, $config->string('linkedin.access_token'), $config->string('linkedin.author_urn'), $config->string('linkedin.version') ?: '202607');
        }

        $editor = $config->has('gemini.api_key')
            ? new Editor(new GeminiClient($http, $config->string('gemini.api_key'), $config->string('gemini.model'), 'https://generativelanguage.googleapis.com/v1beta', (array) $config->get('gemini.fallback_models', [])), $clock)
            : null;

        $guard = new ContentGuard((array) $config->get('blocked_terms', []), (array) $config->get('review_keywords', []));
        $runner = new Runner($store, $clock, $config, new TrendCollector($http, $clock), $editor, $guard, new PostLimiter($store, $clock, $config), $publishers);
        $admin = new AdminApi($store, $runner, new Report($store, $clock, $config), $config, array_keys($publishers), $editor !== null);

        return new self($config, $store, $runner, $admin, new AppTracker($store));
    }
}
