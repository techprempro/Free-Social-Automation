<?php

declare(strict_types=1);

namespace SocialPilot\Publish;

use SocialPilot\Http\HttpClient;

/** Publishes to a Facebook Page you manage through the official Graph API (needs a Page access token). */
final class FacebookPagePublisher implements Publisher
{
    public function __construct(
        private HttpClient $http,
        private string $pageId,
        private string $pageToken,
        private string $graphVersion = 'v26.0',
    ) {
    }

    public function platform(): string
    {
        return 'facebook';
    }

    public function publish(array $post): PublishResult
    {
        $form = ['message' => $post['text'], 'access_token' => $this->pageToken];
        if (!empty($post['link'])) {
            $form['link'] = $post['link'];
        }
        $url = 'https://graph.facebook.com/' . $this->graphVersion . '/' . rawurlencode($this->pageId) . '/feed';
        try {
            $res = $this->http->request('POST', $url, ['Content-Type' => 'application/x-www-form-urlencoded'], http_build_query($form));
        } catch (\Throwable $e) {
            return PublishResult::failure(Redact::clean($e->getMessage(), [$this->pageToken]));
        }
        $data = $res->json() ?? [];
        if ($res->ok() && isset($data['id']) && is_string($data['id'])) {
            return PublishResult::success($data['id']);
        }
        $code = $data['error']['code'] ?? '';
        $msg = (string) ($data['error']['message'] ?? 'unknown error');
        if ((int) $code === 190) {
            $msg = 'Facebook access token is invalid or expired - create a new Page token. ' . $msg;
        }
        return PublishResult::failure('Facebook HTTP ' . $res->status . ': ' . Redact::clean($msg, [$this->pageToken]));
    }
}
