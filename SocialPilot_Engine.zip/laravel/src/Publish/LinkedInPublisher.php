<?php

declare(strict_types=1);

namespace SocialPilot\Publish;

use SocialPilot\Http\HttpClient;

/**
 * Posts to LinkedIn with the official Posts API (POST /rest/posts).
 *  - Personal profile: author "urn:li:person:{id}", token scope w_member_social ("Share on LinkedIn" product).
 *  - Company page:     author "urn:li:organization:{id}", token scope w_organization_social (needs LinkedIn approval).
 * Member tokens expire after about 60 days; when posting starts failing with 401, create a new token.
 */
final class LinkedInPublisher implements Publisher
{
    private const URL = 'https://api.linkedin.com/rest/posts';

    public function __construct(
        private HttpClient $http,
        private string $accessToken,
        private string $authorUrn,
        private string $version = '202607', // YYYYMM API version; LinkedIn retires old ones after about a year
    ) {
    }

    public function platform(): string
    {
        return 'linkedin';
    }

    /**
     * The "commentary" field uses LinkedIn's Little Text Format, where | { } @ [ ] ( ) < > # \ * _ ~ are markup.
     * Unescaped, a "(" silently cuts the post off, so every reserved character gets a backslash.
     */
    public static function escapeCommentary(string $text): string
    {
        return (string) preg_replace('/([\\\\|{}@\[\]()<>#*_~])/u', '\\\\$1', $text);
    }

    public function publish(array $post): PublishResult
    {
        if (!preg_match('/^urn:li:(?:person|organization):[A-Za-z0-9_-]{1,40}$/', $this->authorUrn)) {
            return PublishResult::failure('LinkedIn author is invalid (expected urn:li:person:... or urn:li:organization:...)');
        }
        if (!preg_match('/^\d{6}$/', $this->version)) {
            return PublishResult::failure('LinkedIn API version must look like 202607 (YYYYMM)');
        }
        $body = [
            'author' => $this->authorUrn,
            'commentary' => self::escapeCommentary($post['text']),
            'visibility' => 'PUBLIC',
            'distribution' => ['feedDistribution' => 'MAIN_FEED', 'targetEntities' => [], 'thirdPartyDistributionChannels' => []],
            'lifecycleState' => 'PUBLISHED',
            'isReshareDisabledByAuthor' => false,
        ];
        if (!empty($post['link'])) {
            // LinkedIn does not scrape the URL, so the card title must be provided (plain text, not Little Text Format).
            $title = trim((string) preg_replace('/\s+/u', ' ', $post['text']));
            $body['content'] = ['article' => ['source' => $post['link'], 'title' => mb_substr($title, 0, 100)]];
        }
        try {
            $res = $this->http->request('POST', self::URL, [
                'Authorization' => 'Bearer ' . $this->accessToken,
                'Linkedin-Version' => $this->version,
                'X-Restli-Protocol-Version' => '2.0.0',
                'Content-Type' => 'application/json',
            ], (string) json_encode($body, JSON_UNESCAPED_UNICODE));
        } catch (\Throwable $e) {
            return PublishResult::failure(Redact::clean($e->getMessage(), [$this->accessToken]));
        }
        if ($res->status === 201) {
            return PublishResult::success($res->headers['x-restli-id'] ?? 'created'); // post URN arrives in a header, body is empty
        }
        $data = $res->json() ?? [];
        $msg = (string) ($data['message'] ?? $data['code'] ?? 'unknown error');
        if ($res->status === 401) {
            $msg = 'LinkedIn token is invalid or expired - create a new access token. ' . $msg;
        }
        return PublishResult::failure('LinkedIn HTTP ' . $res->status . ': ' . Redact::clean($msg, [$this->accessToken]));
    }
}
