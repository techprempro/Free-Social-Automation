<?php

declare(strict_types=1);

namespace SocialPilot\Publish;

/** Removes secrets from any text before it is stored or shown (errors end up in the database and admin panel). */
final class Redact
{
    /** @param string[] $secrets */
    public static function clean(string $text, array $secrets): string
    {
        foreach ($secrets as $s) {
            if (strlen($s) >= 6) {
                $text = str_replace($s, '[REDACTED]', $text);
            }
        }
        $text = (string) preg_replace('/(access_token|api[_-]?key|oauth_signature|token)=[^&\s"]+/i', '$1=[REDACTED]', $text);
        return mb_substr($text, 0, 400);
    }
}
