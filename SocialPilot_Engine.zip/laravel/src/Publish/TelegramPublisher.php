<?php

declare(strict_types=1);

namespace SocialPilot\Publish;

use SocialPilot\Http\HttpClient;

/**
 * Posts to a Telegram channel or group with the official Bot API (sendMessage).
 * Setup: create a bot with @BotFather, add the bot as an ADMIN of your channel (permission "Post messages").
 * chat_id is "@channelname" for public channels or a numeric id such as -1001234567890.
 * Telegram only accepts the bot token inside the URL path, so it is redacted from every error and never logged.
 */
final class TelegramPublisher implements Publisher
{
    public function __construct(private HttpClient $http, private string $botToken, private string $chatId)
    {
    }

    public function platform(): string
    {
        return 'telegram';
    }

    public function publish(array $post): PublishResult
    {
        // Validate before building a URL: a malformed token could otherwise change the request path.
        if (!preg_match('/^\d{3,}:[A-Za-z0-9_-]{10,}$/', $this->botToken)) {
            return PublishResult::failure('Telegram bot token format is invalid (expected 123456:ABC-DEF...)');
        }
        if (!preg_match('/^(?:@[A-Za-z][A-Za-z0-9_]{3,}|-?\d{5,})$/', $this->chatId)) {
            return PublishResult::failure('Telegram chat id is invalid (use @channelname or a numeric id like -1001234567890)');
        }
        $text = trim($post['text'] . (!empty($post['link']) ? "\n\n" . $post['link'] : ''));
        try {
            $res = $this->http->request(
                'POST',
                'https://api.telegram.org/bot' . $this->botToken . '/sendMessage',
                ['Content-Type' => 'application/json'],
                (string) json_encode(['chat_id' => $this->chatId, 'text' => $text], JSON_UNESCAPED_UNICODE),
            );
        } catch (\Throwable $e) {
            return PublishResult::failure(Redact::clean($e->getMessage(), [$this->botToken]));
        }
        $data = $res->json() ?? [];
        $messageId = $data['result']['message_id'] ?? null;
        if ($res->ok() && ($data['ok'] ?? false) === true && is_int($messageId)) {
            return PublishResult::success((string) $messageId);
        }
        $msg = (string) ($data['description'] ?? 'unknown error');
        $wait = $data['parameters']['retry_after'] ?? null;
        if (is_int($wait)) {
            $msg .= " (Telegram asks to wait {$wait}s)";
        }
        return PublishResult::failure('Telegram HTTP ' . $res->status . ': ' . Redact::clean($msg, [$this->botToken]));
    }
}
