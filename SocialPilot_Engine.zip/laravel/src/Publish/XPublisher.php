<?php

declare(strict_types=1);

namespace SocialPilot\Publish;

use SocialPilot\Http\HttpClient;

/** Posts a tweet with the official X API v2 (POST /2/tweets). Posting needs an API plan that allows writes. */
final class XPublisher implements Publisher
{
    private const URL = 'https://api.x.com/2/tweets';

    public function __construct(private HttpClient $http, private OAuth1Signer $signer, private array $secrets = [])
    {
    }

    public function platform(): string
    {
        return 'x';
    }

    public function publish(array $post): PublishResult
    {
        // X counts any link as 23 characters, whatever its real length.
        $text = trim($post['text'] . ($post['link'] ? "\n" . $post['link'] : ''));
        try {
            $res = $this->http->request('POST', self::URL, [
                'Authorization' => $this->signer->header('POST', self::URL),
                'Content-Type' => 'application/json',
            ], json_encode(['text' => $text], JSON_UNESCAPED_UNICODE));
        } catch (\Throwable $e) {
            return PublishResult::failure(Redact::clean($e->getMessage(), $this->secrets));
        }
        $data = $res->json() ?? [];
        $id = $data['data']['id'] ?? null;
        if ($res->ok() && is_string($id)) {
            return PublishResult::success($id);
        }
        $msg = (string) ($data['detail'] ?? $data['title'] ?? $data['error'] ?? 'unknown error');
        return PublishResult::failure('X HTTP ' . $res->status . ': ' . Redact::clean($msg, $this->secrets));
    }
}
