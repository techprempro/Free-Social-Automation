<?php

declare(strict_types=1);

namespace SocialPilot\Publish;

interface Publisher
{
    /** 'facebook' | 'x' | 'instagram' | 'telegram' | 'linkedin' */
    public function platform(): string;

    /**
     * @param array{text:string,link:?string,image_url:?string} $post
     */
    public function publish(array $post): PublishResult;
}
