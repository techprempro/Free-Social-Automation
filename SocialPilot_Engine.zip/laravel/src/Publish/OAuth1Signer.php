<?php

declare(strict_types=1);

namespace SocialPilot\Publish;

/** OAuth 1.0a (HMAC-SHA1) request signing, as required by X's user-context API with app keys + access tokens. */
final class OAuth1Signer
{
    /** @var callable():string */
    private $nonce;
    /** @var callable():int */
    private $time;

    public function __construct(
        private string $consumerKey,
        private string $consumerSecret,
        private string $token,
        private string $tokenSecret,
        ?callable $nonce = null,
        ?callable $time = null,
    ) {
        $this->nonce = $nonce ?? static fn (): string => bin2hex(random_bytes(16));
        $this->time = $time ?? static fn (): int => time();
    }

    private static function enc(string $s): string
    {
        return rawurlencode($s); // RFC 3986: only A-Z a-z 0-9 - . _ ~ stay unescaped
    }

    /**
     * @param array<string,string> $params query/form parameters that take part in the signature
     * (a JSON request body does NOT).
     */
    public function baseString(string $method, string $url, array $params): string
    {
        $pairs = [];
        foreach ($params as $k => $v) {
            $pairs[] = [self::enc((string) $k), self::enc((string) $v)];
        }
        usort($pairs, fn (array $a, array $b) => [$a[0], $a[1]] <=> [$b[0], $b[1]]);
        $paramString = implode('&', array_map(fn (array $p) => $p[0] . '=' . $p[1], $pairs));
        return strtoupper($method) . '&' . self::enc($url) . '&' . self::enc($paramString);
    }

    public function sign(string $baseString): string
    {
        $key = self::enc($this->consumerSecret) . '&' . self::enc($this->tokenSecret);
        return base64_encode(hash_hmac('sha1', $baseString, $key, true));
    }

    /** @param array<string,string> $params */
    public function header(string $method, string $url, array $params = []): string
    {
        $oauth = [
            'oauth_consumer_key' => $this->consumerKey,
            'oauth_nonce' => ($this->nonce)(),
            'oauth_signature_method' => 'HMAC-SHA1',
            'oauth_timestamp' => (string) ($this->time)(),
            'oauth_token' => $this->token,
            'oauth_version' => '1.0',
        ];
        $oauth['oauth_signature'] = $this->sign($this->baseString($method, $url, $params + $oauth));
        ksort($oauth);
        $parts = [];
        foreach ($oauth as $k => $v) {
            $parts[] = self::enc($k) . '="' . self::enc($v) . '"';
        }
        return 'OAuth ' . implode(', ', $parts);
    }
}
