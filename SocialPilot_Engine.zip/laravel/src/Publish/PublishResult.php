<?php

declare(strict_types=1);

namespace SocialPilot\Publish;

final class PublishResult
{
    private function __construct(
        public readonly bool $ok,
        public readonly ?string $remoteId,
        public readonly ?string $error,
    ) {
    }

    public static function success(string $remoteId): self
    {
        return new self(true, $remoteId, null);
    }

    public static function failure(string $error): self
    {
        return new self(false, null, $error);
    }
}
