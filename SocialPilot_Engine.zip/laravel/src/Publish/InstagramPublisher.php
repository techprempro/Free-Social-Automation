<?php

declare(strict_types=1);

namespace SocialPilot\Publish;

use SocialPilot\Http\HttpClient;

/**
 * Instagram professional account via the Graph API: create a media container from a PUBLIC image URL,
 * wait until it is ready, then publish it. Instagram posts always need an image.
 */
final class InstagramPublisher implements Publisher
{
    /** @var callable(int):void */
    private $sleep;

    public function __construct(
        private HttpClient $http,
        private string $igUserId,
        private string $token,
        private string $graphVersion = 'v26.0',
        ?callable $sleep = null,
        private int $maxStatusChecks = 6,
    ) {
        $this->sleep = $sleep ?? static function (int $s): void {
            sleep($s);
        };
    }

    public function platform(): string
    {
        return 'instagram';
    }

    public function publish(array $post): PublishResult
    {
        if (empty($post['image_url']) || !str_starts_with((string) $post['image_url'], 'https://')) {
            return PublishResult::failure('Instagram needs a public https image URL');
        }
        $base = 'https://graph.facebook.com/' . $this->graphVersion . '/';
        try {
            $create = $this->call($base . rawurlencode($this->igUserId) . '/media', [
                'image_url' => $post['image_url'],
                'caption' => $post['text'],
            ]);
            $container = $create['id'] ?? null;
            if (!is_string($container)) {
                return PublishResult::failure('Instagram container: ' . $this->errorText($create));
            }
            for ($i = 0; $i < $this->maxStatusChecks; $i++) {
                $status = $this->call($base . rawurlencode($container) . '?fields=status_code&access_token=' . rawurlencode($this->token), null);
                $code = $status['status_code'] ?? 'FINISHED';
                if ($code === 'FINISHED') {
                    break;
                }
                if ($code === 'ERROR' || $code === 'EXPIRED') {
                    return PublishResult::failure('Instagram could not process the image (' . $code . ')');
                }
                ($this->sleep)(5);
            }
            $publish = $this->call($base . rawurlencode($this->igUserId) . '/media_publish', ['creation_id' => $container]);
            $id = $publish['id'] ?? null;
            return is_string($id) ? PublishResult::success($id) : PublishResult::failure('Instagram publish: ' . $this->errorText($publish));
        } catch (\Throwable $e) {
            return PublishResult::failure(Redact::clean($e->getMessage(), [$this->token]));
        }
    }

    /** @param array<string,string>|null $form null = GET @return array<string,mixed> */
    private function call(string $url, ?array $form): array
    {
        if ($form === null) {
            $res = $this->http->request('GET', $url);
        } else {
            $form['access_token'] = $this->token;
            $res = $this->http->request('POST', $url, ['Content-Type' => 'application/x-www-form-urlencoded'], http_build_query($form));
        }
        $data = $res->json() ?? [];
        if (!$res->ok() && !isset($data['error'])) {
            $data['error'] = ['message' => 'HTTP ' . $res->status];
        }
        return $data;
    }

    /** @param array<string,mixed> $data */
    private function errorText(array $data): string
    {
        return Redact::clean((string) ($data['error']['message'] ?? 'unknown error'), [$this->token]);
    }
}
