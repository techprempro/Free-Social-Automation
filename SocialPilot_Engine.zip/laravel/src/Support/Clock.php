<?php

declare(strict_types=1);

namespace SocialPilot\Support;

/** Injectable UTC clock so scheduling, limits and cooldowns are testable. */
final class Clock
{
    private ?\DateTimeImmutable $fixed;

    public function __construct(?\DateTimeImmutable $fixed = null)
    {
        $this->fixed = $fixed;
    }

    public function now(): \DateTimeImmutable
    {
        return $this->fixed ?? new \DateTimeImmutable('now', new \DateTimeZone('UTC'));
    }

    /** Tests only: moves a fixed clock forward. */
    public function advance(int $seconds): void
    {
        $this->fixed = $this->now()->modify(($seconds >= 0 ? '+' : '') . $seconds . ' seconds');
    }

    public function utc(\DateTimeImmutable $t): string
    {
        return $t->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d H:i:s');
    }

    public function nowUtc(): string
    {
        return $this->utc($this->now());
    }

    /** Start of the current local day (in $tz), as a UTC string. */
    public function startOfLocalDayUtc(string $tz): string
    {
        $local = $this->now()->setTimezone(new \DateTimeZone($tz))->setTime(0, 0, 0);
        return $this->utc($local);
    }
}
