<?php

declare(strict_types=1);

namespace SocialPilot\Support;

/** Read-only dotted-path config access over a plain array (Laravel's config('socialpilot') or a test array). */
final class Config
{
    /** @param array<string,mixed> $values */
    public function __construct(private array $values)
    {
    }

    public function get(string $path, mixed $default = null): mixed
    {
        $node = $this->values;
        foreach (explode('.', $path) as $key) {
            if (!is_array($node) || !array_key_exists($key, $node)) {
                return $default;
            }
            $node = $node[$key];
        }
        return $node ?? $default;
    }

    public function string(string $path): string
    {
        $v = $this->get($path, '');
        return is_string($v) ? trim($v) : '';
    }

    public function has(string $path): bool
    {
        return $this->string($path) !== '';
    }
}
