<?php

declare(strict_types=1);

namespace SocialPilot\Safety;

/**
 * Deterministic checks that run on EVERY post before publishing, whatever the AI said.
 * fail   -> the post is blocked (never published)
 * review -> the post needs a human tap in the panel even in full-auto mode
 */
final class ContentGuard
{
    private const MAX_LEN = ['facebook' => 1500, 'x' => 250, 'instagram' => 2000, 'telegram' => 3500, 'linkedin' => 2500];
    private const MAX_TAGS = ['facebook' => 5, 'x' => 3, 'instagram' => 15, 'telegram' => 5, 'linkedin' => 5];
    private const SPAM = '/click here|free money|giveaway|follow for follow|f4f|dm me|whatsapp me|guaranteed (?:profit|income|return)|100% (?:free|guaranteed)|you won|lottery/iu';

    /**
     * @param string[] $blockedTerms never allowed
     * @param string[] $reviewKeywords force human review when present
     */
    public function __construct(private array $blockedTerms = [], private array $reviewKeywords = [])
    {
    }

    /** @return array{ok:bool,review:bool,reasons:string[]} */
    public function check(string $platform, string $text): array
    {
        $reasons = [];
        $review = false;
        $text = trim($text);

        if ($text === '') {
            return ['ok' => false, 'review' => false, 'reasons' => ['empty']];
        }
        if (mb_strlen($text) > (self::MAX_LEN[$platform] ?? 1000)) {
            $reasons[] = 'too_long';
        }
        if (preg_match('~https?://|www\.|\b[a-z0-9-]+\.(?:com|net|org|io|bd|info|xyz|ly)\b~iu', $text)) {
            $reasons[] = 'contains_url';
        }
        if (preg_match('/(?<![\p{L}\p{N}_])@[\p{L}\p{N}_]{2,}/u', $text)) {
            $reasons[] = 'contains_mention';
        }
        if (preg_match_all('/#[\p{L}\p{N}_]+/u', $text) > (self::MAX_TAGS[$platform] ?? 5)) {
            $reasons[] = 'too_many_hashtags';
        }
        $letters = preg_match_all('/\p{L}/u', $text);
        if ($letters >= 20 && preg_match_all('/\p{Lu}/u', $text) / $letters > 0.6) {
            $reasons[] = 'shouting';
        }
        if (preg_match(self::SPAM, $text)) {
            $reasons[] = 'spam_phrase';
        }
        if (preg_match('/(.)\1{6,}/u', $text)) {
            $reasons[] = 'repetition';
        }
        if (preg_match_all('/[\x{1F300}-\x{1FAFF}\x{2600}-\x{27BF}]/u', $text) > 8) {
            $reasons[] = 'too_many_emoji';
        }
        $lower = mb_strtolower($text);
        foreach ($this->blockedTerms as $term) {
            if ($term !== '' && str_contains($lower, mb_strtolower($term))) {
                $reasons[] = 'blocked_term';
                break;
            }
        }
        foreach ($this->reviewKeywords as $kw) {
            if ($kw !== '' && str_contains($lower, mb_strtolower($kw))) {
                $review = true;
                break;
            }
        }
        return ['ok' => !$reasons, 'review' => $review, 'reasons' => $reasons];
    }
}
