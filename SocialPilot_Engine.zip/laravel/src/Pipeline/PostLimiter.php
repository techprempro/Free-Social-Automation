<?php

declare(strict_types=1);

namespace SocialPilot\Pipeline;

use SocialPilot\Storage\Store;
use SocialPilot\Support\Clock;
use SocialPilot\Support\Config;

/** Per-platform daily cap and minimum gap between posts, so automation can never flood a page. */
final class PostLimiter
{
    public function __construct(private Store $store, private Clock $clock, private Config $config)
    {
    }

    /** @return string|null reason when posting is NOT allowed now, null when allowed */
    public function blockReason(string $platform): ?string
    {
        $daily = (int) $this->config->get("limits.$platform.daily", 5);
        $gap = (int) $this->config->get("limits.$platform.gap_minutes", 60);
        $tz = (string) $this->config->get('timezone', 'Asia/Dhaka');

        $done = $this->store->countPublishedSince($platform, $this->clock->startOfLocalDayUtc($tz));
        if ($done >= $daily) {
            return "daily_cap_reached ($done/$daily)";
        }
        $last = $this->store->lastPublishedAt($platform);
        if ($last !== null) {
            $elapsed = $this->clock->now()->getTimestamp() - (new \DateTimeImmutable($last, new \DateTimeZone('UTC')))->getTimestamp();
            if ($elapsed < $gap * 60) {
                return 'min_gap_not_reached (' . (int) ceil(($gap * 60 - $elapsed) / 60) . ' min left)';
            }
        }
        return null;
    }
}
