<?php

declare(strict_types=1);

namespace SocialPilot\Pipeline;

use SocialPilot\Ai\AiException;
use SocialPilot\Ai\Editor;
use SocialPilot\Publish\Publisher;
use SocialPilot\Safety\ContentGuard;
use SocialPilot\Storage\Store;
use SocialPilot\Support\Clock;
use SocialPilot\Support\Config;
use SocialPilot\Trends\TrendCollector;

/**
 * One run for one topic: collect stories -> AI picks the best and writes the posts -> safety checks ->
 * publish (or save as draft when review is needed). At most ONE story per run; the scheduler decides how often it runs.
 */
final class Runner
{
    /** @param array<string,Publisher> $publishers keyed by platform; only configured platforms are present */
    public function __construct(
        private Store $store,
        private Clock $clock,
        private Config $config,
        private TrendCollector $collector,
        private ?Editor $editor,
        private ContentGuard $guard,
        private PostLimiter $limiter,
        private array $publishers,
    ) {
    }

    public function isPaused(): bool
    {
        return $this->store->getSetting('paused') === '1';
    }

    /** @return array<int,array<string,mixed>> */
    public function runAll(bool $dryRun = false): array
    {
        $out = [];
        foreach ($this->store->listTopics(true) as $topic) {
            $out[] = $this->runTopic($topic, $dryRun);
        }
        return $out;
    }

    /**
     * @param array<string,mixed> $topic
     * @return array<string,mixed>
     */
    public function runTopic(array $topic, bool $dryRun = false): array
    {
        $id = (int) $topic['id'];
        $report = ['topic' => $topic['name'], 'topic_id' => $id, 'status' => '', 'posts' => []];

        if ($this->isPaused()) {
            return ['status' => 'paused', 'message' => 'Automation is paused'] + $report;
        }
        if (!$topic['active']) {
            return ['status' => 'disabled'] + $report;
        }
        if ($this->editor === null) {
            return ['status' => 'ai_not_configured'] + $report;
        }
        $cool = (int) $this->store->getSetting("cooldown:$id", '0');
        if ($cool > $this->clock->now()->getTimestamp() && !$dryRun) {
            return ['status' => 'cooldown'] + $report;
        }
        $tz = (string) $this->config->get('timezone', 'Asia/Dhaka');
        if ($this->store->countPickedSince($id, $this->clock->startOfLocalDayUtc($tz)) >= $topic['posts_per_day'] && !$dryRun) {
            return ['status' => 'quota_reached'] + $report;
        }

        // Auto mode needs at least one platform that is configured AND currently allowed by the limits.
        $usable = [];
        foreach ($topic['platforms'] as $p) {
            if (!isset($this->publishers[$p])) {
                $report['posts'][] = ['platform' => $p, 'status' => 'skipped', 'reason' => 'platform_not_configured'];
                continue;
            }
            if ($topic['auto_publish'] && ($why = $this->limiter->blockReason($p)) !== null) {
                $report['posts'][] = ['platform' => $p, 'status' => 'skipped', 'reason' => $why];
                continue;
            }
            $usable[] = $p;
        }
        if (!$usable) {
            return ['status' => 'limit'] + $report;
        }
        $aiTopic = $topic;
        $aiTopic['platforms'] = $usable;

        $seen = $this->store->recentFingerprints($id);
        $forAi = max(1, (int) $this->config->get('candidates_for_ai', 12));
        // collect extra so that already-used stories can be dropped and the AI still gets $forAi fresh ones
        $candidates = array_values(array_filter(
            $this->collector->collect($topic, $forAi * 3),
            fn ($c) => !isset($seen[$c->fingerprint])
        ));
        $candidates = array_slice($candidates, 0, $forAi);
        if (!$candidates) {
            $this->cooldown($id, (int) $this->config->get('cooldown_minutes', 60));
            $this->store->addEvent('no_candidates', $id);
            return ['status' => 'no_candidates'] + $report;
        }

        try {
            $edit = $this->editor->compose($aiTopic, $candidates);
        } catch (AiException $e) {
            $this->cooldown($id, 10);
            $this->store->addEvent('ai_error', $id, null, ['message' => mb_substr($e->getMessage(), 0, 200)]);
            return ['status' => 'ai_error', 'message' => mb_substr($e->getMessage(), 0, 200)] + $report;
        }
        if ($edit === null) {
            $this->cooldown($id, (int) $this->config->get('cooldown_minutes', 60));
            $this->store->addEvent('nothing_suitable', $id);
            return ['status' => 'nothing_suitable'] + $report;
        }

        $chosen = $candidates[$edit['pick']];
        $report['pick'] = ['title' => $chosen->title, 'score' => $edit['score'], 'reason' => $edit['reason'], 'sensitivity' => $edit['sensitivity'], 'signal' => $chosen->signal];

        // 1) decide what happens to each platform's text
        $plan = [];
        foreach ($usable as $p) {
            $text = $edit['posts'][$p] ?? null;
            if ($text === null) {
                $report['posts'][] = ['platform' => $p, 'status' => 'skipped', 'reason' => 'ai_gave_no_text'];
                continue;
            }
            $check = $this->guard->check($p, $text);
            $image = null;
            $reasons = $check['reasons'];
            if ($check['ok'] && $p === 'instagram') {
                $image = $dryRun ? 'dry-run' : $this->store->nextImage($id);
                if ($image === null) {
                    $reasons[] = 'no_image_configured';
                }
            }
            if ($reasons) {
                $plan[$p] = ['action' => 'blocked', 'text' => $text, 'reason' => implode(',', $reasons), 'image' => null];
                continue;
            }
            $review = [];
            if (!$topic['auto_publish']) {
                $review[] = 'topic_requires_approval';
            }
            if (!$edit['safe']) {
                $review[] = 'ai_flagged_unsafe';
            }
            if ($edit['sensitivity'] !== 'none') {
                $review[] = 'sensitive:' . $edit['sensitivity'];
            }
            if ($check['review']) {
                $review[] = 'review_keyword';
            }
            $plan[$p] = ['action' => $review ? 'draft' : 'publish', 'text' => $text, 'reason' => implode(',', $review), 'image' => $image];
        }

        if ($dryRun) {
            foreach ($plan as $p => $x) {
                $report['posts'][] = ['platform' => $p, 'status' => 'dry_run:' . $x['action'], 'reason' => $x['reason'], 'text' => $x['text']];
            }
            return ['status' => 'dry_run'] + $report;
        }

        // 2) remember the story so it is never posted twice, then execute the plan
        $kept = array_filter($plan, fn ($x) => $x['action'] !== 'blocked');
        try {
            $candidateId = $this->store->addCandidate($id, $chosen->fingerprint, $chosen->title, $chosen->url, $chosen->source, $chosen->signal, $kept ? 'picked' : 'skipped');
        } catch (\PDOException) {
            return ['status' => 'duplicate_story'] + $report; // another run just took it
        }
        $this->store->addEvent('topic_selected', $id, null, ['score' => $edit['score'], 'signal' => $chosen->signal, 'sensitivity' => $edit['sensitivity']]);

        $attempted = 0;
        $failed = 0;
        foreach ($plan as $p => $x) {
            $base = [
                'topic_id' => $id, 'candidate_id' => $candidateId, 'platform' => $p, 'text' => $x['text'],
                'link' => $chosen->url, 'image_url' => $x['image'], 'sensitivity' => $edit['sensitivity'], 'virality_score' => $edit['score'],
            ];
            if ($x['action'] === 'blocked') {
                $postId = $this->store->addPost($base + ['status' => 'blocked', 'review_reason' => $x['reason']]);
                $this->store->addEvent('post_blocked', $id, $p, ['reason' => $x['reason']]);
                $report['posts'][] = ['id' => $postId, 'platform' => $p, 'status' => 'blocked', 'reason' => $x['reason']];
                continue;
            }
            if ($x['action'] === 'draft') {
                $postId = $this->store->addPost($base + ['status' => 'draft', 'review_reason' => $x['reason']]);
                $this->store->addEvent('post_drafted', $id, $p, ['reason' => $x['reason']]);
                $report['posts'][] = ['id' => $postId, 'platform' => $p, 'status' => 'draft', 'reason' => $x['reason']];
                continue;
            }
            $attempted++;
            $result = $this->send($p, $x['text'], $chosen->url, $x['image']);
            if ($result->ok) {
                $postId = $this->store->addPost($base + ['status' => 'published', 'remote_id' => $result->remoteId, 'published_at' => $this->clock->nowUtc()]);
                $this->store->addEvent('post_published', $id, $p);
                $report['posts'][] = ['id' => $postId, 'platform' => $p, 'status' => 'published', 'remote_id' => $result->remoteId];
            } else {
                $failed++;
                $postId = $this->store->addPost($base + ['status' => 'failed', 'error' => $result->error]);
                $this->store->addEvent('post_failed', $id, $p, ['error' => mb_substr((string) $result->error, 0, 200)]);
                $report['posts'][] = ['id' => $postId, 'platform' => $p, 'status' => 'failed', 'error' => $result->error];
            }
        }
        if ($attempted > 0 && $failed === $attempted) {
            $this->cooldown($id, (int) $this->config->get('cooldown_minutes', 60)); // e.g. expired token: don't burn AI quota
        }
        $statuses = array_column($report['posts'], 'status');
        $report['status'] = in_array('published', $statuses, true) ? 'published'
            : (in_array('draft', $statuses, true) ? 'drafted' : ($failed > 0 ? 'failed' : 'blocked'));
        return $report;
    }

    /**
     * Publishes a saved draft (or retries a failed post) after the owner approved it.
     * @return array{ok:bool,message:string}
     */
    public function publishSaved(int $postId): array
    {
        $post = $this->store->getPost($postId);
        if (!$post) {
            return ['ok' => false, 'message' => 'Post not found'];
        }
        if (!in_array($post['status'], ['draft', 'failed'], true)) {
            return ['ok' => false, 'message' => 'Only drafts and failed posts can be published'];
        }
        $platform = (string) $post['platform'];
        if (!isset($this->publishers[$platform])) {
            return ['ok' => false, 'message' => "$platform is not configured"];
        }
        $check = $this->guard->check($platform, (string) $post['text']);
        if (!$check['ok']) {
            return ['ok' => false, 'message' => 'Blocked by safety checks: ' . implode(',', $check['reasons'])];
        }
        if (($why = $this->limiter->blockReason($platform)) !== null) {
            return ['ok' => false, 'message' => "Not now: $why"];
        }
        $result = $this->send($platform, (string) $post['text'], $post['link'] !== null ? (string) $post['link'] : null, $post['image_url'] !== null ? (string) $post['image_url'] : null);
        if ($result->ok) {
            $this->store->updatePost($postId, ['status' => 'published', 'remote_id' => $result->remoteId, 'published_at' => $this->clock->nowUtc(), 'error' => null]);
            $this->store->addEvent('post_published', (int) $post['topic_id'], $platform, ['approved' => true]);
            return ['ok' => true, 'message' => 'Published'];
        }
        $this->store->updatePost($postId, ['status' => 'failed', 'error' => $result->error]);
        $this->store->addEvent('post_failed', (int) $post['topic_id'], $platform, ['error' => mb_substr((string) $result->error, 0, 200)]);
        return ['ok' => false, 'message' => (string) $result->error];
    }

    private function send(string $platform, string $text, ?string $link, ?string $image): \SocialPilot\Publish\PublishResult
    {
        // Instagram links are not clickable, so name the source instead of pasting a URL.
        if ($platform === 'instagram') {
            $link = null;
        }
        try {
            return $this->publishers[$platform]->publish(['text' => $text, 'link' => $link, 'image_url' => $image]);
        } catch (\Throwable $e) {
            return \SocialPilot\Publish\PublishResult::failure('Unexpected error: ' . mb_substr($e->getMessage(), 0, 200));
        }
    }

    private function cooldown(int $topicId, int $minutes): void
    {
        $this->store->setSetting("cooldown:$topicId", (string) ($this->clock->now()->getTimestamp() + $minutes * 60));
    }
}
