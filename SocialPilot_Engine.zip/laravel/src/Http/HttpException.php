<?php

declare(strict_types=1);

namespace SocialPilot\Http;

final class HttpException extends \RuntimeException
{
}
