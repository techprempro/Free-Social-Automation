<?php

declare(strict_types=1);

namespace SocialPilot\Http;

interface HttpClient
{
    /**
     * @param array<string,string> $headers
     * @throws HttpException on network failure (never includes request bodies or secrets)
     */
    public function request(string $method, string $url, array $headers = [], ?string $body = null, int $timeout = 20): HttpResponse;
}
