<?php

declare(strict_types=1);

namespace SocialPilot\Laravel;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use SocialPilot\App;

final class ApiController
{
    /** Owner API: everything under /api/socialpilot/admin/*. Authorization happens inside AdminApi (Bearer token). */
    public function admin(Request $request, App $app, string $path = ''): JsonResponse
    {
        $body = $request->isJson() ? $request->json()->all() : null;
        [$status, $data] = $app->admin->handle(
            $request->method(),
            '/' . $path,
            $request->query(),
            is_array($body) ? $body : null,
            $request->header('Authorization'),
        );
        return response()->json($data, $status, ['Cache-Control' => 'no-store']);
    }

    /** Public app endpoint (same idea as /api/app/active-user): the Android app reports that it was opened. */
    public function activeUser(Request $request, App $app): JsonResponse
    {
        [$status, $data] = $app->tracker->record($request->json()->all());
        return response()->json($data, $status);
    }

    /** The owner panel page. It contains no data: every number is fetched from the protected API. */
    public function panel(): Response
    {
        $nonce = base64_encode(random_bytes(16)); // per-request nonce: only this page's own script/style may run
        $html = str_replace('{{NONCE}}', $nonce, (string) file_get_contents(__DIR__ . '/../../resources/panel.html'));
        return response($html, 200, [
            'Content-Type' => 'text/html; charset=utf-8',
            'Cache-Control' => 'no-store',
            'X-Frame-Options' => 'DENY',
            'X-Robots-Tag' => 'noindex, nofollow',
            'Referrer-Policy' => 'no-referrer',
            'Content-Security-Policy' => "default-src 'none'; script-src 'nonce-$nonce'; style-src 'nonce-$nonce'; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",
        ]);
    }
}
