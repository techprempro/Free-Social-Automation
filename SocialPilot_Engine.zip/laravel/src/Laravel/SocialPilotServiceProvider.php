<?php

declare(strict_types=1);

namespace SocialPilot\Laravel;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\ServiceProvider;
use SocialPilot\App;

/**
 * Laravel glue: config, migration, routes, artisan command and the 15-minute scheduler entry.
 * Auto-discovered through composer.json "extra.laravel.providers".
 */
final class SocialPilotServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__ . '/../../config/socialpilot.php', 'socialpilot');
        $this->app->singleton(App::class, fn ($app) => App::build((array) $app['config']->get('socialpilot', []), DB::connection()->getPdo()));
    }

    public function boot(): void
    {
        $this->loadMigrationsFrom(__DIR__ . '/../../database/migrations');
        $this->loadRoutesFrom(__DIR__ . '/../../routes/socialpilot.php');
        $this->publishes([__DIR__ . '/../../config/socialpilot.php' => config_path('socialpilot.php')], 'socialpilot-config');

        if ($this->app->runningInConsole()) {
            $this->commands([RunCommand::class]);
        }
        $this->callAfterResolving(Schedule::class, function (Schedule $schedule): void {
            // Every 15 minutes; per-platform gaps, daily caps and per-topic quotas decide whether anything is actually posted.
            $schedule->command('socialpilot:run')->everyFifteenMinutes()->withoutOverlapping(14)->runInBackground();
        });
    }
}
