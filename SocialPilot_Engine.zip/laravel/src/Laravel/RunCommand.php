<?php

declare(strict_types=1);

namespace SocialPilot\Laravel;

use Illuminate\Console\Command;
use SocialPilot\App;

final class RunCommand extends Command
{
    protected $signature = 'socialpilot:run {--topic= : Only this topic id} {--dry-run : Show what would be posted, publish nothing}';
    protected $description = 'Collect trending stories, let the AI write posts and publish them to the configured platforms';

    public function handle(App $app): int
    {
        $dry = (bool) $this->option('dry-run');
        $topicId = $this->option('topic');
        if ($topicId !== null) {
            $topic = $app->store->getTopic((int) $topicId);
            if (!$topic) {
                $this->error('Topic not found');
                return self::FAILURE;
            }
            $results = [$app->runner->runTopic($topic, $dry)];
        } else {
            $results = $app->runner->runAll($dry);
        }
        foreach ($results as $r) {
            $this->line(sprintf('[%s] %s%s', $r['topic'] ?? '?', $r['status'], isset($r['pick']['title']) ? ' - ' . $r['pick']['title'] : ''));
            foreach ($r['posts'] ?? [] as $p) {
                $this->line(sprintf('    %s: %s %s', $p['platform'], $p['status'], $p['reason'] ?? $p['error'] ?? ''));
            }
        }
        return self::SUCCESS;
    }
}
