<?php

declare(strict_types=1);

namespace SocialPilot\Storage;

/**
 * One schema definition for MySQL (production) and SQLite (tests). Run through PDO,
 * so the Laravel migration and the test-suite create exactly the same tables.
 * MySQL tables are utf8mb4 so Bangla text and emoji are stored correctly.
 */
final class SchemaInstaller
{
    /** @return string[] */
    public static function statements(string $driver): array
    {
        $mysql = $driver === 'mysql';
        $pk = $mysql ? 'BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY' : 'INTEGER PRIMARY KEY AUTOINCREMENT';
        $tail = $mysql ? ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci' : '';
        $bigint = $mysql ? 'BIGINT UNSIGNED' : 'INTEGER';

        return [
            "CREATE TABLE IF NOT EXISTS sp_topics (
                id $pk,
                name VARCHAR(80) NOT NULL,
                keywords TEXT NOT NULL,
                language VARCHAR(8) NOT NULL DEFAULT 'bn',
                region VARCHAR(8) NOT NULL DEFAULT 'BD',
                platforms TEXT NOT NULL,
                tone VARCHAR(120) NOT NULL DEFAULT '',
                hashtags TEXT NOT NULL,
                posts_per_day INTEGER NOT NULL DEFAULT 3,
                auto_publish TINYINT NOT NULL DEFAULT 1,
                active TINYINT NOT NULL DEFAULT 1,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL
            )$tail",
            "CREATE TABLE IF NOT EXISTS sp_candidates (
                id $pk,
                topic_id $bigint NOT NULL,
                fingerprint VARCHAR(64) NOT NULL,
                title VARCHAR(500) NOT NULL,
                url VARCHAR(1000) NOT NULL,
                source VARCHAR(160) NOT NULL DEFAULT '',
                signal_score DECIMAL(6,1) NOT NULL DEFAULT 0,
                status VARCHAR(16) NOT NULL DEFAULT 'picked',
                created_at DATETIME NOT NULL
            )$tail",
            'CREATE UNIQUE INDEX sp_candidates_topic_fp ON sp_candidates (topic_id, fingerprint)',
            'CREATE INDEX sp_candidates_created ON sp_candidates (topic_id, created_at)',
            "CREATE TABLE IF NOT EXISTS sp_posts (
                id $pk,
                topic_id $bigint NOT NULL,
                candidate_id $bigint NULL,
                platform VARCHAR(16) NOT NULL,
                text TEXT NOT NULL,
                link VARCHAR(1000) NULL,
                image_url VARCHAR(1000) NULL,
                status VARCHAR(16) NOT NULL,
                review_reason VARCHAR(255) NULL,
                remote_id VARCHAR(190) NULL,
                error TEXT NULL,
                sensitivity VARCHAR(16) NOT NULL DEFAULT 'none',
                virality_score INTEGER NOT NULL DEFAULT 0,
                created_at DATETIME NOT NULL,
                published_at DATETIME NULL
            )$tail",
            'CREATE INDEX sp_posts_status ON sp_posts (status, created_at)',
            'CREATE INDEX sp_posts_platform_pub ON sp_posts (platform, status, published_at)',
            "CREATE TABLE IF NOT EXISTS sp_events (
                id $pk,
                event VARCHAR(40) NOT NULL,
                topic_id $bigint NULL,
                platform VARCHAR(16) NULL,
                meta TEXT NULL,
                created_at DATETIME NOT NULL
            )$tail",
            'CREATE INDEX sp_events_created ON sp_events (created_at)',
            "CREATE TABLE IF NOT EXISTS sp_images (
                id $pk,
                topic_id $bigint NULL,
                url VARCHAR(1000) NOT NULL,
                last_used_at DATETIME NULL,
                created_at DATETIME NOT NULL
            )$tail",
            "CREATE TABLE IF NOT EXISTS sp_settings (
                skey VARCHAR(80) NOT NULL PRIMARY KEY,
                svalue VARCHAR(255) NOT NULL
            )$tail",
            "CREATE TABLE IF NOT EXISTS sp_installs (
                id $pk,
                installation_id VARCHAR(64) NOT NULL,
                platform VARCHAR(20) NOT NULL,
                device_name VARCHAR(150) NOT NULL DEFAULT '',
                app_version VARCHAR(20) NOT NULL DEFAULT '',
                opens INTEGER NOT NULL DEFAULT 1,
                first_seen_at DATETIME NOT NULL,
                last_seen_at DATETIME NOT NULL
            )$tail",
            'CREATE UNIQUE INDEX sp_installs_iid ON sp_installs (installation_id)',
            'CREATE INDEX sp_installs_last ON sp_installs (last_seen_at)',
        ];
    }

    public static function install(\PDO $pdo): void
    {
        $driver = (string) $pdo->getAttribute(\PDO::ATTR_DRIVER_NAME);
        foreach (self::statements($driver) as $sql) {
            // Re-running is safe: CREATE INDEX has no IF NOT EXISTS on MySQL, so ignore "already exists".
            try {
                $pdo->exec($sql);
            } catch (\PDOException $e) {
                $msg = strtolower($e->getMessage());
                if (!str_contains($msg, 'already exists') && !str_contains($msg, 'duplicate key name')) {
                    throw $e;
                }
            }
        }
    }
}
