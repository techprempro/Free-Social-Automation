<?php

declare(strict_types=1);

namespace SocialPilot\Storage;

use SocialPilot\Support\Clock;

/** All database access (PDO, works on MySQL and SQLite). Every query is a prepared statement. */
final class Store
{
    public function __construct(private \PDO $pdo, private Clock $clock)
    {
        $this->pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
    }

    /** @param array<int|string,mixed> $params */
    private function q(string $sql, array $params = []): \PDOStatement
    {
        $st = $this->pdo->prepare($sql);
        $st->execute($params);
        return $st;
    }

    /** @return array<string,mixed>|null */
    private function one(string $sql, array $params = []): ?array
    {
        $row = $this->q($sql, $params)->fetch(\PDO::FETCH_ASSOC);
        return $row === false ? null : $row;
    }

    /** @return array<int,array<string,mixed>> */
    private function all(string $sql, array $params = []): array
    {
        return $this->q($sql, $params)->fetchAll(\PDO::FETCH_ASSOC);
    }

    private function now(): string
    {
        return $this->clock->nowUtc();
    }

    // ---------------------------------------------------------------- topics

    /** @param array<string,mixed> $row @return array<string,mixed> */
    private function hydrateTopic(array $row): array
    {
        $row['id'] = (int) $row['id'];
        $row['keywords'] = json_decode((string) $row['keywords'], true) ?: [];
        $row['platforms'] = json_decode((string) $row['platforms'], true) ?: [];
        $row['hashtags'] = json_decode((string) $row['hashtags'], true) ?: [];
        $row['posts_per_day'] = (int) $row['posts_per_day'];
        $row['auto_publish'] = (bool) $row['auto_publish'];
        $row['active'] = (bool) $row['active'];
        return $row;
    }

    /** @return array<int,array<string,mixed>> */
    public function listTopics(bool $activeOnly = false): array
    {
        $rows = $this->all('SELECT * FROM sp_topics' . ($activeOnly ? ' WHERE active = 1' : '') . ' ORDER BY id');
        return array_map(fn (array $r) => $this->hydrateTopic($r), $rows);
    }

    /** @return array<string,mixed>|null */
    public function getTopic(int $id): ?array
    {
        $row = $this->one('SELECT * FROM sp_topics WHERE id = ?', [$id]);
        return $row ? $this->hydrateTopic($row) : null;
    }

    /** @param array<string,mixed> $t validated topic */
    public function saveTopic(array $t, ?int $id = null): int
    {
        $fields = [
            json_encode($t['keywords'], JSON_UNESCAPED_UNICODE),
            $t['language'], $t['region'],
            json_encode($t['platforms']), $t['tone'],
            json_encode($t['hashtags'], JSON_UNESCAPED_UNICODE),
            $t['posts_per_day'], $t['auto_publish'] ? 1 : 0, $t['active'] ? 1 : 0,
        ];
        if ($id === null) {
            $this->q('INSERT INTO sp_topics (name, keywords, language, region, platforms, tone, hashtags, posts_per_day, auto_publish, active, created_at, updated_at)
                      VALUES (?,?,?,?,?,?,?,?,?,?,?,?)', array_merge([$t['name']], $fields, [$this->now(), $this->now()]));
            return (int) $this->pdo->lastInsertId();
        }
        $this->q('UPDATE sp_topics SET name=?, keywords=?, language=?, region=?, platforms=?, tone=?, hashtags=?, posts_per_day=?, auto_publish=?, active=?, updated_at=? WHERE id=?',
            array_merge([$t['name']], $fields, [$this->now(), $id]));
        return $id;
    }

    public function deleteTopic(int $id): bool
    {
        return $this->q('DELETE FROM sp_topics WHERE id = ?', [$id])->rowCount() > 0;
    }

    // ------------------------------------------------------------ candidates

    public function hasFingerprint(int $topicId, string $fp): bool
    {
        return $this->one('SELECT 1 AS x FROM sp_candidates WHERE topic_id = ? AND fingerprint = ?', [$topicId, $fp]) !== null;
    }

    /** @return array<string,true> fingerprints already used for this topic in the last $days days */
    public function recentFingerprints(int $topicId, int $days = 30): array
    {
        $since = $this->clock->utc($this->clock->now()->modify("-$days days"));
        $rows = $this->all('SELECT fingerprint FROM sp_candidates WHERE topic_id = ? AND created_at >= ?', [$topicId, $since]);
        $out = [];
        foreach ($rows as $r) {
            $out[(string) $r['fingerprint']] = true;
        }
        return $out;
    }

    public function addCandidate(int $topicId, string $fp, string $title, string $url, string $source, float $signal, string $status): int
    {
        $this->q('INSERT INTO sp_candidates (topic_id, fingerprint, title, url, source, signal_score, status, created_at) VALUES (?,?,?,?,?,?,?,?)',
            [$topicId, $fp, mb_substr($title, 0, 500), mb_substr($url, 0, 1000), mb_substr($source, 0, 160), $signal, $status, $this->now()]);
        return (int) $this->pdo->lastInsertId();
    }

    public function countPickedSince(int $topicId, string $sinceUtc): int
    {
        $r = $this->one("SELECT COUNT(*) AS n FROM sp_candidates WHERE topic_id = ? AND status = 'picked' AND created_at >= ?", [$topicId, $sinceUtc]);
        return (int) ($r['n'] ?? 0);
    }

    // ----------------------------------------------------------------- posts

    /** @param array<string,mixed> $p */
    public function addPost(array $p): int
    {
        $this->q('INSERT INTO sp_posts (topic_id, candidate_id, platform, text, link, image_url, status, review_reason, remote_id, error, sensitivity, virality_score, created_at, published_at)
                  VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)', [
            $p['topic_id'], $p['candidate_id'] ?? null, $p['platform'], $p['text'], $p['link'] ?? null, $p['image_url'] ?? null,
            $p['status'], $p['review_reason'] ?? null, $p['remote_id'] ?? null, isset($p['error']) ? mb_substr((string) $p['error'], 0, 1000) : null,
            $p['sensitivity'] ?? 'none', (int) ($p['virality_score'] ?? 0), $this->now(), $p['published_at'] ?? null,
        ]);
        return (int) $this->pdo->lastInsertId();
    }

    /** @param array<string,mixed> $changes only whitelisted columns are applied */
    public function updatePost(int $id, array $changes): void
    {
        $allowed = ['status', 'remote_id', 'error', 'published_at', 'review_reason', 'text', 'image_url'];
        $sets = [];
        $vals = [];
        foreach ($changes as $k => $v) {
            if (in_array($k, $allowed, true)) {
                $sets[] = "$k = ?";
                $vals[] = $k === 'error' && $v !== null ? mb_substr((string) $v, 0, 1000) : $v;
            }
        }
        if ($sets) {
            $vals[] = $id;
            $this->q('UPDATE sp_posts SET ' . implode(', ', $sets) . ' WHERE id = ?', $vals);
        }
    }

    /** @return array<string,mixed>|null */
    public function getPost(int $id): ?array
    {
        return $this->one('SELECT * FROM sp_posts WHERE id = ?', [$id]);
    }

    /** @return array<int,array<string,mixed>> */
    public function listPosts(?string $status, int $limit, int $offset): array
    {
        $limit = max(1, min(100, $limit));
        $offset = max(0, $offset);
        if ($status !== null) {
            return $this->all("SELECT * FROM sp_posts WHERE status = ? ORDER BY id DESC LIMIT $limit OFFSET $offset", [$status]);
        }
        return $this->all("SELECT * FROM sp_posts ORDER BY id DESC LIMIT $limit OFFSET $offset");
    }

    public function countPublishedSince(string $platform, string $sinceUtc): int
    {
        $r = $this->one("SELECT COUNT(*) AS n FROM sp_posts WHERE platform = ? AND status = 'published' AND published_at >= ?", [$platform, $sinceUtc]);
        return (int) ($r['n'] ?? 0);
    }

    public function lastPublishedAt(string $platform): ?string
    {
        $r = $this->one("SELECT MAX(published_at) AS m FROM sp_posts WHERE platform = ? AND status = 'published'", [$platform]);
        return isset($r['m']) && $r['m'] !== null ? (string) $r['m'] : null;
    }

    /** @return array<string,int> */
    public function postStatusCounts(string $sinceUtc): array
    {
        $out = [];
        foreach ($this->all('SELECT status, COUNT(*) AS n FROM sp_posts WHERE created_at >= ? GROUP BY status', [$sinceUtc]) as $r) {
            $out[(string) $r['status']] = (int) $r['n'];
        }
        return $out;
    }

    /** @return array<int,array<string,mixed>> */
    public function publishedSince(string $sinceUtc): array
    {
        return $this->all("SELECT platform, topic_id, published_at FROM sp_posts WHERE status = 'published' AND published_at >= ?", [$sinceUtc]);
    }

    // ---------------------------------------------------------------- events

    /** @param array<string,mixed> $meta non-sensitive details only */
    public function addEvent(string $event, ?int $topicId = null, ?string $platform = null, array $meta = []): void
    {
        $this->q('INSERT INTO sp_events (event, topic_id, platform, meta, created_at) VALUES (?,?,?,?,?)',
            [$event, $topicId, $platform, $meta ? mb_substr((string) json_encode($meta, JSON_UNESCAPED_UNICODE), 0, 1000) : null, $this->now()]);
    }

    /** @return array<string,int> */
    public function eventCounts(string $sinceUtc): array
    {
        $out = [];
        foreach ($this->all('SELECT event, COUNT(*) AS n FROM sp_events WHERE created_at >= ? GROUP BY event', [$sinceUtc]) as $r) {
            $out[(string) $r['event']] = (int) $r['n'];
        }
        return $out;
    }

    // -------------------------------------------------------------- settings

    public function getSetting(string $key, ?string $default = null): ?string
    {
        $r = $this->one('SELECT svalue FROM sp_settings WHERE skey = ?', [$key]);
        return $r ? (string) $r['svalue'] : $default;
    }

    public function setSetting(string $key, string $value): void
    {
        $n = $this->q('UPDATE sp_settings SET svalue = ? WHERE skey = ?', [$value, $key])->rowCount();
        if ($n === 0 && $this->getSetting($key) === null) {
            $this->q('INSERT INTO sp_settings (skey, svalue) VALUES (?,?)', [$key, $value]);
        }
    }

    // ---------------------------------------------------------------- images

    public function addImage(string $url, ?int $topicId): int
    {
        $this->q('INSERT INTO sp_images (topic_id, url, created_at) VALUES (?,?,?)', [$topicId, $url, $this->now()]);
        return (int) $this->pdo->lastInsertId();
    }

    public function deleteImage(int $id): bool
    {
        return $this->q('DELETE FROM sp_images WHERE id = ?', [$id])->rowCount() > 0;
    }

    /** @return array<int,array<string,mixed>> */
    public function listImages(): array
    {
        return $this->all('SELECT id, topic_id, url, last_used_at FROM sp_images ORDER BY id DESC LIMIT 200');
    }

    /** Least-recently-used image for the topic (or a global one). */
    public function nextImage(int $topicId): ?string
    {
        $r = $this->one('SELECT id, url FROM sp_images WHERE topic_id = ? OR topic_id IS NULL ORDER BY (last_used_at IS NULL) DESC, last_used_at ASC, id ASC LIMIT 1', [$topicId]);
        if (!$r) {
            return null;
        }
        $this->q('UPDATE sp_images SET last_used_at = ? WHERE id = ?', [$this->now(), $r['id']]);
        return (string) $r['url'];
    }

    // --------------------------------------------------------------- installs

    public function recordInstall(string $iid, string $platform, string $device, string $version): void
    {
        $now = $this->now();
        $n = $this->q('UPDATE sp_installs SET opens = opens + 1, last_seen_at = ?, device_name = ?, app_version = ?, platform = ? WHERE installation_id = ?',
            [$now, $device, $version, $platform, $iid])->rowCount();
        if ($n > 0) {
            return;
        }
        try {
            $this->q('INSERT INTO sp_installs (installation_id, platform, device_name, app_version, opens, first_seen_at, last_seen_at) VALUES (?,?,?,?,1,?,?)',
                [$iid, $platform, $device, $version, $now, $now]);
        } catch (\PDOException $e) {
            // two first-opens raced: the row exists now, so just count this open
            $this->q('UPDATE sp_installs SET opens = opens + 1, last_seen_at = ? WHERE installation_id = ?', [$now, $iid]);
        }
    }

    /** @return array<string,int> */
    public function installStats(string $todayStartUtc, string $weekStartUtc, string $monthStartUtc): array
    {
        $r = $this->one('SELECT COUNT(*) AS total,
                SUM(CASE WHEN last_seen_at >= ? THEN 1 ELSE 0 END) AS today,
                SUM(CASE WHEN last_seen_at >= ? THEN 1 ELSE 0 END) AS week,
                SUM(CASE WHEN last_seen_at >= ? THEN 1 ELSE 0 END) AS month,
                SUM(CASE WHEN first_seen_at >= ? THEN 1 ELSE 0 END) AS new_today,
                COALESCE(SUM(opens), 0) AS opens
            FROM sp_installs', [$todayStartUtc, $weekStartUtc, $monthStartUtc, $todayStartUtc]) ?? [];
        return [
            'total_installs' => (int) ($r['total'] ?? 0),
            'active_today' => (int) ($r['today'] ?? 0),
            'active_7d' => (int) ($r['week'] ?? 0),
            'active_30d' => (int) ($r['month'] ?? 0),
            'new_today' => (int) ($r['new_today'] ?? 0),
            'total_opens' => (int) ($r['opens'] ?? 0),
        ];
    }

    /** @return array<int,array<string,mixed>> */
    public function installVersions(): array
    {
        return $this->all('SELECT app_version, COUNT(*) AS users FROM sp_installs GROUP BY app_version ORDER BY users DESC LIMIT 20');
    }
}
