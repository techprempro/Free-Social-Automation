<?php

declare(strict_types=1);

namespace SocialPilot\Api;

use SocialPilot\Support\ValidationException;

final class TopicValidator
{
    public const PLATFORMS = ['facebook', 'x', 'instagram', 'telegram', 'linkedin'];

    /**
     * @param array<string,mixed> $in raw JSON from the panel
     * @return array<string,mixed> clean topic ready for Store::saveTopic
     * @throws ValidationException
     */
    public static function clean(array $in): array
    {
        $errors = [];

        $name = is_string($in['name'] ?? null) ? trim($in['name']) : '';
        if ($name === '' || mb_strlen($name) > 80) {
            $errors['name'] = 'Name is required (max 80 characters)';
        }

        $keywords = [];
        foreach ((is_array($in['keywords'] ?? null) ? $in['keywords'] : []) as $k) {
            if (is_string($k) && mb_strlen(trim($k)) >= 2 && mb_strlen(trim($k)) <= 60) {
                $keywords[] = trim($k);
            }
        }
        $keywords = array_slice(array_values(array_unique($keywords)), 0, 10);
        if (!$keywords) {
            $errors['keywords'] = 'Add 1-10 keywords (2-60 characters each)';
        }

        $language = is_string($in['language'] ?? null) ? strtolower(trim($in['language'])) : 'bn';
        if (!preg_match('/^[a-z]{2}$/', $language)) {
            $errors['language'] = 'Use a 2-letter language code, e.g. bn or en';
        }
        $region = is_string($in['region'] ?? null) ? strtoupper(trim($in['region'])) : 'BD';
        if (!preg_match('/^[A-Z]{2}$/', $region)) {
            $errors['region'] = 'Use a 2-letter country code, e.g. BD';
        }

        $platforms = [];
        foreach ((is_array($in['platforms'] ?? null) ? $in['platforms'] : []) as $p) {
            if (is_string($p) && in_array($p, self::PLATFORMS, true)) {
                $platforms[$p] = $p;
            }
        }
        if (!$platforms) {
            $errors['platforms'] = 'Choose at least one of: ' . implode(', ', self::PLATFORMS);
        }

        $tone = is_string($in['tone'] ?? null) ? trim($in['tone']) : '';
        if (mb_strlen($tone) > 120) {
            $errors['tone'] = 'Tone is too long (max 120 characters)';
        }

        $hashtags = [];
        foreach ((is_array($in['hashtags'] ?? null) ? $in['hashtags'] : []) as $h) {
            if (is_string($h)) {
                $h = ltrim(trim($h), '#');
                if (preg_match('/^[\p{L}\p{N}_]{2,40}$/u', $h)) {
                    $hashtags[] = '#' . $h;
                }
            }
        }
        $hashtags = array_slice(array_values(array_unique($hashtags)), 0, 10);

        $perDay = $in['posts_per_day'] ?? 3;
        if (!is_int($perDay) && !(is_string($perDay) && ctype_digit($perDay))) {
            $errors['posts_per_day'] = 'Posts per day must be a whole number';
            $perDay = 3;
        }
        $perDay = (int) $perDay;
        if ($perDay < 1 || $perDay > 24) {
            $errors['posts_per_day'] = 'Posts per day must be between 1 and 24';
        }

        if ($errors) {
            throw new ValidationException($errors);
        }
        return [
            'name' => $name,
            'keywords' => $keywords,
            'language' => $language,
            'region' => $region,
            'platforms' => array_values($platforms),
            'tone' => $tone,
            'hashtags' => $hashtags,
            'posts_per_day' => $perDay,
            'auto_publish' => ($in['auto_publish'] ?? true) === true,
            'active' => ($in['active'] ?? true) === true,
        ];
    }
}
