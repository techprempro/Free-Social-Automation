<?php

declare(strict_types=1);

namespace SocialPilot\Api;

use SocialPilot\Storage\Store;
use SocialPilot\Support\Clock;
use SocialPilot\Support\Config;

/** Numbers for the panel: posting activity per platform/day and app usage (installs, active devices). */
final class Report
{
    public function __construct(private Store $store, private Clock $clock, private Config $config)
    {
    }

    /** @return array<string,mixed> */
    public function summary(int $days): array
    {
        $days = max(1, min(90, $days));
        $tz = new \DateTimeZone((string) $this->config->get('timezone', 'Asia/Dhaka'));
        $today = $this->clock->now()->setTimezone($tz)->setTime(0, 0, 0);
        $first = $today->modify('-' . ($days - 1) . ' days');
        $sinceUtc = $this->clock->utc($first);

        $labels = [];
        for ($i = 0; $i < $days; $i++) {
            $labels[] = $first->modify("+$i days")->format('Y-m-d');
        }
        $series = [];
        foreach (TopicValidator::PLATFORMS as $p) {
            $series[$p] = array_fill_keys($labels, 0);
        }
        foreach ($this->store->publishedSince($sinceUtc) as $row) {
            $day = (new \DateTimeImmutable((string) $row['published_at'], new \DateTimeZone('UTC')))->setTimezone($tz)->format('Y-m-d');
            if (isset($series[$row['platform']][$day])) {
                $series[$row['platform']][$day]++;
            }
        }
        $perDay = [];
        foreach ($series as $p => $byDay) {
            $perDay[$p] = array_values($byDay);
        }

        $installs = $this->store->installStats(
            $this->clock->utc($today),
            $this->clock->utc($today->modify('-6 days')),
            $this->clock->utc($today->modify('-29 days')),
        );

        return [
            'as_of' => $this->clock->nowUtc(),
            'timezone' => $tz->getName(),
            'days' => $labels,
            'published_per_day' => $perDay,
            'post_status' => $this->store->postStatusCounts($sinceUtc),
            'events' => $this->store->eventCounts($sinceUtc),
            'installs' => $installs,
            'app_versions' => $this->store->installVersions(),
        ];
    }
}
