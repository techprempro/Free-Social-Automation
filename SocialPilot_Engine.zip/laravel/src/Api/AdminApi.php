<?php

declare(strict_types=1);

namespace SocialPilot\Api;

use SocialPilot\Pipeline\Runner;
use SocialPilot\Storage\Store;
use SocialPilot\Support\Config;
use SocialPilot\Support\ValidationException;

/**
 * Owner-only JSON API for the panel/app. Framework-agnostic: the Laravel controller just forwards the request.
 * Every route requires `Authorization: Bearer <SOCIALPILOT_ADMIN_TOKEN>` (checked in constant time).
 * Secrets (API keys, tokens) are never returned, only "configured: true/false".
 */
final class AdminApi
{
    /** @param string[] $configuredPlatforms */
    public function __construct(
        private Store $store,
        private Runner $runner,
        private Report $report,
        private Config $config,
        private array $configuredPlatforms,
        private bool $aiConfigured,
    ) {
    }

    /**
     * @param array<string,mixed> $query
     * @param array<string,mixed>|null $body
     * @return array{0:int,1:array<string,mixed>}
     */
    public function handle(string $method, string $path, array $query, ?array $body, ?string $authorization): array
    {
        $token = $this->config->string('admin_token');
        if (strlen($token) < 32) {
            return [503, ['error' => 'admin_disabled', 'message' => 'Set SOCIALPILOT_ADMIN_TOKEN (at least 32 characters) to enable the panel']];
        }
        if (!preg_match('/^Bearer (\S+)$/', (string) $authorization, $m) || !hash_equals($token, $m[1])) {
            return [401, ['error' => 'unauthorized']];
        }

        $method = strtoupper($method);
        $path = '/' . trim($path, '/');
        $body ??= [];

        try {
            if ($method === 'GET' && $path === '/status') {
                return [200, $this->status()];
            }
            if ($method === 'GET' && $path === '/summary') {
                return [200, $this->report->summary((int) ($query['days'] ?? 7))];
            }
            if ($method === 'POST' && $path === '/pause') {
                $this->store->setSetting('paused', '1');
                return [200, ['paused' => true]];
            }
            if ($method === 'POST' && $path === '/resume') {
                $this->store->setSetting('paused', '0');
                return [200, ['paused' => false]];
            }

            if ($path === '/topics') {
                if ($method === 'GET') {
                    return [200, ['topics' => $this->store->listTopics()]];
                }
                if ($method === 'POST') {
                    $id = $this->store->saveTopic(TopicValidator::clean($body));
                    return [201, ['topic' => $this->store->getTopic($id)]];
                }
            }
            if (preg_match('~^/topics/(\d{1,12})$~', $path, $m)) {
                $id = (int) $m[1];
                if (!$this->store->getTopic($id)) {
                    return [404, ['error' => 'not_found']];
                }
                if ($method === 'PUT') {
                    $this->store->saveTopic(TopicValidator::clean($body), $id);
                    return [200, ['topic' => $this->store->getTopic($id)]];
                }
                if ($method === 'DELETE') {
                    $this->store->deleteTopic($id);
                    return [200, ['deleted' => true]];
                }
            }
            if ($method === 'POST' && preg_match('~^/topics/(\d{1,12})/run$~', $path, $m)) {
                $topic = $this->store->getTopic((int) $m[1]);
                if (!$topic) {
                    return [404, ['error' => 'not_found']];
                }
                return [200, ['result' => $this->runner->runTopic($topic, ($body['dry_run'] ?? false) === true)]];
            }

            if ($method === 'GET' && $path === '/posts') {
                $status = isset($query['status']) && is_string($query['status']) ? $query['status'] : null;
                if ($status !== null && !in_array($status, ['draft', 'published', 'failed', 'blocked', 'rejected'], true)) {
                    return [422, ['error' => 'validation', 'errors' => ['status' => 'Unknown status']]];
                }
                return [200, ['posts' => $this->store->listPosts($status, (int) ($query['limit'] ?? 30), (int) ($query['offset'] ?? 0))]];
            }
            if ($method === 'POST' && preg_match('~^/posts/(\d{1,12})/publish$~', $path, $m)) {
                $r = $this->runner->publishSaved((int) $m[1]);
                return [$r['ok'] ? 200 : 409, $r];
            }
            if ($method === 'POST' && preg_match('~^/posts/(\d{1,12})/reject$~', $path, $m)) {
                $post = $this->store->getPost((int) $m[1]);
                if (!$post) {
                    return [404, ['error' => 'not_found']];
                }
                if ($post['status'] !== 'draft') {
                    return [409, ['ok' => false, 'message' => 'Only drafts can be rejected']];
                }
                $this->store->updatePost((int) $m[1], ['status' => 'rejected']);
                return [200, ['ok' => true]];
            }

            if ($path === '/images') {
                if ($method === 'GET') {
                    return [200, ['images' => $this->store->listImages()]];
                }
                if ($method === 'POST') {
                    $url = is_string($body['url'] ?? null) ? trim($body['url']) : '';
                    if (strlen($url) > 1000 || !str_starts_with($url, 'https://') || filter_var($url, FILTER_VALIDATE_URL) === false) {
                        throw new ValidationException(['url' => 'Use a public https:// image URL (max 1000 characters)']);
                    }
                    $topicId = $body['topic_id'] ?? null;
                    if ($topicId !== null && (!is_int($topicId) || !$this->store->getTopic($topicId))) {
                        throw new ValidationException(['topic_id' => 'Unknown topic']);
                    }
                    return [201, ['id' => $this->store->addImage($url, $topicId)]];
                }
            }
            if ($method === 'DELETE' && preg_match('~^/images/(\d{1,12})$~', $path, $m)) {
                return $this->store->deleteImage((int) $m[1]) ? [200, ['deleted' => true]] : [404, ['error' => 'not_found']];
            }
        } catch (ValidationException $e) {
            return [422, ['error' => 'validation', 'errors' => $e->errors]];
        } catch (\Throwable $e) {
            return [500, ['error' => 'server_error']]; // details stay in the server log, never in the response
        }

        return [404, ['error' => 'not_found']];
    }

    /** @return array<string,mixed> */
    private function status(): array
    {
        $platforms = [];
        foreach (TopicValidator::PLATFORMS as $p) {
            $platforms[$p] = in_array($p, $this->configuredPlatforms, true);
        }
        return [
            'paused' => $this->runner->isPaused(),
            'ai_configured' => $this->aiConfigured,
            'platforms_configured' => $platforms,
            'timezone' => (string) $this->config->get('timezone', 'Asia/Dhaka'),
            'limits' => $this->config->get('limits', []),
        ];
    }
}
