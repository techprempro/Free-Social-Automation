<?php

declare(strict_types=1);

namespace SocialPilot\Api;

use SocialPilot\Storage\Store;

/**
 * Public endpoint the Android app calls on every start (same idea as /api/app/active-user).
 * Receives ONLY: a random installation id, device name, platform and app version. Everything is validated
 * and cleaned; unknown fields are ignored, so nothing else can be stored.
 */
final class AppTracker
{
    private const PLATFORMS = ['android' => 'android', 'ios' => 'ios', 'web' => 'web'];

    public function __construct(private Store $store)
    {
    }

    /**
     * @param array<string,mixed> $payload
     * @return array{0:int,1:array<string,mixed>}
     */
    public function record(array $payload): array
    {
        $iid = $payload['installation_id'] ?? null;
        if (!is_string($iid) || !preg_match('/^[A-Za-z0-9_-]{16,64}$/', $iid)) {
            return [422, ['error' => 'invalid installation_id']];
        }
        $platform = self::PLATFORMS[strtolower((string) ($payload['platform'] ?? ''))] ?? null;
        if ($platform === null) {
            return [422, ['error' => 'invalid platform']];
        }
        $version = is_string($payload['app_version'] ?? null) ? $payload['app_version'] : '';
        if (!preg_match('/^[0-9A-Za-z._-]{1,20}$/', $version)) {
            return [422, ['error' => 'invalid app_version']];
        }
        $device = is_string($payload['device_name'] ?? null) ? $payload['device_name'] : '';
        $device = mb_substr(trim((string) preg_replace('/[^\p{L}\p{N} ._+-]/u', '', $device)), 0, 150);

        $this->store->recordInstall($iid, $platform, $device, $version);
        $this->store->addEvent('app_open', null, null, ['platform' => $platform, 'version' => $version]);
        return [200, ['ok' => true]];
    }
}
