<?php

declare(strict_types=1);

namespace SocialPilot\Ai;

use SocialPilot\Http\HttpClient;

/** Minimal Gemini (Google AI Studio) client. The API key goes in a header, never in the URL, so it cannot leak into logs. */
final class GeminiClient
{
    public function __construct(
        private HttpClient $http,
        private string $apiKey,
        private string $model = 'gemini-3.8-flash',
        private string $baseUrl = 'https://generativelanguage.googleapis.com/v1beta',
        /** @var string[] tried in order when the main model is busy (429/5xx) or unavailable (404) */
        private array $fallbackModels = [],
        private int $retriesPerModel = 1,
        /** @var (callable(int):void)|null pause between retries, in seconds (injectable for tests) */
        private $sleeper = null,
    ) {
    }

    /** Busy or temporarily broken: worth retrying / switching model. */
    private static function isTransient(int $status): bool
    {
        return $status === 429 || $status >= 500;
    }

    /**
     * Asks for a JSON object and returns it decoded.
     * @return array<string,mixed>
     * @throws AiException on API error, blocked prompt or unparseable output
     */
    public function generateJson(string $system, string $user, float $temperature = 0.7): array
    {
        $payload = [
            'systemInstruction' => ['parts' => [['text' => $system]]],
            'contents' => [['role' => 'user', 'parts' => [['text' => $user]]]],
            'generationConfig' => [
                'temperature' => $temperature,
                'responseMimeType' => 'application/json',
                'maxOutputTokens' => 2048,
            ],
        ];
        $models = array_values(array_unique(array_filter(array_merge([$this->model], $this->fallbackModels), fn ($m) => is_string($m) && preg_match('/^[A-Za-z0-9._-]{1,80}$/', $m) === 1)));
        $lastError = 'no model configured';
        $res = null;
        $data = null;
        foreach ($models as $model) {
            $url = rtrim($this->baseUrl, '/') . '/models/' . rawurlencode($model) . ':generateContent';
            for ($attempt = 0; $attempt <= $this->retriesPerModel; $attempt++) {
                if ($attempt > 0) {
                    $this->sleeper ? ($this->sleeper)(3 * $attempt) : sleep(3 * $attempt);
                }
                try {
                    $res = $this->http->request('POST', $url, [
                        'Content-Type' => 'application/json',
                        'x-goog-api-key' => $this->apiKey,
                    ], json_encode($payload, JSON_UNESCAPED_UNICODE), 60);
                } catch (\Throwable $e) {
                    $lastError = 'Gemini request failed: ' . $e->getMessage();
                    $res = null;
                    continue; // network hiccup: retry, then next model
                }
                $data = $res->json();
                if ($res->ok() && $data !== null) {
                    break 2;
                }
                $msg = is_array($data) ? (string) ($data['error']['message'] ?? 'unknown error') : 'bad response';
                $lastError = 'Gemini HTTP ' . $res->status . ' (' . $model . '): ' . str_replace($this->apiKey, '[REDACTED]', mb_substr($msg, 0, 200));
                if (!self::isTransient($res->status)) {
                    if ($res->status === 404) {
                        continue 2; // model name not available: try the next model
                    }
                    throw new AiException($lastError); // 400/401/403: switching model will not help
                }
            }
            $res = null;
        }
        if ($res === null || !$res->ok() || $data === null) {
            throw new AiException($lastError);
        }
        if (isset($data['promptFeedback']['blockReason'])) {
            throw new AiException('Gemini blocked the prompt: ' . (string) $data['promptFeedback']['blockReason']);
        }
        $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? null;
        if (!is_string($text) || trim($text) === '') {
            throw new AiException('Gemini returned no text');
        }
        $text = trim((string) preg_replace('/^```(?:json)?\s*|\s*```$/i', '', trim($text)));
        $decoded = json_decode($text, true);
        if (!is_array($decoded)) {
            throw new AiException('Gemini did not return valid JSON');
        }
        return $decoded;
    }
}
