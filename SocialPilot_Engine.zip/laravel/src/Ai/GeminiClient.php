<?php

declare(strict_types=1);

namespace SocialPilot\Ai;

use SocialPilot\Http\HttpClient;

/** Minimal Gemini (Google AI Studio) client. The API key goes in a header, never in the URL, so it cannot leak into logs. */
final class GeminiClient
{
    public function __construct(
        private HttpClient $http,
        private string $apiKey,
        private string $model = 'gemini-2.5-flash',
        private string $baseUrl = 'https://generativelanguage.googleapis.com/v1beta',
    ) {
    }

    /**
     * Asks for a JSON object and returns it decoded.
     * @return array<string,mixed>
     * @throws AiException on API error, blocked prompt or unparseable output
     */
    public function generateJson(string $system, string $user, float $temperature = 0.7): array
    {
        $payload = [
            'systemInstruction' => ['parts' => [['text' => $system]]],
            'contents' => [['role' => 'user', 'parts' => [['text' => $user]]]],
            'generationConfig' => [
                'temperature' => $temperature,
                'responseMimeType' => 'application/json',
                'maxOutputTokens' => 2048,
            ],
        ];
        $url = rtrim($this->baseUrl, '/') . '/models/' . rawurlencode($this->model) . ':generateContent';
        try {
            $res = $this->http->request('POST', $url, [
                'Content-Type' => 'application/json',
                'x-goog-api-key' => $this->apiKey,
            ], json_encode($payload, JSON_UNESCAPED_UNICODE), 60);
        } catch (\Throwable $e) {
            throw new AiException('Gemini request failed: ' . $e->getMessage());
        }
        $data = $res->json();
        if (!$res->ok() || $data === null) {
            $msg = is_array($data) ? (string) ($data['error']['message'] ?? 'unknown error') : 'bad response';
            throw new AiException('Gemini HTTP ' . $res->status . ': ' . str_replace($this->apiKey, '[REDACTED]', mb_substr($msg, 0, 200)));
        }
        if (isset($data['promptFeedback']['blockReason'])) {
            throw new AiException('Gemini blocked the prompt: ' . (string) $data['promptFeedback']['blockReason']);
        }
        $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? null;
        if (!is_string($text) || trim($text) === '') {
            throw new AiException('Gemini returned no text');
        }
        $text = trim((string) preg_replace('/^```(?:json)?\s*|\s*```$/i', '', trim($text)));
        $decoded = json_decode($text, true);
        if (!is_array($decoded)) {
            throw new AiException('Gemini did not return valid JSON');
        }
        return $decoded;
    }
}
