<?php

declare(strict_types=1);

namespace SocialPilot\Ai;

final class AiException extends \RuntimeException
{
}
