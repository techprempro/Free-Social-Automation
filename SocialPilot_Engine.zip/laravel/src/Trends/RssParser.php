<?php

declare(strict_types=1);

namespace SocialPilot\Trends;

final class RssParser
{
    /**
     * @return array<int,array{title:string,link:string,pubDate:?\DateTimeImmutable,source:string,traffic:int}>
     */
    public static function parse(string $xml): array
    {
        if (trim($xml) === '') {
            return [];
        }
        $prev = libxml_use_internal_errors(true);
        // LIBXML_NONET blocks network access; PHP 8 already ignores external entities.
        $doc = simplexml_load_string($xml, \SimpleXMLElement::class, LIBXML_NONET | LIBXML_NOCDATA);
        libxml_clear_errors();
        libxml_use_internal_errors($prev);
        if ($doc === false || !isset($doc->channel->item)) {
            return [];
        }
        $items = [];
        foreach ($doc->channel->item as $item) {
            $title = trim((string) $item->title);
            if ($title === '') {
                continue;
            }
            $source = isset($item->source) ? trim((string) $item->source) : '';
            if ($source === '' && preg_match('/\s[-–—|]\s+([^-–—|]{2,60})$/u', $title, $m)) {
                $source = trim($m[1]);
            }
            $date = null;
            $rawDate = trim((string) $item->pubDate);
            // Some feeds print the wrong weekday ("Tue, 25 Nov 2026" is a Wednesday). PHP then silently moves the
            // date to the next Tuesday, which would wreck the freshness score. The weekday adds nothing, so drop it.
            $rawDate = (string) preg_replace('/^(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)[a-z]*,?\s*/i', '', $rawDate);
            if ($rawDate !== '') {
                try {
                    $date = (new \DateTimeImmutable($rawDate))->setTimezone(new \DateTimeZone('UTC'));
                } catch (\Exception) {
                    $date = null;
                }
            }
            $items[] = [
                'title' => $title,
                'link' => trim((string) $item->link),
                'pubDate' => $date,
                'source' => $source,
                'traffic' => self::traffic($item),
            ];
        }
        return $items;
    }

    /** Google Trends adds <ht:approx_traffic>200+</ht:approx_traffic> (namespace varies by feed version). */
    private static function traffic(\SimpleXMLElement $item): int
    {
        foreach ($item->getNamespaces(true) as $ns) {
            $children = $item->children($ns);
            if (isset($children->approx_traffic)) {
                return (int) preg_replace('/\D/', '', (string) $children->approx_traffic);
            }
        }
        return 0;
    }
}
