<?php

declare(strict_types=1);

namespace SocialPilot\Trends;

final class Candidate
{
    public function __construct(
        public string $title,
        public string $url,
        public string $source,
        public ?\DateTimeImmutable $publishedAt = null,
        public int $mentions = 1,
        public bool $trending = false,
        public float $signal = 0.0,
        public string $fingerprint = '',
    ) {
    }
}
