<?php

declare(strict_types=1);

namespace SocialPilot\Trends;

/** Title normalisation used for de-duplication and "how many outlets cover this" clustering. */
final class Text
{
    /** Removes a trailing " - Outlet" / " | Outlet" suffix that news feeds append. */
    public static function stripOutlet(string $title): string
    {
        return trim((string) preg_replace('/\s+[-–—|]\s+[^-–—|]{2,60}$/u', '', trim($title)));
    }

    public static function normalize(string $title): string
    {
        $t = mb_strtolower(self::stripOutlet($title));
        $t = (string) preg_replace('/[^\p{L}\p{N}\p{M}\s]+/u', ' ', $t);
        return trim((string) preg_replace('/\s+/u', ' ', $t));
    }

    public static function fingerprint(string $title): string
    {
        return sha1(self::normalize($title));
    }

    /** @return string[] */
    public static function tokens(string $title): array
    {
        $out = [];
        foreach (explode(' ', self::normalize($title)) as $tok) {
            if (mb_strlen($tok) >= 3) {
                $out[$tok] = true;
            }
        }
        return array_keys($out);
    }

    /** Jaccard similarity of the token sets. */
    public static function similarity(string $a, string $b): float
    {
        $ta = self::tokens($a);
        $tb = self::tokens($b);
        if (!$ta || !$tb) {
            return 0.0;
        }
        $inter = count(array_intersect($ta, $tb));
        $union = count(array_unique(array_merge($ta, $tb)));
        return $union > 0 ? $inter / $union : 0.0;
    }
}
