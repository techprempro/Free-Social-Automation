<?php

declare(strict_types=1);

namespace SocialPilot\Trends;

use SocialPilot\Http\HttpClient;
use SocialPilot\Support\Clock;

/**
 * Finds candidate stories for a topic from public RSS feeds (Google News search + Google Trends)
 * and scores them with transparent signals. "Viral" is an ESTIMATE:
 *   signal = 45% freshness + 35% how many outlets cover it + 20% match with a currently trending search.
 * The AI then judges relevance/shareability on top of this.
 */
final class TrendCollector
{
    public function __construct(private HttpClient $http, private Clock $clock)
    {
    }

    /** @param array<string,mixed> $topic @return Candidate[] */
    public function collect(array $topic, int $limit): array
    {
        $items = $this->newsItems($topic);
        $trending = $this->trendingTerms((string) $topic['region']);

        // 1) cluster near-duplicates: keep the freshest as representative, remember how many outlets covered it
        usort($items, fn (Candidate $a, Candidate $b) => ($b->publishedAt?->getTimestamp() ?? 0) <=> ($a->publishedAt?->getTimestamp() ?? 0));
        /** @var Candidate[] $clusters */
        $clusters = [];
        foreach ($items as $c) {
            $merged = false;
            foreach ($clusters as $rep) {
                if (Text::similarity($rep->title, $c->title) >= 0.5) {
                    $rep->mentions++;
                    $merged = true;
                    break;
                }
            }
            if (!$merged) {
                $clusters[] = $c;
            }
        }

        // 2) score
        $now = $this->clock->now()->getTimestamp();
        foreach ($clusters as $c) {
            $hours = $c->publishedAt ? max(0.0, ($now - $c->publishedAt->getTimestamp()) / 3600) : 24.0;
            $fresh = max(0.0, 1 - $hours / 24);
            $cover = min(1.0, ($c->mentions - 1) / 4);
            $norm = Text::normalize($c->title);
            foreach ($trending as $term) {
                if (mb_strlen($term) >= 3 && str_contains($norm, $term)) {
                    $c->trending = true;
                    break;
                }
            }
            $c->signal = round(100 * (0.45 * $fresh + 0.35 * $cover + 0.20 * ($c->trending ? 1 : 0)), 1);
            $c->fingerprint = Text::fingerprint($c->title);
        }
        usort($clusters, fn (Candidate $a, Candidate $b) => $b->signal <=> $a->signal);
        return array_slice($clusters, 0, max(1, $limit));
    }

    /** @param array<string,mixed> $topic @return Candidate[] */
    private function newsItems(array $topic): array
    {
        $lang = (string) $topic['language'];
        $region = (string) $topic['region'];
        $query = implode(' OR ', array_map(fn (string $k) => '"' . str_replace('"', '', $k) . '"', array_slice($topic['keywords'], 0, 6)));
        $url = 'https://news.google.com/rss/search?q=' . rawurlencode($query . ' when:1d')
            . '&hl=' . rawurlencode($lang) . '&gl=' . rawurlencode($region) . '&ceid=' . rawurlencode($region . ':' . $lang);
        try {
            $res = $this->http->request('GET', $url, ['Accept' => 'application/rss+xml, application/xml']);
        } catch (\Throwable) {
            return [];
        }
        if (!$res->ok()) {
            return [];
        }
        $out = [];
        foreach (RssParser::parse($res->body) as $it) {
            if (!preg_match('~^https?://~i', $it['link'])) {
                continue; // only real web links are ever shared
            }
            $out[] = new Candidate($it['title'], $it['link'], $it['source'], $it['pubDate']);
        }
        return $out;
    }

    /** @return string[] lower-cased currently trending search terms (empty if the feed is unavailable) */
    private function trendingTerms(string $region): array
    {
        try {
            $res = $this->http->request('GET', 'https://trends.google.com/trending/rss?geo=' . rawurlencode($region));
        } catch (\Throwable) {
            return [];
        }
        if (!$res->ok()) {
            return [];
        }
        $terms = [];
        foreach (RssParser::parse($res->body) as $it) {
            $terms[] = Text::normalize($it['title']);
        }
        return array_values(array_filter($terms));
    }
}
