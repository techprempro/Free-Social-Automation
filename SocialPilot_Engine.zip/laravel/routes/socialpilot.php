<?php

use Illuminate\Support\Facades\Route;
use SocialPilot\Laravel\ApiController;

// Owner panel (HTML shell, no data) + owner API (Bearer token) + public app-open tracking.
Route::get('/socialpilot', [ApiController::class, 'panel']);

Route::middleware('throttle:60,1')->prefix('api/socialpilot')->group(function () {
    Route::post('active-user', [ApiController::class, 'activeUser']);
});

// Tighter throttle on the owner API slows down token guessing.
Route::middleware('throttle:40,1')->prefix('api/socialpilot/admin')->group(function () {
    Route::match(['GET', 'POST', 'PUT', 'DELETE'], '{path?}', [ApiController::class, 'admin'])->where('path', '.*');
});
