# SocialPilot AI — সেটআপ গাইড (techprempro.com, Laravel + MySQL)

## এটা কী করে
নির্দিষ্ট বিষয় (Topic) ধরে চলে: Google News + Google Trends থেকে খবর জোগাড় → Gemini AI বিশ্লেষণ করে সবচেয়ে ভাইরাল হওয়ার মতো একটি খবর বেছে নেয় → প্রতিটি প্ল্যাটফর্মের জন্য আলাদা পোস্ট লেখে → সেফটি চেক → লিমিট চেক → অফিসিয়াল API দিয়ে পোস্ট।
প্ল্যাটফর্ম: Facebook Page, Instagram, X, Telegram, LinkedIn।

**ডিফল্ট নিরাপত্তা:** নতুন টপিকে "auto publish" চালু থাকে; বন্ধ করলে পোস্ট Draft হয়ে প্যানেলে অপেক্ষা করে, আপনি এক ট্যাপে Publish করেন। প্রথম কয়েকদিন auto publish বন্ধ রেখে Draft দেখে নেওয়ার পরামর্শ। দুঃখজনক/সংবেদনশীল খবর (মৃত্যু, দুর্ঘটনা ইত্যাদি) সবসময় Draft হয়, অটো পোস্ট হয় না।

## ১. ফাইল বসানো
`SocialPilot_Engine.zip` খুলে `laravel/` ফোল্ডারটি আপনার Laravel প্রজেক্টে `packages/socialpilot/` নামে রাখুন। তারপর প্রজেক্টের `composer.json`-এ:
```json
"repositories": [{"type": "path", "url": "packages/socialpilot"}],
"require": {"techprempro/socialpilot": "*"}
```
```
composer update techprempro/socialpilot
php artisan vendor:publish --tag=socialpilot-config
php artisan migrate
```
(এটি ৫টি টেবিল বানায়; MySQL-এ আগে ব্যাকআপ নিন।)

## ২. .env-এ বসান
```
SOCIALPILOT_ADMIN_TOKEN=   # ৩২+ অক্ষর: php -r "echo bin2hex(random_bytes(24));"
SOCIALPILOT_TIMEZONE=Asia/Dhaka
GEMINI_API_KEY=            # https://aistudio.google.com/apikey

FACEBOOK_PAGE_ID=
FACEBOOK_PAGE_TOKEN=       # Page access token, permission: pages_manage_posts
INSTAGRAM_USER_ID=
INSTAGRAM_TOKEN=           # instagram_content_publish; ইনস্টাগ্রামে ছবি (https) লাগে
X_API_KEY=
X_API_SECRET=
X_ACCESS_TOKEN=
X_ACCESS_TOKEN_SECRET=     # App permission: Read and write
TELEGRAM_BOT_TOKEN=        # @BotFather থেকে বট বানান
TELEGRAM_CHAT_ID=          # @channelname বা -100...; বটকে চ্যানেলের Admin করুন
LINKEDIN_ACCESS_TOKEN=     # scope w_member_social; প্রায় ৬০ দিন পর মেয়াদ শেষ
LINKEDIN_AUTHOR_URN=       # urn:li:person:xxxx
```
যেটা ফাঁকা থাকবে সেই প্ল্যাটফর্ম বন্ধ থাকবে। `.env` কখনো GitHub-এ দেবেন না।

## ৩. অটো চালানো
Laravel Scheduler প্রতি ১৫ মিনিটে `socialpilot:run` চালায়। cPanel/সার্ভারে একটি cron দিন:
```
* * * * * cd /path/to/project && php artisan schedule:run >> /dev/null 2>&1
```
আগে পরীক্ষা (কিছু পোস্ট হবে না): `php artisan socialpilot:run --dry-run`

## ৪. প্যানেল ও অ্যাপ
- ওয়েব প্যানেল: `https://techprempro.com/socialpilot` (Admin Token দিয়ে ঢুকবেন)। এখানে টপিক বানানো, Draft অনুমোদন/বাতিল, Pause/Resume, রিপোর্ট।
- টপিক উদাহরণ: নাম "ক্রিকেট", keywords `cricket, বিপিএল`, language `bn`, region `BD`, প্ল্যাটফর্ম বেছে নিন।
- Android অ্যাপ (`SocialPilot_App_GitHub.zip`) একই প্যানেল খোলে এবং প্রতিবার চালু হলে `/api/socialpilot/active-user`-এ ট্র্যাকিং পাঠায় (র‍্যান্ডম ইনস্টল আইডি, ডিভাইসের নাম, platform, app version)।

## ৫. লিমিট (ডিফল্ট, প্রতি প্ল্যাটফর্ম)
Facebook দিনে ৬ (৯০ মিনিট বিরতি), X ৮, Instagram ৩, Telegram ১০, LinkedIn ৩। `config/socialpilot.php`-এ বদলানো যায়।

## ৬. GitHub workflow
- রেপোর রুটে জিপগুলো আপলোড করুন, আর `.github/workflows/`-এ ইয়ামল ফাইল।
- `build-socialpilot-apk.yml` → সাইনড APK (আগের ৪টি Secret-ই লাগে: ANDROID_KEYSTORE_BASE64, ANDROID_KEYSTORE_PASSWORD, ANDROID_KEY_ALIAS, ANDROID_KEY_PASSWORD)।
- `socialpilot-php-tests.yml` → ইঞ্জিনের ৩১টি টেস্ট চালায়।

## সীমাবদ্ধতা (সৎভাবে)
- আসল Facebook/Instagram/X/Telegram/LinkedIn/Gemini API-তে লাইভ টেস্ট করা হয়নি; টেস্টগুলো নকল (fake) HTTP দিয়ে। প্রথমে `--dry-run` ও Draft মোডে দেখুন।
- Facebook: নিজের Page-এ ডেভেলপার মোডে চলে; অন্যের Page-এ পোস্টের জন্য Meta App Review লাগে।
- LinkedIn Organization (কোম্পানি পেজ) পোস্টে LinkedIn-এর অনুমোদন লাগে। API ভার্সন `202607` যাচাই করা নেই; ব্যর্থ হলে `LINKEDIN_API_VERSION` বদলান। LinkedIn-এ হ্যাশট্যাগ সাধারণ লেখা হিসেবে যায়।
- MySQL, আসল Laravel এবং Kotlin অ্যাপ এখানে বিল্ড/চালিয়ে দেখা হয়নি (SQLite ও PHP টেস্টে যাচাই)। প্রথম APK বিল্ডে ত্রুটি এলে লগ পাঠান।
- সব প্ল্যাটফর্মের নিয়ম মেনে চলুন: স্প্যাম বা অতিরিক্ত পোস্ট অ্যাকাউন্ট ব্যান করাতে পারে। অ্যাপের ট্র্যাকিং আপনার প্রাইভেসি পলিসিতে উল্লেখ করুন।
- আগের Supabase অ্যানালিটিক্স ড্যাশবোর্ড এই Laravel সংস্করণে ব্যবহৃত হয় না; এখানে নিজস্ব রিপোর্ট (প্যানেলে) আছে।
